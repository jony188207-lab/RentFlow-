// Protected-information lockout: three wrong passwords lock access and require extra verification.
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { db, fakeAuth, req, tokens } from "./helpers/fake-firestore";

vi.mock("@/lib/firebase/admin", () => ({ adminDb: () => db, adminAuth: () => fakeAuth }));

import { POST as unlock } from "@/app/api/admin/protected/unlock/route";

let correctPassword = "right-password";
const identityToolkit = vi.fn(async (_url: string, init: RequestInit) => {
  const { password } = JSON.parse(String(init.body));
  return new Response("{}", { status: password === correctPassword ? 200 : 400 });
});

const attempt = (password: string, totp?: string) =>
  unlock(req("/api/admin/protected/unlock", { method: "POST", token: "t-p1", body: JSON.stringify({ password, totp }) }));

beforeEach(() => {
  db.reset();
  Object.keys(tokens).forEach((k) => delete tokens[k]);
  db.store.set("admins/p1", { email: "p1@example.com", role: "reviewer", active: true, canViewProtected: true });
  tokens["t-p1"] = { uid: "p1", email: "p1@example.com", email_verified: true };
  vi.stubGlobal("fetch", identityToolkit);
});
afterEach(() => { vi.unstubAllGlobals(); identityToolkit.mockClear(); });

describe("protected area unlock", () => {
  it("issues a token for the correct password and logs success", async () => {
    const res = await attempt("right-password");
    expect(res.status).toBe(200);
    expect((await res.json()).unlockToken).toBeTruthy();
    expect(db.entries("auditLogs").map((e) => e.action)).toContain("protected.unlock_success");
  });

  it("locks out after three consecutive incorrect passwords, even if the fourth is correct", async () => {
    expect((await attempt("bad-1")).status).toBe(401);
    expect((await attempt("bad-2")).status).toBe(401);
    const third = await attempt("bad-3");
    expect(third.status).toBe(401);
    expect((await third.json()).locked).toBe(true);

    const fourth = await attempt("right-password");
    expect(fourth.status).toBe(429);
    expect((await fourth.json()).retryAfterSeconds).toBeGreaterThan(0);

    const actions = db.entries("auditLogs").map((e) => e.action);
    expect(actions.filter((a) => a === "protected.unlock_failed")).toHaveLength(3);
    expect(actions).toContain("protected.unlock_blocked_locked");
    // The password was never sent to Firebase while locked out.
    expect(identityToolkit).toHaveBeenCalledTimes(3);
  });

  it("after the lockout expires, a code from an enrolled authenticator is also required", async () => {
    db.store.set("protectedAttempts/p1", { failures: 3, lockedUntil: Date.now() - 1000 });
    const res = await attempt("right-password");
    expect(res.status).toBe(401);
    expect((await res.json()).requireTotp).toBe(true);
  });

  it("a successful unlock resets the failure counter", async () => {
    await attempt("bad-1");
    await attempt("right-password");
    expect(db.store.get("protectedAttempts/p1")).toEqual({ failures: 0 });
  });

  it("never records the password in the audit log", async () => {
    await attempt("super-secret-guess");
    expect(JSON.stringify(db.entries("auditLogs"))).not.toContain("super-secret-guess");
  });

  it("refuses admins that lack the protected-information grant", async () => {
    db.store.set("admins/p1", { email: "p1@example.com", role: "reviewer", active: true, canViewProtected: false });
    expect((await attempt("right-password")).status).toBe(403);
    expect(identityToolkit).not.toHaveBeenCalled();
  });
});
