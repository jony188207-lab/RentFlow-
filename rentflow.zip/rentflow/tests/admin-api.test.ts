// Route-level tests for admin authentication, authorization, role permissions, application data
// access, and audit logging. Firebase is replaced by an in-memory fake (see helpers/).
import { beforeEach, describe, expect, it, vi } from "vitest";
import { db, fakeAuth, req, revoked, tokens } from "./helpers/fake-firestore";
import { encryptField } from "@/lib/crypto";
import { issueUnlockToken } from "@/lib/auth/protected-area";

vi.mock("@/lib/firebase/admin", () => ({ adminDb: () => db, adminAuth: () => fakeAuth }));

import { GET as me } from "@/app/api/admin/me/route";
import { GET as stats } from "@/app/api/admin/stats/route";
import { POST as inviteAdmin } from "@/app/api/admin/admins/route";
import { PATCH as patchAdmin } from "@/app/api/admin/admins/[uid]/route";
import { GET as getApplication, PATCH as patchApplication } from "@/app/api/admin/applications/[id]/route";
import { GET as getReport } from "@/app/api/admin/protected/reports/[id]/route";
import { PUT as putSettings } from "@/app/api/admin/settings/route";

const actions = () => db.entries("auditLogs").map((e) => e.action as string);
const json = (r: Response) => r.json();
const addAdmin = (uid: string, role: string, extra: object = {}) =>
  db.store.set(`admins/${uid}`, { email: `${uid}@example.com`, role, active: true, ...extra });
const login = (token: string, uid: string, email = `${uid}@example.com`, verified = true) =>
  (tokens[token] = { uid, email, email_verified: verified });

beforeEach(() => {
  db.reset();
  Object.keys(tokens).forEach((k) => delete tokens[k]);
  revoked.length = 0;
});

describe("admin authentication & authorization", () => {
  it("rejects requests without a token (401) and with an invalid token (401)", async () => {
    expect((await me(req("/api/admin/me"))).status).toBe(401);
    expect((await me(req("/api/admin/me", { token: "nope" }))).status).toBe(401);
  });

  it("blocks ordinary applicants (valid login, not an admin) and audits the attempt", async () => {
    login("t-app", "applicant1");
    const res = await me(req("/api/admin/me", { token: "t-app" }));
    expect(res.status).toBe(403);
    expect(actions()).toContain("security.admin_access_denied");
  });

  it("blocks unverified emails even for the configured initial admin address", async () => {
    login("t-unv", "ownerUid", "owner@example.com", false);
    expect((await me(req("/api/admin/me", { token: "t-unv" }))).status).toBe(403);
    expect(db.store.has("admins/ownerUid")).toBe(false);
  });

  it("bootstraps a super_admin only for the verified INITIAL_ADMIN_EMAIL, with an audit record", async () => {
    login("t-owner", "ownerUid", "Owner@Example.com");
    const res = await me(req("/api/admin/me", { token: "t-owner" }));
    expect(res.status).toBe(200);
    expect((await json(res)).role).toBe("super_admin");
    expect(db.store.get("admins/ownerUid")).toMatchObject({ role: "super_admin", active: true, canViewProtected: true });
    expect(actions()).toContain("admin.bootstrap");
  });

  it("rejects a disabled admin", async () => {
    addAdmin("a1", "admin", { active: false });
    login("t-a1", "a1");
    expect((await me(req("/api/admin/me", { token: "t-a1" }))).status).toBe(403);
  });

  it("consumes a pre-authorized email invite on first verified sign-in", async () => {
    db.store.set("adminInvites/new@example.com", { role: "reviewer", canViewProtected: false, active: true, createdBy: "x" });
    login("t-new", "newUid", "new@example.com");
    const res = await me(req("/api/admin/me", { token: "t-new" }));
    expect((await json(res)).role).toBe("reviewer");
    expect(db.store.has("adminInvites/new@example.com")).toBe(false);
    expect(actions()).toContain("admin.invite_consumed");
  });
});

describe("role-based permissions", () => {
  it("viewer can read stats-level data but cannot update applications", async () => {
    addAdmin("v1", "viewer");
    login("t-v1", "v1");
    db.store.set("applications/app1", { applicantName: "Sample", status: "new", isSample: true });
    const res = await patchApplication(req("/api/admin/applications/app1", { method: "PATCH", token: "t-v1", body: JSON.stringify({ status: "pending" }) }), { params: { id: "app1" } });
    expect(res.status).toBe(403);
    expect(actions()).toContain("security.permission_denied");
  });

  it("an ordinary admin cannot invite admins, promote anyone, or change security settings", async () => {
    addAdmin("a1", "admin");
    login("t-a1", "a1");
    const inv = await inviteAdmin(req("/api/admin/admins", { method: "POST", token: "t-a1", body: JSON.stringify({ email: "x@example.com", role: "admin" }) }));
    expect(inv.status).toBe(403);
    const patch = await patchAdmin(req("/api/admin/admins/a1", { method: "PATCH", token: "t-a1", body: JSON.stringify({ role: "admin" }) }), { params: { uid: "a1" } });
    expect(patch.status).toBe(403);
    const sec = await putSettings(req("/api/admin/settings", { method: "PUT", token: "t-a1", body: JSON.stringify({ maxFailedAttempts: 10 }) }));
    expect(sec.status).toBe(403);
  });

  it("super_admin cannot change their own access or modify another super_admin, and cannot grant super_admin", async () => {
    addAdmin("s1", "super_admin", { canViewProtected: true });
    addAdmin("s2", "super_admin");
    addAdmin("r1", "reviewer");
    login("t-s1", "s1");
    const patch = (uid: string, body: object) => patchAdmin(req(`/api/admin/admins/${uid}`, { method: "PATCH", token: "t-s1", body: JSON.stringify(body) }), { params: { uid } });
    expect((await patch("s1", { active: false })).status).toBe(403);
    expect((await patch("s2", { active: false })).status).toBe(403);
    expect((await patch("r1", { role: "super_admin" })).status).toBe(400); // not an allowed role value
    expect((await patch("r1", { role: "admin", canViewProtected: true })).status).toBe(200);
    expect(db.store.get("admins/r1")).toMatchObject({ role: "admin", canViewProtected: true });
    expect(actions()).toContain("admin.permissions_changed");
  });

  it("disabling an admin revokes their sessions server-side", async () => {
    addAdmin("s1", "super_admin");
    addAdmin("r1", "reviewer");
    login("t-s1", "s1");
    const res = await patchAdmin(req("/api/admin/admins/r1", { method: "PATCH", token: "t-s1", body: JSON.stringify({ active: false }) }), { params: { uid: "r1" } });
    expect(res.status).toBe(200);
    expect(revoked).toContain("r1");
  });

  it("settings: fee is validated server-side and the change is audited with old and new values", async () => {
    addAdmin("a1", "admin");
    login("t-a1", "a1");
    const bad = await putSettings(req("/api/admin/settings", { method: "PUT", token: "t-a1", body: JSON.stringify({ totalFeeCents: -5 }) }));
    expect(bad.status).toBe(400);
    const tooBig = await putSettings(req("/api/admin/settings", { method: "PUT", token: "t-a1", body: JSON.stringify({ totalFeeCents: 9_999_999 }) }));
    expect(tooBig.status).toBe(400);
    const ok = await putSettings(req("/api/admin/settings", { method: "PUT", token: "t-a1", body: JSON.stringify({ totalFeeCents: 4500 }) }));
    expect(ok.status).toBe(200);
    expect(db.store.get("publicSettings/pricing")).toMatchObject({ totalFeeCents: 4500 });
    const entry = db.entries("auditLogs").find((e) => e.action === "settings.pricing_changed");
    expect(entry?.meta).toMatchObject({ oldFeeCents: 3500, newFeeCents: 4500 });
  });

  it("stats endpoint requires a valid admin", async () => {
    login("t-app", "applicant1");
    expect((await stats(req("/api/admin/stats", { token: "t-app" }))).status).toBe(403);
  });
});

describe("application data access & status changes", () => {
  beforeEach(() => {
    db.store.set("applications/app1", { applicantName: "Sample One", applicantEmail: "s1@example.com", status: "new", ssnEnc: encryptField("000-00-0000"), isSample: true });
  });

  it("never returns the encrypted SSN in application details and audits the view", async () => {
    addAdmin("v1", "viewer");
    login("t-v1", "v1");
    const res = await getApplication(req("/api/admin/applications/app1", { token: "t-v1" }), { params: { id: "app1" } });
    const body = await json(res);
    expect(res.status).toBe(200);
    expect(body.ssnEnc).toBeUndefined();
    expect(body.ssnOnFile).toBe(true);
    expect(actions()).toContain("application.viewed");
    expect(JSON.stringify(body)).not.toContain("000-00-0000");
  });

  it("rejection requires a human reason and acknowledgement of any screening report", async () => {
    addAdmin("r1", "reviewer");
    login("t-r1", "r1");
    db.store.set("screeningReports/rep1", { applicationId: "app1" });
    const call = (b: object) => patchApplication(req("/api/admin/applications/app1", { method: "PATCH", token: "t-r1", body: JSON.stringify(b) }), { params: { id: "app1" } });
    expect((await call({ status: "rejected" })).status).toBe(400);
    expect((await call({ status: "rejected", reason: "Income does not meet the stated requirement" })).status).toBe(409);
    expect((await call({ status: "rejected", reason: "Income does not meet the stated requirement", acknowledgeReportReviewed: true })).status).toBe(200);
    expect(db.store.get("applications/app1")).toMatchObject({ status: "rejected", publicStatus: "decision_made" });
    const entry = db.entries("auditLogs").find((e) => e.action === "application.status_changed");
    expect(entry).toMatchObject({ actorUid: "r1", targetId: "app1", meta: { from: "new", to: "rejected" } });
  });
});

describe("protected report access", () => {
  const secret = process.env.PROTECTED_AREA_SECRET!;
  beforeEach(() => {
    db.store.set("screeningReports/rep1", { applicationId: "app1", verified: false, isSample: true, payloadEnc: encryptField(JSON.stringify({ demo: true })) });
  });
  const get = (token: string, unlock?: string) => getReport(req("/api/admin/protected/reports/rep1", { token, unlock }), { params: { id: "rep1" } });

  it("denies admins without the explicit protected grant (even super_admin)", async () => {
    addAdmin("s1", "super_admin"); // no canViewProtected
    login("t-s1", "s1");
    expect((await get("t-s1", issueUnlockToken("s1", secret))).status).toBe(403);
  });

  it("denies without a re-authentication token and audits the denied attempt", async () => {
    addAdmin("p1", "reviewer", { canViewProtected: true });
    login("t-p1", "p1");
    expect((await get("t-p1")).status).toBe(403);
    expect(actions()).toContain("protected.access_denied");
  });

  it("denies a token issued for a different admin or signed with another secret", async () => {
    addAdmin("p1", "reviewer", { canViewProtected: true });
    login("t-p1", "p1");
    expect((await get("t-p1", issueUnlockToken("someone-else", secret))).status).toBe(403);
    expect((await get("t-p1", issueUnlockToken("p1", "wrong-secret"))).status).toBe(403);
  });

  it("returns the decrypted report with a valid token, and logs the view without report contents", async () => {
    addAdmin("p1", "reviewer", { canViewProtected: true });
    login("t-p1", "p1");
    const res = await get("t-p1", issueUnlockToken("p1", secret));
    expect(res.status).toBe(200);
    expect((await json(res)).payload).toEqual({ demo: true });
    expect(res.headers.get("cache-control")).toBe("no-store");
    const entry = db.entries("auditLogs").find((e) => e.action === "protected.report_viewed");
    expect(entry).toBeTruthy();
    expect(JSON.stringify(entry)).not.toContain("demo");
  });

  it("stores reports encrypted at rest", () => {
    expect(JSON.stringify(db.store.get("screeningReports/rep1"))).not.toContain('"demo"');
  });
});
