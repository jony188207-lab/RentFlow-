// Minimal in-memory stand-in for Firestore + Firebase Auth, used by API route tests.
// Supports only what the routes under test use.
type Doc = Record<string, any>;

function makeDb() {
  const store = new Map<string, Doc>();
  let n = 0;

  const snap = (path: string): any => ({
    id: path.split("/").pop(),
    exists: store.has(path),
    data: () => store.get(path),
    ref: ref(path),
  });

  const ref = (path: string): any => ({
    id: path.split("/").pop(),
    path,
    get: async () => snap(path),
    set: async (d: Doc, opts?: { merge?: boolean }) => { store.set(path, opts?.merge ? { ...store.get(path), ...d } : d); },
    update: async (d: Doc) => {
      if (!store.has(path)) throw new Error("not found");
      store.set(path, { ...store.get(path), ...d });
    },
    delete: async () => { store.delete(path); },
    create: async (d: Doc) => {
      if (store.has(path)) throw new Error("already exists");
      store.set(path, d);
    },
    collection: (name: string) => col(`${path}/${name}`),
  });

  const query = (path: string, filters: [string, unknown][]): any => ({
    where: (f: string, _op: string, v: unknown) => query(path, [...filters, [f, v]]),
    orderBy: () => query(path, filters),
    limit: () => query(path, filters),
    get: async () => {
      const docs = [...store.keys()]
        .filter((k) => k.startsWith(path + "/") && !k.slice(path.length + 1).includes("/"))
        .filter((k) => filters.every(([f, v]) => store.get(k)?.[f] === v))
        .map(snap);
      return { empty: docs.length === 0, docs, size: docs.length };
    },
  });

  const col = (path: string): any => ({
    doc: (id: string) => ref(`${path}/${id}`),
    add: async (d: Doc) => {
      const id = `auto${++n}`;
      store.set(`${path}/${id}`, d);
      return ref(`${path}/${id}`);
    },
    where: (f: string, op: string, v: unknown) => query(path, [[f, v]]),
    orderBy: () => query(path, []),
  });

  return {
    store,
    collection: (name: string) => col(name),
    // Real Firestore transactions are optimistic; this fake just runs the callback.
    runTransaction: async (fn: (tx: any) => Promise<any>) =>
      fn({ get: (r: any) => r.get(), update: (r: any, d: Doc) => r.update(d), set: (r: any, d: Doc) => r.set(d), create: (r: any, d: Doc) => r.create(d) }),
    reset: () => store.clear(),
    entries: (prefix: string) => [...store.entries()].filter(([k]) => k.startsWith(prefix + "/")).map(([, v]) => v),
  };
}

export const db = makeDb();

/** token string → decoded identity. Unknown tokens are rejected like an invalid Firebase token. */
export const tokens: Record<string, { uid: string; email?: string; email_verified?: boolean }> = {};
export const revoked: string[] = [];

export const fakeAuth = {
  verifyIdToken: async (t: string) => {
    const id = tokens[t];
    if (!id) throw new Error("invalid token");
    return id;
  },
  revokeRefreshTokens: async (uid: string) => { revoked.push(uid); },
};

export const req = (url: string, init: RequestInit & { token?: string; unlock?: string } = {}) => {
  const headers: Record<string, string> = { ...(init.headers as Record<string, string>) };
  if (init.token) headers.authorization = `Bearer ${init.token}`;
  if (init.unlock) headers["x-unlock-token"] = init.unlock;
  return new Request(`http://localhost${url}`, { ...init, headers });
};
