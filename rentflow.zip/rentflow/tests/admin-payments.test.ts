// Admin side: payment-method management (super_admin only), payment review, private screenshot
// access, promo codes, audit logging.
import { beforeEach, describe, expect, it, vi } from "vitest";
import { db, fakeAuth, req, tokens } from "./helpers/fake-firestore";

const { files } = vi.hoisted(() => ({ files: new Map<string, Buffer>() }));
vi.mock("@/lib/firebase/admin", () => ({ adminDb: () => db, adminAuth: () => fakeAuth }));
vi.mock("@/lib/storage", () => ({
  putPrivate: async (p: string, b: Buffer) => { files.set(p, b); },
  readPrivate: async (p: string) => { const b = files.get(p); if (!b) throw new Error("missing"); return b; },
  deletePrivate: async (p: string) => { files.delete(p); },
}));

import { GET as listMethods, POST as createMethod } from "@/app/api/admin/payment-methods/route";
import { PUT as updateMethod, DELETE as deleteMethod } from "@/app/api/admin/payment-methods/[id]/route";
import { POST as uploadQr } from "@/app/api/admin/payment-methods/[id]/qr/route";
import { GET as publicQr } from "@/app/api/public/payment-methods/[id]/qr/route";
import { GET as getPayment, POST as reviewPayment } from "@/app/api/admin/payments/[id]/route";
import { GET as getProof } from "@/app/api/admin/payments/[id]/proof/route";
import { POST as createPromo } from "@/app/api/admin/promo-codes/route";
import { POST as statusLookup } from "@/app/api/status/route";

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(32)]);
const json = (o: object) => JSON.stringify(o);
const actions = () => db.entries("auditLogs").map((e) => e.action as string);
const addAdmin = (uid: string, role: string, extra: object = {}) => {
  db.store.set(`admins/${uid}`, { email: `${uid}@example.com`, role, active: true, ...extra });
  tokens[`t-${uid}`] = { uid, email: `${uid}@example.com`, email_verified: true };
};
const cashApp = { provider: "cashapp", enabled: true, displayName: "Cash App", description: "", instructions: "", applicantGuidance: "", paymentUrl: "https://cash.app/$Biz", identifier: "$Biz", amountMode: "global", currency: "USD", displayOrder: 1, countries: [] };

beforeEach(() => {
  db.reset(); files.clear();
  Object.keys(tokens).forEach((k) => delete tokens[k]);
  addAdmin("super", "super_admin"); addAdmin("adm", "admin"); addAdmin("rev", "reviewer"); addAdmin("view", "viewer");
  tokens["t-applicant"] = { uid: "ap1", email: "ap@example.com", email_verified: true };
});

describe("payment method management", () => {
  const create = (token: string, body: object) => createMethod(req("/api/admin/payment-methods", { method: "POST", token, body: json(body) }));

  it("only a super administrator can add, edit or delete methods; others get 403", async () => {
    for (const t of ["t-adm", "t-rev", "t-view", "t-applicant"]) expect((await create(t, cashApp)).status).toBe(403);
    expect((await create("t-super", cashApp)).status).toBe(201);
    db.store.set("paymentMethods/m1", { ...cashApp, hasQr: false });
    const put = (token: string) => updateMethod(req("/api/admin/payment-methods/m1", { method: "PUT", token, body: json({ ...cashApp, displayName: "X" }) }), { params: { id: "m1" } });
    expect((await put("t-adm")).status).toBe(403);
    expect((await deleteMethod(req("/api/admin/payment-methods/m1", { method: "DELETE", token: "t-adm" }), { params: { id: "m1" } })).status).toBe(403);
    expect((await put("t-super")).status).toBe(200);
  });

  it("readers can list methods but the response never contains storage paths", async () => {
    db.store.set("paymentMethods/m1", { ...cashApp, hasQr: true, qrPath: "payment-qr/secret.png", displayOrder: 1 });
    const res = await listMethods(req("/api/admin/payment-methods", { token: "t-view" }));
    const body = await res.json();
    expect(body.items).toHaveLength(1);
    expect(JSON.stringify(body)).not.toContain("secret.png");
    expect(body.capabilities.chime.supportsQr).toBe(false);
  });

  it("rejects provider-invalid input: lookalike hosts, Chime links, enabling with nothing to pay to", async () => {
    expect((await create("t-super", { ...cashApp, paymentUrl: "https://cash.app.evil.com/$Biz" })).status).toBe(400);
    expect((await create("t-super", { ...cashApp, provider: "chime", paymentUrl: "https://chime.com/x", identifier: "$biz" })).status).toBe(400);
    expect((await create("t-super", { ...cashApp, paymentUrl: undefined, identifier: undefined })).status).toBe(400);
    expect((await create("t-super", { ...cashApp, paymentUrl: undefined, identifier: undefined, enabled: false })).status).toBe(201);
  });

  it("records old and new payment identifier in the audit log (payment-diversion trail)", async () => {
    db.store.set("paymentMethods/m1", { ...cashApp, hasQr: false });
    await updateMethod(req("/api/admin/payment-methods/m1", { method: "PUT", token: "t-super", body: json({ ...cashApp, identifier: "$NewOne", paymentUrl: "https://cash.app/$NewOne" }) }), { params: { id: "m1" } });
    const e = db.entries("auditLogs").find((x) => x.action === "payment_method.updated");
    expect(e).toMatchObject({ actorUid: "super", meta: { oldIdentifier: "$Biz", newIdentifier: "$NewOne" } });
  });

  it("QR upload: validated by content, refused for providers without QR, and served only while enabled", async () => {
    db.store.set("paymentMethods/m1", { ...cashApp, hasQr: false });
    db.store.set("paymentMethods/chime1", { ...cashApp, provider: "chime", paymentUrl: undefined, identifier: "$biz", hasQr: false });
    const up = (id: string, file: File) => { const fd = new FormData(); fd.set("qr", file); return uploadQr(req(`/api/admin/payment-methods/${id}/qr`, { method: "POST", token: "t-super", body: fd }), { params: { id } }); };
    expect((await up("chime1", new File([PNG], "q.png", { type: "image/png" }))).status).toBe(400);
    expect((await up("m1", new File([Buffer.from("<svg/>")], "q.png", { type: "image/png" }))).status).toBe(400);
    expect((await up("m1", new File([PNG], "q.png", { type: "image/png" }))).status).toBe(200);
    const m = db.store.get("paymentMethods/m1")!;
    expect(m.hasQr).toBe(true);
    expect(files.has(m.qrPath)).toBe(true);

    const ok = await publicQr(req("/api/public/payment-methods/m1/qr"), { params: { id: "m1" } });
    expect(ok.status).toBe(200);
    expect(ok.headers.get("content-type")).toBe("image/png");
    db.store.set("paymentMethods/m1", { ...m, enabled: false });
    expect((await publicQr(req("/api/public/payment-methods/m1/qr"), { params: { id: "m1" } })).status).toBe(404);
  });
});

describe("payment review", () => {
  beforeEach(() => {
    files.set("payment-proofs/ap1/p1.png", PNG);
    db.store.set("payments/p1", { source: "manual", applicantUid: "ap1", applicantEmail: "ap@example.com", methodId: "m1", methodName: "Cash App", provider: "manual:cashapp", transactionRef: "TX-1", proofPath: "payment-proofs/ap1/p1.png", proofContentType: "image/png", amountCents: 3500, currency: "USD", status: "pending_verification", refundStatus: "none", applicationId: "RF-AAAAAAAA", isSample: false });
    db.store.set("applications/RF-AAAAAAAA", { applicantName: "Sample Person", applicantEmail: "ap@example.com", status: "new", publicStatus: "received", paymentId: "p1", property: { address: "1 Fictional St" } });
  });
  const act = (token: string, body: object) => reviewPayment(req("/api/admin/payments/p1", { method: "POST", token, body: json(body) }), { params: { id: "p1" } });

  it("shows payment, applicant application and history together", async () => {
    const res = await getPayment(req("/api/admin/payments/p1", { token: "t-view" }), { params: { id: "p1" } });
    const body = await res.json();
    expect(body).toMatchObject({ id: "p1", transactionRef: "TX-1", hasProof: true, application: { reference: "RF-AAAAAAAA", applicantName: "Sample Person" } });
    expect(JSON.stringify(body)).not.toContain("payment-proofs/");
  });

  it("only admins with payments.manage can review; reviewers/viewers/applicants cannot", async () => {
    for (const t of ["t-rev", "t-view", "t-applicant"]) expect((await act(t, { action: "approve" })).status).toBe(403);
    expect(db.store.get("payments/p1")!.status).toBe("pending_verification");
  });

  it("approve → verified, audited with the reviewing admin; applicant then sees Verified", async () => {
    const look = () => statusLookup(req("/api/status", { method: "POST", body: json({ applicationId: "RF-AAAAAAAA", email: "ap@example.com" }) })).then((r) => r.json());
    expect((await look()).paymentStatus).toBe("Pending Verification");
    expect((await act("t-adm", { action: "approve", notes: "Funds seen in account" })).status).toBe(200);
    expect(db.store.get("payments/p1")).toMatchObject({ status: "verified", reviewedBy: "adm", reviewNotes: "Funds seen in account" });
    expect((await look()).paymentStatus).toBe("Verified");
    const e = db.entries("auditLogs").find((x) => x.action === "payment.reviewed");
    expect(e).toMatchObject({ actorUid: "adm", targetId: "p1", meta: { from: "pending_verification", to: "verified" } });
    expect(db.entries("payments/p1/events")).toHaveLength(1);
  });

  it("reject requires a reason; refund states follow a strict order", async () => {
    expect((await act("t-adm", { action: "reject" })).status).toBe(400);
    expect((await act("t-adm", { action: "refund_pending", notes: "customer asked" })).status).toBe(409); // not verified yet
    expect((await act("t-adm", { action: "approve" })).status).toBe(200);
    expect((await act("t-adm", { action: "approve" })).status).toBe(409); // already verified
    expect((await act("t-adm", { action: "refund_pending", notes: "customer asked" })).status).toBe(200);
    expect(db.store.get("payments/p1")).toMatchObject({ status: "refund_pending", refundStatus: "pending" });
    expect((await act("t-adm", { action: "mark_refunded", notes: "sent back via Cash App" })).status).toBe(200);
    expect(db.store.get("payments/p1")).toMatchObject({ status: "refunded", refundStatus: "refunded" });
    expect((await act("t-adm", { action: "reject", notes: "too late now" })).status).toBe(409);
  });

  it("a rejected payment can be rejected with notes and the applicant sees Rejected", async () => {
    expect((await act("t-adm", { action: "reject", notes: "Amount did not arrive" })).status).toBe(200);
    const r = await statusLookup(req("/api/status", { method: "POST", body: json({ applicationId: "RF-AAAAAAAA", email: "ap@example.com" }) }));
    expect((await r.json()).paymentStatus).toBe("Rejected");
  });

  it("manual payments cannot be marked paid by the provider 'verify' action", async () => {
    expect((await act("t-adm", { action: "verify" })).status).toBe(409);
  });

  it("screenshots stream only to authorized admins, are never cached, and every view is audited", async () => {
    const proof = (token: string) => getProof(req("/api/admin/payments/p1/proof", { token }), { params: { id: "p1" } });
    expect((await proof("t-applicant")).status).toBe(403);
    expect((await getProof(req("/api/admin/payments/p1/proof"), { params: { id: "p1" } })).status).toBe(401);
    const ok = await proof("t-view");
    expect(ok.status).toBe(200);
    expect(ok.headers.get("cache-control")).toBe("private, no-store");
    expect(ok.headers.get("content-type")).toBe("image/png");
    expect(actions()).toContain("payment.proof_viewed");
  });
});

describe("promo code management", () => {
  const create = (token: string, body: object) => createPromo(req("/api/admin/promo-codes", { method: "POST", token, body: json(body) }));
  it("needs settings.write; validates percent range; rejects duplicates; audits", async () => {
    expect((await create("t-rev", { code: "SAVE10", type: "percent", value: 10 })).status).toBe(403);
    expect((await create("t-adm", { code: "SAVE10", type: "percent", value: 100 })).status).toBe(400);
    expect((await create("t-adm", { code: "bad code!", type: "percent", value: 10 })).status).toBe(400);
    expect((await create("t-adm", { code: "save10", type: "percent", value: 10 })).status).toBe(201);
    expect((await create("t-adm", { code: "SAVE10", type: "percent", value: 20 })).status).toBe(409);
    expect(db.store.get("promoCodes/SAVE10")).toMatchObject({ type: "percent", value: 10, usedCount: 0 });
    expect(actions()).toContain("settings.promo_created");
  });
});
