// Applicant payment-proof + application flow, public checkout, and public status. Firebase and
// private storage are replaced by in-memory fakes.
import { beforeEach, describe, expect, it, vi } from "vitest";
import { db, fakeAuth, req, tokens } from "./helpers/fake-firestore";

const { files } = vi.hoisted(() => ({ files: new Map<string, Buffer>() }));
vi.mock("@/lib/firebase/admin", () => ({ adminDb: () => db, adminAuth: () => fakeAuth }));
vi.mock("@/lib/storage", () => ({
  putPrivate: async (p: string, b: Buffer) => { files.set(p, b); },
  readPrivate: async (p: string) => { const b = files.get(p); if (!b) throw new Error("missing"); return b; },
  deletePrivate: async (p: string) => { files.delete(p); },
}));

import { GET as checkout } from "@/app/api/public/checkout/route";
import { POST as submitPayment } from "@/app/api/applicant/payments/route";
import { GET as listMine, POST as submitApplication } from "@/app/api/applicant/applications/route";
import { POST as statusLookup } from "@/app/api/status/route";

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64)]);
let n = 0;
const key = () => `idem-key-${String(++n).padStart(16, "0")}`;

const pngFile = () => new File([PNG], "shot.png", { type: "image/png" });
function paymentForm(over: Record<string, string> = {}, file: File | null | "none" = "default") {
  const fd = new FormData();
  fd.set("methodId", "m1"); fd.set("transactionRef", `TX-${++n}-ABCD`); fd.set("idempotencyKey", key());
  Object.entries(over).forEach(([k, v]) => fd.set(k, v));
  if (file === "default") fd.set("screenshot", pngFile());
  else if (file && file !== "none") fd.set("screenshot", file);
  return fd;
}
const pay = (fd: FormData, token = "t-ap") => submitPayment(req("/api/applicant/payments", { method: "POST", token, body: fd }));
const payCount = () => [...db.store.keys()].filter((k) => /^payments\/[^/]+$/.test(k)).length;

const app = (paymentId: string, over: object = {}) => ({
  paymentId, fullName: "Sample Person", phone: "555-0100",
  property: { address: "1 Fictional St", rentCents: 150000, moveIn: "2026-12-01" },
  household: { adults: 1, children: 0, pets: [] },
  employment: { employer: "Fictional Co", title: "Analyst", monthlyIncomeCents: 400000 },
  rentalHistory: [], ssn: "000-00-0000",
  consent: { fcraDisclosure: true, screeningAuthorization: true }, ...over,
});
const submitApp = (body: object, token = "t-ap") => submitApplication(req("/api/applicant/applications", { method: "POST", token, body: JSON.stringify(body) }));

beforeEach(() => {
  db.reset(); files.clear();
  Object.keys(tokens).forEach((k) => delete tokens[k]);
  tokens["t-ap"] = { uid: "ap1", email: "ap@example.com", email_verified: true };
  tokens["t-other"] = { uid: "ap2", email: "other@example.com", email_verified: true };
  tokens["t-unverified"] = { uid: "ap3", email: "u@example.com", email_verified: false };
  db.store.set("paymentMethods/m1", { provider: "cashapp", enabled: true, displayName: "Cash App", description: "d", instructions: "i", applicantGuidance: "g", paymentUrl: "https://cash.app/$Biz", identifier: "$Biz", amountMode: "global", currency: "USD", displayOrder: 1, countries: [], hasQr: false, qrPath: "secret/path.png", updatedBy: "admin1" });
  db.store.set("paymentMethods/m2", { provider: "paypal", enabled: false, displayName: "PayPal (off)", identifier: "pay@biz.com", amountMode: "global", currency: "USD", displayOrder: 2, countries: [], hasQr: false });
});

describe("public checkout", () => {
  it("shows only enabled methods with a server-computed price, and no admin-only fields", async () => {
    const res = await checkout(req("/api/public/checkout?country=US"));
    const body = await res.json();
    expect(res.status).toBe(200);
    expect(body.methods.map((m: any) => m.id)).toEqual(["m1"]);
    expect(body.methods[0].amountCents).toBe(3500);
    expect(JSON.stringify(body)).not.toMatch(/qrPath|updatedBy|secret\/path/);
  });
  it("reflects admin changes immediately (enable another method, change fee, add promo)", async () => {
    db.store.set("paymentMethods/m2", { ...db.store.get("paymentMethods/m2"), enabled: true });
    db.store.set("settings/app", { totalFeeCents: 5000 });
    db.store.set("promoCodes/SAVE10", { type: "percent", value: 10, active: true, usedCount: 0 });
    const body = await (await checkout(req("/api/public/checkout?country=US&promo=save10"))).json();
    expect(body.methods.map((m: any) => m.id)).toEqual(["m1", "m2"]);
    expect(body.methods[0].amountCents).toBe(4500);
    expect(body.promo).toMatchObject({ valid: true, code: "SAVE10" });
  });
  it("applies country availability and reports invalid promos", async () => {
    db.store.set("paymentMethods/m1", { ...db.store.get("paymentMethods/m1"), countries: ["US"] });
    expect((await (await checkout(req("/api/public/checkout?country=BD"))).json()).methods).toHaveLength(0);
    const body = await (await checkout(req("/api/public/checkout?country=US&promo=NOPE"))).json();
    expect(body.promo.valid).toBe(false);
    expect(body.methods[0].amountCents).toBe(3500);
  });
  it("shows a closed state when applications are disabled", async () => {
    db.store.set("settings/app", { applicationsEnabled: false });
    expect((await (await checkout(req("/api/public/checkout"))).json()).applicationsEnabled).toBe(false);
  });
});

describe("payment proof submission", () => {
  it("requires a signed-in applicant with a verified email", async () => {
    expect((await submitPayment(req("/api/applicant/payments", { method: "POST", body: paymentForm() }))).status).toBe(401);
    expect((await pay(paymentForm(), "t-unverified")).status).toBe(403);
  });

  it("stores a pending_verification payment, never a paid one; ignores amount/status sent by the browser", async () => {
    const fd = paymentForm({ amountCents: "1", status: "verified", amount: "0.01" });
    const res = await pay(fd);
    expect(res.status).toBe(201);
    const id = (await res.json()).paymentId;
    const p = db.store.get(`payments/${id}`)!;
    expect(p).toMatchObject({ status: "pending_verification", amountCents: 3500, applicantUid: "ap1", applicationId: null, source: "manual" });
    expect(files.get(p.proofPath)).toBeTruthy();
    expect(p.proofPath).toMatch(/^payment-proofs\/ap1\//);
    expect(db.entries("auditLogs").map((e) => e.action)).toContain("payment.proof_submitted");
    expect(db.entries("notifications").map((x) => x.type)).toContain("payment.proof_submitted");
  });

  it("blocks submission without a screenshot when the admin requires one, and allows it when not", async () => {
    expect((await pay(paymentForm({}, "none"))).status).toBe(400);
    db.store.set("settings/app", { requireScreenshot: false });
    expect((await pay(paymentForm({}, "none"))).status).toBe(201);
  });

  it("rejects non-images (even when named .png) and oversize files", async () => {
    const fake = new File([Buffer.from("<svg onload=alert(1)>")], "shot.png", { type: "image/png" });
    expect((await pay(paymentForm({}, fake))).status).toBe(400);
    const big = new File([Buffer.concat([PNG, Buffer.alloc(4 * 1024 * 1024)])], "big.png", { type: "image/png" });
    expect((await pay(paymentForm({}, big))).status).toBe(413);
    expect(payCount()).toBe(0);
  });

  it("is idempotent: a retried request with the same key creates one payment", async () => {
    const k = key();
    const first = await pay(paymentForm({ idempotencyKey: k, transactionRef: "REF-AAAA-1" }));
    const second = await pay(paymentForm({ idempotencyKey: k, transactionRef: "REF-AAAA-1" }));
    expect(first.status).toBe(201);
    expect((await second.json()).duplicate).toBe(true);
    expect(payCount()).toBe(1);
  });

  it("rejects reuse of the same transaction reference (case-insensitive), even by another account", async () => {
    expect((await pay(paymentForm({ transactionRef: "Same-Ref-1" }))).status).toBe(201);
    expect((await pay(paymentForm({ transactionRef: "SAME-REF-1" }), "t-other")).status).toBe(409);
    expect(payCount()).toBe(1);
  });

  it("rejects disabled/unknown methods, restricted countries, bad promos and closed intake", async () => {
    expect((await pay(paymentForm({ methodId: "m2" }))).status).toBe(400);
    expect((await pay(paymentForm({ methodId: "nope" }))).status).toBe(400);
    db.store.set("paymentMethods/m1", { ...db.store.get("paymentMethods/m1"), countries: ["US"] });
    expect((await pay(paymentForm({ country: "BD" }))).status).toBe(400);
    expect((await pay(paymentForm({ country: "US", promo: "BOGUS" }))).status).toBe(400);
    db.store.set("settings/app", { applicationsEnabled: false });
    expect((await pay(paymentForm({ country: "US" }))).status).toBe(403);
    expect(payCount()).toBe(0);
  });

  it("applies a promo on the server, snapshots the price, and later fee changes do not alter old payments", async () => {
    db.store.set("promoCodes/SAVE10", { type: "percent", value: 10, active: true, usedCount: 0 });
    const a = await (await pay(paymentForm({ promo: "save10" }))).json();
    expect(db.store.get(`payments/${a.paymentId}`)).toMatchObject({ amountCents: 3150, baseCents: 3500, discountCents: 350, promoCode: "SAVE10" });
    expect(db.store.get("promoCodes/SAVE10")!.usedCount).toBeTruthy();

    db.store.set("settings/app", { totalFeeCents: 5000 });
    const b = await (await pay(paymentForm())).json();
    expect(db.store.get(`payments/${b.paymentId}`)!.amountCents).toBe(5000);
    expect(db.store.get(`payments/${a.paymentId}`)!.amountCents).toBe(3150);
  });

  it("never stores card numbers or CVV", async () => {
    const id = (await (await pay(paymentForm({ cardNumber: "4242424242424242", cvv: "123" }))).json()).paymentId;
    const stored = JSON.stringify(db.store.get(`payments/${id}`));
    expect(stored).not.toMatch(/4242424242424242|cvv|cvc/i);
  });
});

describe("application submission", () => {
  async function newPayment(token = "t-ap") {
    return (await (await pay(paymentForm({}, "default"), token)).json()).paymentId as string;
  }

  it("requires the payment proof to exist and belong to the applicant", async () => {
    const mine = await newPayment();
    expect((await submitApp(app("does-not-exist"))).status).toBe(403);
    expect((await submitApp(app(mine), "t-other")).status).toBe(403);
    expect((await submitApplication(req("/api/applicant/applications", { method: "POST", body: JSON.stringify(app(mine)) }))).status).toBe(401);
  });

  it("creates the application with a reference number, encrypted SSN and server-side consent timestamps; payment stays pending", async () => {
    const paymentId = await newPayment();
    const res = await submitApp(app(paymentId));
    const body = await res.json();
    expect(res.status).toBe(201);
    expect(body.reference).toMatch(/^RF-[A-Z0-9]{8}$/);
    const a = db.store.get(`applications/${body.reference}`)!;
    expect(a).toMatchObject({ applicantUid: "ap1", applicantEmail: "ap@example.com", status: "new", paymentId, isSample: false });
    expect(a.ssnEnc).toMatch(/^v1:/);
    expect(JSON.stringify(a)).not.toContain("000-00-0000");
    expect(a.consent.version).toBe("template-v0");
    expect(a.consent.fcraDisclosureAcceptedAt).toBeTruthy();
    expect(db.store.get(`payments/${paymentId}`)).toMatchObject({ applicationId: body.reference, status: "pending_verification" });
    expect(db.entries("notifications").map((x) => x.type)).toContain("application.new");
  });

  it("a payment can be used for only one application", async () => {
    const paymentId = await newPayment();
    expect((await submitApp(app(paymentId))).status).toBe(201);
    expect((await submitApp(app(paymentId))).status).toBe(409);
  });

  it("refuses a rejected payment, missing consent, and closed intake", async () => {
    const rejected = await newPayment();
    db.store.set(`payments/${rejected}`, { ...db.store.get(`payments/${rejected}`), status: "rejected" });
    expect((await submitApp(app(rejected))).status).toBe(409);

    const ok = await newPayment();
    expect((await submitApp(app(ok, { consent: { fcraDisclosure: true, screeningAuthorization: false } }))).status).toBe(400);
    db.store.set("settings/app", { applicationsEnabled: false });
    expect((await submitApp(app(ok))).status).toBe(403);
  });

  it("applicants see only their own applications, with the right payment label", async () => {
    const paymentId = await newPayment();
    let mine = await (await listMine(req("/api/applicant/applications", { token: "t-ap" }))).json();
    expect(mine.unlinkedPayments[0]).toMatchObject({ paymentId, label: "Submitted" });
    const { reference } = await (await submitApp(app(paymentId))).json();
    mine = await (await listMine(req("/api/applicant/applications", { token: "t-ap" }))).json();
    expect(mine.applications[0]).toMatchObject({ reference, payment: { label: "Pending Verification" } });
    const other = await (await listMine(req("/api/applicant/applications", { token: "t-other" }))).json();
    expect(other.applications).toHaveLength(0);
    expect(JSON.stringify(mine)).not.toMatch(/ssn|proofPath/i);
  });

  it("public status needs reference + matching email, and shows Pending Verification until an admin verifies", async () => {
    const paymentId = await newPayment();
    const { reference } = await (await submitApp(app(paymentId))).json();
    const look = (applicationId: string, email: string) => statusLookup(req("/api/status", { method: "POST", body: JSON.stringify({ applicationId, email }) }));
    expect((await look(reference, "wrong@example.com")).status).toBe(404);
    expect((await look("RF-NOTREAL1", "ap@example.com")).status).toBe(404);
    const ok = await (await look(reference.toLowerCase(), "AP@example.com")).json();
    expect(ok).toEqual({ status: "received", paymentStatus: "Pending Verification" });
  });
});
