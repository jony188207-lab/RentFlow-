// Payment verification: only authenticated provider webhooks (or an admin-triggered server-to-server
// provider lookup) can change payment status. Client-supplied status is never trusted.
import { beforeEach, describe, expect, it, vi } from "vitest";
import { db, fakeAuth, req, tokens } from "./helpers/fake-firestore";
import { computeSignature } from "@/lib/payments/webhook";

vi.mock("@/lib/firebase/admin", () => ({ adminDb: () => db, adminAuth: () => fakeAuth }));

import { POST as webhook } from "@/app/api/webhooks/payments/route";
import { POST as paymentAction } from "@/app/api/admin/payments/[id]/route";

const secret = process.env.PAYMENT_WEBHOOK_SECRET!;
const event = (over: object = {}, amountCents = 3500) =>
  JSON.stringify({ id: "evt_1", type: "payment.succeeded", data: { providerRef: "ref_1", amountCents, currency: "usd", cardBrand: "visa", cardLast4: "4242" }, ...over });
const signed = (body: string, t = Math.floor(Date.now() / 1000), s = secret) =>
  new Request("http://localhost/api/webhooks/payments", { method: "POST", body, headers: { "x-rentflow-signature": `t=${t},v1=${computeSignature(body, t, s)}` } });

beforeEach(() => {
  db.reset();
  Object.keys(tokens).forEach((k) => delete tokens[k]);
  db.store.set("payments/pay1", { applicationId: "app1", amountCents: 3500, status: "pending", providerRef: "ref_1", provider: "mock", isSample: true });
});

describe("payment webhook", () => {
  it("rejects unsigned requests without touching data", async () => {
    const res = await webhook(new Request("http://localhost/api/webhooks/payments", { method: "POST", body: event() }));
    expect(res.status).toBe(401);
    expect(db.store.get("payments/pay1")).toMatchObject({ status: "pending" });
  });

  it("rejects a wrong signature, and a stale timestamp (replay)", async () => {
    expect((await webhook(signed(event(), undefined, "wrong-secret"))).status).toBe(401);
    expect((await webhook(signed(event(), Math.floor(Date.now() / 1000) - 3600))).status).toBe(401);
    expect(db.store.get("payments/pay1")).toMatchObject({ status: "pending" });
  });

  it("marks the payment succeeded from a valid signed event, stores brand + last4, and audits it", async () => {
    const res = await webhook(signed(event()));
    expect(res.status).toBe(200);
    expect(db.store.get("payments/pay1")).toMatchObject({ status: "succeeded", cardBrand: "visa", cardLast4: "4242", needsReview: false });
    expect(db.entries("auditLogs").map((e) => e.action)).toContain("payment.status_changed");
    expect(db.entries("notifications").map((n) => n.type)).toContain("payment.completed");
  });

  it("is idempotent: replaying the same event id does not process it twice", async () => {
    await webhook(signed(event()));
    const second = await webhook(signed(event()));
    expect((await second.json()).duplicate).toBe(true);
    expect(db.entries("payments/pay1/events")).toHaveLength(1);
  });

  it("never marks paid when the provider amount differs from the charged amount", async () => {
    await webhook(signed(event({}, 100)));
    expect(db.store.get("payments/pay1")).toMatchObject({ status: "pending", needsReview: true });
    expect(db.entries("notifications").map((n) => n.type)).toContain("system.error");
  });

  it("never stores anything resembling a full card number or CVV", async () => {
    await webhook(signed(event()));
    const stored = JSON.stringify(db.store.get("payments/pay1"));
    expect(stored).not.toMatch(/\b\d{13,19}\b/);
    expect(stored.toLowerCase()).not.toMatch(/cvv|cvc/);
  });
});

describe("admin-triggered verification", () => {
  it("is server-to-server only: an admin cannot supply a status, and non-managers are denied", async () => {
    db.store.set("admins/v1", { email: "v1@example.com", role: "viewer", active: true });
    tokens["t-v1"] = { uid: "v1", email: "v1@example.com", email_verified: true };
    const denied = await paymentAction(req("/api/admin/payments/pay1", { method: "POST", token: "t-v1", body: JSON.stringify({ action: "verify" }) }), { params: { id: "pay1" } });
    expect(denied.status).toBe(403);

    db.store.set("admins/a1", { email: "a1@example.com", role: "admin", active: true });
    tokens["t-a1"] = { uid: "a1", email: "a1@example.com", email_verified: true };
    // Extra client-supplied "status" is ignored; the provider ledger (no record here) is authoritative.
    const res = await paymentAction(req("/api/admin/payments/pay1", { method: "POST", token: "t-a1", body: JSON.stringify({ action: "verify", status: "succeeded" }) }), { params: { id: "pay1" } });
    expect(res.status).toBe(404);
    expect(db.store.get("payments/pay1")).toMatchObject({ status: "pending" });
  });

  it("verifies against the provider ledger and records the result", async () => {
    db.store.set("admins/a1", { email: "a1@example.com", role: "admin", active: true });
    tokens["t-a1"] = { uid: "a1", email: "a1@example.com", email_verified: true };
    db.store.set("mockProviderLedger/ref_1", { status: "succeeded", amountCents: 3500, currency: "usd", cardBrand: "visa", cardLast4: "4242" });
    const res = await paymentAction(req("/api/admin/payments/pay1", { method: "POST", token: "t-a1", body: JSON.stringify({ action: "verify" }) }), { params: { id: "pay1" } });
    expect(res.status).toBe(200);
    expect(db.store.get("payments/pay1")).toMatchObject({ status: "succeeded" });
    expect(db.entries("auditLogs").map((e) => e.action)).toContain("payment.verified");
  });
});
