import { describe, expect, it } from "vitest";
import { PaymentMethodInput, hasPayableDetails, methodAvailableIn, qrAllowed } from "@/lib/paymentMethods";
import { computeQuote, evaluatePromo, type Promo } from "@/lib/pricing";
import { sniffImage } from "@/lib/files";
import { applicantPaymentLabel } from "@/lib/domain";
import { generateReference } from "@/lib/reference";
import { ApplicationInput } from "@/lib/applicationSchema";

const base = { provider: "cashapp", enabled: true, displayName: "Cash App", description: "", instructions: "", applicantGuidance: "", amountMode: "global", currency: "USD", displayOrder: 1, countries: [] };
const parse = (o: object) => PaymentMethodInput.safeParse({ ...base, ...o });

describe("payment method validation (per-provider rules)", () => {
  it("accepts valid provider-specific links and identifiers", () => {
    expect(parse({ paymentUrl: "https://cash.app/$MyBusiness", identifier: "$MyBusiness" }).success).toBe(true);
    expect(parse({ provider: "paypal", paymentUrl: "https://www.paypal.com/paypalme/biz" }).success).toBe(true);
    expect(parse({ provider: "stripe", paymentUrl: "https://buy.stripe.com/test_abc" }).success).toBe(true);
    expect(parse({ provider: "chime", identifier: "$biz-sign" }).success).toBe(true);
  });
  it("rejects links on the wrong host (lookalike domains) and non-https schemes", () => {
    expect(parse({ paymentUrl: "https://cash.app.evil.com/$x" }).success).toBe(false);
    expect(parse({ paymentUrl: "https://evil.com/cash.app" }).success).toBe(false);
    expect(parse({ paymentUrl: "http://cash.app/$x" }).success).toBe(false);
    expect(parse({ provider: "custom", paymentUrl: "javascript:alert(1)" }).success).toBe(false);
    expect(parse({ provider: "custom", paymentUrl: "https://user:pw@example.com/pay" }).success).toBe(false);
  });
  it("does not claim features a provider lacks: Chime has no payment link or QR", () => {
    expect(parse({ provider: "chime", paymentUrl: "https://chime.com/pay" }).success).toBe(false);
    expect(qrAllowed("chime")).toBe(false);
    expect(qrAllowed("payoneer")).toBe(false);
    expect(qrAllowed("cashapp")).toBe(true);
  });
  it("validates identifiers", () => {
    expect(parse({ identifier: "MyBusiness" }).success).toBe(false); // missing $
    expect(parse({ provider: "stripe", identifier: "abc" }).success).toBe(false); // no identifier concept
  });
  it("requires a fixed amount when amountMode is fixed", () => {
    expect(parse({ identifier: "$Biz", amountMode: "fixed" }).success).toBe(false);
    expect(parse({ identifier: "$Biz", amountMode: "fixed", fixedAmountCents: 4000 }).success).toBe(true);
  });
  it("rejects bad country codes and currencies", () => {
    expect(parse({ identifier: "$Biz", countries: ["usa"] }).success).toBe(false);
    expect(parse({ identifier: "$Biz", currency: "dollars" }).success).toBe(false);
  });
  it("country availability", () => {
    expect(methodAvailableIn({ countries: [] }, undefined)).toBe(true);
    expect(methodAvailableIn({ countries: ["US"] }, "us")).toBe(true);
    expect(methodAvailableIn({ countries: ["US"] }, "BD")).toBe(false);
    expect(methodAvailableIn({ countries: ["US"] }, undefined)).toBe(false);
  });
  it("an enabled method needs a way to pay", () => {
    expect(hasPayableDetails({})).toBe(false);
    expect(hasPayableDetails({ hasQr: true })).toBe(true);
  });
});

describe("promo + quote", () => {
  const promo = (o: Partial<Promo> = {}): Promo => ({ code: "SAVE", type: "percent", value: 10, active: true, usedCount: 0, ...o });
  const now = Date.parse("2026-11-01T00:00:00Z");
  it("computes percent and fixed discounts and never goes below zero", () => {
    expect(computeQuote(3500, promo())).toEqual({ baseCents: 3500, discountCents: 350, totalCents: 3150 });
    expect(computeQuote(3500, promo({ type: "fixed", value: 500 })).totalCents).toBe(3000);
    expect(computeQuote(300, promo({ type: "fixed", value: 500 })).totalCents).toBe(0);
    expect(computeQuote(3500, null).totalCents).toBe(3500);
  });
  it("rejects inactive, expired, not-yet-valid, exhausted and missing codes with one generic message", () => {
    const msgs = [
      evaluatePromo(promo({ active: false }), now, "USD", "USD"),
      evaluatePromo(promo({ endsAt: "2026-10-01T00:00:00Z" }), now, "USD", "USD"),
      evaluatePromo(promo({ startsAt: "2026-12-01T00:00:00Z" }), now, "USD", "USD"),
      evaluatePromo(promo({ maxUses: 5, usedCount: 5 }), now, "USD", "USD"),
      evaluatePromo(null, now, "USD", "USD"),
    ];
    msgs.forEach((m) => expect(m).toEqual({ ok: false, reason: "This promo code is not valid" }));
    expect(evaluatePromo(promo(), now, "USD", "USD")).toEqual({ ok: true });
  });
  it("fixed-amount promos do not apply across currencies", () => {
    expect(evaluatePromo(promo({ type: "fixed", value: 500 }), now, "EUR", "USD").ok).toBe(false);
    expect(evaluatePromo(promo(), now, "EUR", "USD").ok).toBe(true);
  });
});

describe("uploads, labels, references", () => {
  it("detects real image types by content, not by name", () => {
    expect(sniffImage(Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0]))?.mime).toBe("image/png");
    expect(sniffImage(Uint8Array.from([0xff, 0xd8, 0xff, 0xe0]))?.mime).toBe("image/jpeg");
    expect(sniffImage(Buffer.from("RIFFxxxxWEBPVP8 "))?.mime).toBe("image/webp");
    expect(sniffImage(Buffer.from("<svg onload=alert(1)>"))).toBeNull();
    expect(sniffImage(Buffer.from("%PDF-1.4"))).toBeNull();
  });
  it("a submitted payment is never shown as Verified", () => {
    expect(applicantPaymentLabel("pending_verification", false)).toBe("Submitted");
    expect(applicantPaymentLabel("pending_verification", true)).toBe("Pending Verification");
    expect(applicantPaymentLabel("verified", true)).toBe("Verified");
    expect(applicantPaymentLabel("rejected", true)).toBe("Rejected");
    expect(applicantPaymentLabel("refund_pending", true)).toBe("Refund Pending");
    expect(applicantPaymentLabel("refunded", true)).toBe("Refunded");
  });
  it("reference numbers look right and do not repeat", () => {
    const refs = new Set(Array.from({ length: 500 }, generateReference));
    expect(refs.size).toBe(500);
    refs.forEach((r) => expect(r).toMatch(/^RF-[A-HJKMNP-Z2-9]{8}$/));
  });
});

describe("application form validation", () => {
  const valid = {
    paymentId: "uid_abcdef0123456789", fullName: "Sample Person", phone: "555-0100",
    property: { address: "1 Fictional St", rentCents: 150000, moveIn: "2026-12-01" },
    household: { adults: 1, children: 0, pets: [] },
    employment: { employer: "Fictional Co", title: "Analyst", monthlyIncomeCents: 400000 },
    rentalHistory: [], consent: { fcraDisclosure: true, screeningAuthorization: true },
  };
  it("accepts a valid application and rejects missing consent", () => {
    expect(ApplicationInput.safeParse(valid).success).toBe(true);
    expect(ApplicationInput.safeParse({ ...valid, consent: { fcraDisclosure: true, screeningAuthorization: false } }).success).toBe(false);
  });
  it("rejects malformed SSN, phone and dates", () => {
    expect(ApplicationInput.safeParse({ ...valid, ssn: "12-345" }).success).toBe(false);
    expect(ApplicationInput.safeParse({ ...valid, phone: "abc" }).success).toBe(false);
    expect(ApplicationInput.safeParse({ ...valid, property: { ...valid.property, moveIn: "soon" } }).success).toBe(false);
  });
});
