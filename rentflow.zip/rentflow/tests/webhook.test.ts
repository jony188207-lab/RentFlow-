import { describe, expect, it } from "vitest";
import { applyEvent, computeSignature, verifyWebhookSignature } from "@/lib/payments/webhook";

const secret = "s3cret";
const body = JSON.stringify({ id: "evt_1" });
const now = 1_700_000_000;
const header = (t = now, sig = computeSignature(body, t, secret)) => `t=${t},v1=${sig}`;

describe("webhook signature verification", () => {
  it("accepts a correctly signed, fresh request", () => {
    expect(verifyWebhookSignature(body, header(), secret, now)).toBe(true);
  });
  it("rejects missing header, wrong secret, tampered body, and bad format", () => {
    expect(verifyWebhookSignature(body, null, secret, now)).toBe(false);
    expect(verifyWebhookSignature(body, header(), "other", now)).toBe(false);
    expect(verifyWebhookSignature(body + " ", header(), secret, now)).toBe(false);
    expect(verifyWebhookSignature(body, "garbage", secret, now)).toBe(false);
  });
  it("rejects replays outside the tolerance window", () => {
    expect(verifyWebhookSignature(body, header(now - 1000), secret, now)).toBe(false);
  });
  it("rejects when no secret is configured", () => {
    expect(verifyWebhookSignature(body, header(now, computeSignature(body, now, "")), "", now)).toBe(false);
  });
});

describe("applyEvent", () => {
  const ev = (type: any, amountCents: number) => ({ id: "e", type, data: { providerRef: "r", amountCents, currency: "usd" } });
  it("marks succeeded only when the amount matches what we charged", () => {
    expect(applyEvent(ev("payment.succeeded", 3500), 3500)).toEqual({ status: "succeeded", amountMismatch: false });
    expect(applyEvent(ev("payment.succeeded", 100), 3500)).toEqual({ status: "pending", amountMismatch: true });
  });
  it("maps failures and refunds", () => {
    expect(applyEvent(ev("payment.failed", 3500), 3500).status).toBe("failed");
    expect(applyEvent(ev("payment.refunded", 3500), 3500).status).toBe("refunded");
  });
});
