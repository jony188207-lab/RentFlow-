import { randomBytes } from "node:crypto";
import { describe, expect, it } from "vitest";
import { decryptField, encryptField, maskLast4 } from "@/lib/crypto";

const key = randomBytes(32).toString("base64");

describe("field encryption", () => {
  it("round-trips and never stores plaintext", () => {
    const enc = encryptField("123-45-6789", key);
    expect(enc).not.toContain("6789");
    expect(decryptField(enc, key)).toBe("123-45-6789");
  });
  it("uses a fresh IV each time", () => {
    expect(encryptField("a", key)).not.toBe(encryptField("a", key));
  });
  it("fails with the wrong key or tampered data", () => {
    const enc = encryptField("secret", key);
    expect(() => decryptField(enc, randomBytes(32).toString("base64"))).toThrow();
    expect(() => decryptField(enc.slice(0, -2) + "AA", key)).toThrow();
  });
  it("masks all but last 4", () => {
    expect(maskLast4("123456789")).toBe("•••-••-6789");
  });
});
