// DEVELOPMENT ONLY seed data. Every record is clearly fictional and flagged isSample: true, so the
// admin dashboard keeps it separate from real data. Refuses to run in production.
//
// Usage:  SEED_CONFIRM=I_UNDERSTAND_THIS_IS_FAKE_DEV_DATA npm run seed
import { cert, initializeApp } from "firebase-admin/app";
import { FieldValue, Timestamp, getFirestore } from "firebase-admin/firestore";

if (process.env.NODE_ENV === "production") throw new Error("Refusing to seed in production.");
if (process.env.SEED_CONFIRM !== "I_UNDERSTAND_THIS_IS_FAKE_DEV_DATA") {
  throw new Error("Set SEED_CONFIRM=I_UNDERSTAND_THIS_IS_FAKE_DEV_DATA to seed a development project.");
}

initializeApp({
  credential: cert({
    projectId: process.env.FIREBASE_ADMIN_PROJECT_ID!,
    clientEmail: process.env.FIREBASE_ADMIN_CLIENT_EMAIL!,
    privateKey: process.env.FIREBASE_ADMIN_PRIVATE_KEY!.replace(/\\n/g, "\n"),
  }),
});
const db = getFirestore();
const daysAgo = (n: number) => Timestamp.fromDate(new Date(Date.now() - n * 86_400_000));
const STATUSES = ["new", "new", "pending", "approved", "rejected", "pending"] as const;

async function main() {
  const batch = db.batch();
  STATUSES.forEach((status, i) => {
    const n = i + 1;
    const id = `SAMPLE-APP-${n}`;
    const name = `Sample Applicant ${n}`;
    batch.set(db.collection("applications").doc(id), {
      applicantName: name,
      applicantNameLower: name.toLowerCase(),
      applicantEmail: `sample${n}@example.com`,
      applicantEmailLower: `sample${n}@example.com`,
      applicantPhone: "555-0100",
      status,
      publicStatus: status === "new" ? "received" : status === "pending" ? "in_review" : "decision_made",
      property: { address: `${100 + n} Fictional Street, Exampleville`, rentCents: 150_000 + n * 5_000, moveIn: "2026-12-01" },
      household: { adults: 1 + (n % 2), children: n % 3, pets: n % 2 ? [{ type: "cat" }] : [] },
      employment: { employer: "Fictional Corp", title: "Analyst", monthlyIncomeCents: 450_000 + n * 10_000, startDate: "2022-03-01" },
      rentalHistory: [{ address: "1 Previous Lane, Exampleville", landlord: "Sample Landlord", from: "2020-01", to: "2024-06", rentCents: 120_000, reason: "Relocation" }],
      consent: { fcraDisclosureAcceptedAt: daysAgo(n), authorizationAcceptedAt: daysAgo(n), version: "sample-v0" },
      isSample: true,
      createdAt: daysAgo(n),
      updatedAt: daysAgo(n),
    });
    const payId = `SAMPLE-PAY-${n}`;
    const paid = n % 3 !== 0;
    batch.set(db.collection("payments").doc(payId), {
      applicationId: id,
      amountCents: 3500,
      currency: "usd",
      status: paid ? "succeeded" : "pending",
      provider: "mock",
      providerRef: `mock_ref_${n}`,
      cardBrand: paid ? "visa" : null,
      cardLast4: paid ? "4242" : null, // fictional test value
      refundStatus: "none",
      needsReview: false,
      isSample: true,
      createdAt: daysAgo(n),
    });
    batch.set(db.collection("mockProviderLedger").doc(`mock_ref_${n}`), {
      status: paid ? "succeeded" : "pending", amountCents: 3500, currency: "usd",
      ...(paid ? { cardBrand: "visa", cardLast4: "4242" } : {}),
    });
  });
  batch.set(db.collection("screeningJobs").doc("SAMPLE-JOB-1"), {
    applicationId: "SAMPLE-APP-1", status: "queued", provider: null, attempts: 0, error: null,
    manualReview: { status: "none" }, isSample: true, createdAt: daysAgo(1), updatedAt: daysAgo(1),
  });
  batch.set(db.collection("screeningJobs").doc("SAMPLE-JOB-2"), {
    applicationId: "SAMPLE-APP-2", status: "failed", provider: "mock-demo", attempts: 1,
    error: { code: "demo_error", message: "Fictional demo failure" },
    manualReview: { status: "none" }, isSample: true, createdAt: daysAgo(2), updatedAt: daysAgo(2),
  });
  batch.set(db.collection("notifications").doc("SAMPLE-NOTE-1"), {
    type: "application.new", title: "New application received (sample)", message: "Application SAMPLE-APP-1 received.",
    link: "/admin/applications", read: false, isSample: true, createdAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();
  console.log("Seeded fictional sample data (isSample: true).");
}
main().catch((e) => { console.error(e instanceof Error ? e.message : "Seed failed"); process.exit(1); });
