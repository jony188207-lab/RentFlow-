# RentFlow

USA rental application and tenant screening platform (Next.js, TypeScript, Tailwind, Firebase, Vercel).

> **Status: foundation + admin panel + applicant flow + manual payment methods.** Written but **NOT yet built, type-checked or test-run** (the authoring environment could not install npm packages; only a syntax-only check passed). First run: `npm install && npm run typecheck && npm test && npm run build`, and fix whatever they report.
> **Not built / needs your accounts:** real payment-provider automation (Stripe webhook adapter etc.), real screening provider adapter, email sending, website traffic analytics, service-based pricing beyond one fee + optional per-method fixed amount.
>
> Legal pages and the consent wording are **templates, not legal advice**. Have an attorney review them (FCRA, state/local screening and application-fee laws) before accepting real applications.

## Requirements
- Node.js 20+
- A Firebase project (free tier is fine to start)

## 1. Firebase setup
1. Create a project at https://console.firebase.google.com.
2. **Authentication → Sign-in method:** enable **Email/Password** (admins sign in with a password so protected-area re-verification works).
3. **Firestore Database:** create a database (production mode).
4. **Project settings → General → Your apps:** add a Web app and copy its config values.
5. **Project settings → Service accounts → Generate new private key.** Keep the JSON file private; never commit it.
6. Deploy the rules: `npm i -g firebase-tools`, `firebase login`, `firebase init firestore` (point at `firestore.rules`), then `firebase deploy --only firestore:rules`.

## 2. Local development
```bash
npm install
cp .env.example .env.local     # then fill in the values
openssl rand -base64 32        # run twice: DATA_ENCRYPTION_KEY and PROTECTED_AREA_SECRET
npm run dev                    # http://localhost:3000
npm test                       # unit tests
```
Set `FIREBASE_ADMIN_PRIVATE_KEY` with literal `\n` sequences inside double quotes.

## 3. First administrator
1. Set `INITIAL_ADMIN_EMAIL` to your Gmail address.
2. In Firebase Console → Authentication → Users, add that email with a password, and make sure the email is **verified** (send/verify via the console or a sign-in flow). Unverified emails are always rejected.
3. Open `/admin` and sign in. The first successful sign-in creates your `super_admin` record (logged in `auditLogs`). Remove `INITIAL_ADMIN_EMAIL` afterwards if you want bootstrap disabled.

## 4. Vercel deployment
1. Push to GitHub and import the repo in Vercel.
2. Add every variable from `.env.example` under Project → Settings → Environment Variables (mark secrets as Sensitive).
3. Add your Vercel domain under Firebase Authentication → Settings → Authorized domains.
4. Keep `PAYMENTS_MODE=test` and `PAYMENTS_LIVE_ENABLED=false` until your payment provider account and eligibility are verified.

## Security model (summary)
- Admin APIs verify the Firebase ID token (with revocation check) and an active `admins/{uid}` record on every request (`src/lib/auth/admin-guard.ts`); hiding UI is never the control.
- Firestore rules deny browser access to applications, payments, reports, secrets; the server uses the Admin SDK.
- Protected information requires a separate password check (`/api/admin/protected/unlock`): 3 failures → authenticator code required + 15-minute lockout. Every attempt is audit-logged.
- Sensitive fields use AES-256-GCM (`src/lib/crypto.ts`).

## Integrations needing your own accounts
Payment provider (hosted checkout + webhooks), tenant-screening provider (CRA contract/API), email provider. None are faked; mock adapters will be test-only.

## Folder structure
```
src/app/            public pages, /admin, /api routes
src/components/     site + admin UI
src/lib/            firebase, auth (authorize, guard, protected-area), crypto, settings
tests/              vitest suites
firestore.rules     security rules
```

## Admin panel testing
```bash
npm run typecheck        # TypeScript
npm test                 # unit + API route tests (in-memory Firebase fake)
npm run test:rules       # Firestore rules tests (needs Firebase emulator via firebase-tools)
SEED_CONFIRM=I_UNDERSTAND_THIS_IS_FAKE_DEV_DATA npm run seed   # fictional sample data, dev only
```
Sample records carry `isSample: true`; the dashboard shows real and sample data separately.

## Authorizing admins
- First admin: set `INITIAL_ADMIN_EMAIL`, create that user in Firebase Auth with a **verified** email, sign in at `/admin`.
- More admins: Admin users → "Authorize an admin email" (super admin only). Access starts when they sign in with that verified email.
- Protected information needs an explicit per-admin grant; no role (even super admin) includes it by default.

## Cards
Card numbers and CVV/CVC are never stored or displayed (card-network rules and the hosted-checkout model). Payments show brand + last four only.

## Payment methods (manual, admin-controlled)
- Admin → **Payment methods** (super administrator only to change): Stripe, Cash App, Payoneer, PayPal, Chime and custom methods; enable/disable, name, instructions, link, identifier, QR upload, amount/currency, order, countries. Changes take effect from the database immediately.
- Provider rules are in `src/lib/paymentMethods.ts` (`PROVIDER_CAPABILITIES`): e.g. Chime has no link/QR; Payoneer has no QR. **Verify these against each provider's current docs** before relying on them.
- Flow: applicant signs in (verified email) → sees the fee and enabled methods → pays outside RentFlow → submits transaction reference + screenshot (`/api/applicant/payments`, status `pending_verification`) → submits the application (`/api/applicant/applications`) → an admin verifies in **Payment review**. A screenshot is never treated as payment success.
- Screenshots and QR images live in **private** Cloud Storage and are served only through audited API routes. `storage.rules` deny all client access.
- The server computes every price (fee, per-method amount, promo). Each payment keeps its own price snapshot; changing the fee never alters old payments.

## Storage and extra Firebase setup
1. Firebase Console → Storage → create a bucket; put its name in `FIREBASE_STORAGE_BUCKET`. Keep it private.
2. `firebase deploy --only firestore:rules,firestore:indexes,storage`
3. Firestore → TTL policies: add one on collection `rateLimits`, field `expiresAt`.
4. Vercel request bodies are limited (~4.5 MB), so uploads are capped at 4 MB.

## URLs
- Website: `/` · apply: `/apply` · status: `/status`
- Admin panel: `/admin`
