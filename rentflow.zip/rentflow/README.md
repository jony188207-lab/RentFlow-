# RentFlow

USA rental application and tenant screening platform (Next.js, TypeScript, Tailwind, Firebase, Vercel).

> **Status: foundation build.** Implemented: public site (except the application form), Firebase auth, server-side admin authorization, protected-area unlock with lockout, field encryption, Firestore rules, admin shell and dashboard counts, tests. Not yet built: rental application form + API, payments, screening queue, notifications, remaining admin modules, seed script. Admin sections not built show an honest "not implemented" placeholder.
>
> Legal pages are **templates, not legal advice**. Have an attorney review them (FCRA, state/local rental-screening and fee laws) before accepting real applications.

## Requirements
- Node.js 20+
- A Firebase project (free tier is fine to start)

## 1. Firebase setup
1. Create a project at https://console.firebase.google.com.
2. **Authentication → Sign-in method:** enable **Email/Password** (admins sign in with a password so protected-area re-verification works).
3. **Firestore Database:** create a database (production mode).
4. **Project settings → General → Your apps:** add a Web app and copy its config values.
5. **Project settings → Service accounts → Generate new private key.** Keep the JSON file private; never commit it.
6. Deploy the rules: `npm i -g firebase-tools`, `firebase login`, `firebase init firestore` (point at `firestore.rules`), then `firebase deploy --only firestore:rules`.

## 2. Local development
```bash
npm install
cp .env.example .env.local     # then fill in the values
openssl rand -base64 32        # run twice: DATA_ENCRYPTION_KEY and PROTECTED_AREA_SECRET
npm run dev                    # http://localhost:3000
npm test                       # unit tests
```
Set `FIREBASE_ADMIN_PRIVATE_KEY` with literal `\n` sequences inside double quotes.

## 3. First administrator
1. Set `INITIAL_ADMIN_EMAIL` to your Gmail address.
2. In Firebase Console → Authentication → Users, add that email with a password, and make sure the email is **verified** (send/verify via the console or a sign-in flow). Unverified emails are always rejected.
3. Open `/admin` and sign in. The first successful sign-in creates your `super_admin` record (logged in `auditLogs`). Remove `INITIAL_ADMIN_EMAIL` afterwards if you want bootstrap disabled.

## 4. Vercel deployment
1. Push to GitHub and import the repo in Vercel.
2. Add every variable from `.env.example` under Project → Settings → Environment Variables (mark secrets as Sensitive).
3. Add your Vercel domain under Firebase Authentication → Settings → Authorized domains.
4. Keep `PAYMENTS_MODE=test` and `PAYMENTS_LIVE_ENABLED=false` until your payment provider account and eligibility are verified.

## Security model (summary)
- Admin APIs verify the Firebase ID token (with revocation check) and an active `admins/{uid}` record on every request (`src/lib/auth/admin-guard.ts`); hiding UI is never the control.
- Firestore rules deny browser access to applications, payments, reports, secrets; the server uses the Admin SDK.
- Protected information requires a separate password check (`/api/admin/protected/unlock`): 3 failures → authenticator code required + 15-minute lockout. Every attempt is audit-logged.
- Sensitive fields use AES-256-GCM (`src/lib/crypto.ts`).

## Integrations needing your own accounts
Payment provider (hosted checkout + webhooks), tenant-screening provider (CRA contract/API), email provider. None are faked; mock adapters will be test-only.

## Folder structure
```
src/app/            public pages, /admin, /api routes
src/components/     site + admin UI
src/lib/            firebase, auth (authorize, guard, protected-area), crypto, settings
tests/              vitest suites
firestore.rules     security rules
```
