"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";
import { gbtn, ginput } from "./ui";

export const ADMIN_SECTIONS = [
  ["", "Dashboard", "applications.read"],
  ["applications", "Applications", "applications.read"],
  ["payments", "Payment review", "payments.read"],
  ["payment-methods", "Payment methods", "payments.read"],
  ["pricing", "Pricing & promos", "settings.read"],
  ["screening", "Screening", "screening.read"],
  ["protected", "Protected information", "protected.view"],
  ["notifications", "Notifications", "notifications.read"],
  ["admins", "Admin users", "admins.manage"],
  ["audit-logs", "Audit logs", "audit.read"],
  ["settings", "Settings", "settings.read"],
] as const;

export interface Me { uid: string; email: string; role: string; permissions: string[] }
export type ApiResult<T = any> = { ok: boolean; status: number; data: T };

interface Ctx {
  me: Me;
  /** Authenticated JSON call to our own API; never throws, returns {ok,status,data}. */
  api: <T = any>(path: string, init?: { method?: string; body?: unknown; headers?: Record<string, string> }) => Promise<ApiResult<T>>;
  /** Authenticated raw fetch (for file downloads). */
  rawFetch: (path: string, init?: RequestInit) => Promise<Response>;
  can: (permission: string) => boolean;
}
const AdminCtx = createContext<Ctx | null>(null);
export const useAdmin = () => {
  const v = useContext(AdminCtx);
  if (!v) throw new Error("useAdmin outside AdminShell");
  return v;
};

export function AdminShell({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [navOpen, setNavOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => onAuthStateChanged(firebaseAuth(), setUser), []);
  useEffect(() => setNavOpen(false), [pathname]);

  useEffect(() => {
    if (!user) { setMe(null); return; }
    (async () => {
      const token = await user.getIdToken();
      const res = await fetch("/api/admin/me", { headers: { authorization: `Bearer ${token}` } });
      if (!res.ok) { setError((await res.json().catch(() => ({}))).error ?? "Not authorized"); return; }
      setMe(await res.json());
      // Record the login once per browser session (server-side audit).
      try {
        if (!sessionStorage.getItem("rf_login_logged")) {
          await fetch("/api/admin/session", { method: "POST", headers: { authorization: `Bearer ${token}` } });
          sessionStorage.setItem("rf_login_logged", "1");
        }
      } catch { /* storage unavailable: skip */ }
    })();
  }, [user]);

  const rawFetch = useCallback(
    async (path: string, init: RequestInit = {}) => {
      const token = await user!.getIdToken();
      return fetch(path, { ...init, headers: { ...(init.headers as Record<string, string>), authorization: `Bearer ${token}` } });
    },
    [user],
  );

  const api = useCallback<Ctx["api"]>(
    async (path, init = {}) => {
      try {
        const res = await rawFetch(path, {
          method: init.method ?? "GET",
          headers: { ...(init.body ? { "content-type": "application/json" } : {}), ...init.headers },
          body: init.body ? JSON.stringify(init.body) : undefined,
        });
        const data = await res.json().catch(() => ({}));
        return { ok: res.ok, status: res.status, data };
      } catch {
        return { ok: false, status: 0, data: { error: "Network error" } };
      }
    },
    [rawFetch],
  );

  async function login(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const f = new FormData(e.currentTarget);
    try {
      await signInWithEmailAndPassword(firebaseAuth(), String(f.get("email")), String(f.get("password")));
    } catch {
      setError("Sign-in failed. Check your email and password.");
    }
  }

  async function logout() {
    // Server revokes refresh tokens + audits; then clear the local session.
    if (user) await rawFetch("/api/admin/session", { method: "DELETE" }).catch(() => undefined);
    try { sessionStorage.removeItem("rf_login_logged"); } catch { /* ignore */ }
    await signOut(firebaseAuth());
    setError(null);
  }

  if (user === undefined)
    return <div className="flex min-h-[50vh] items-center justify-center" role="status">Loading…</div>;

  if (!user)
    return (
      <form onSubmit={login} className="mx-auto mt-10 w-full max-w-sm space-y-4 rounded-2xl border border-forest-100 bg-white p-6 shadow-sm">
        <h1 className="text-xl font-bold text-forest-900">Admin sign-in</h1>
        <div><label className="mb-1 block text-sm font-medium" htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="username" required className={ginput} /></div>
        <div><label className="mb-1 block text-sm font-medium" htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete="current-password" required className={ginput} /></div>
        {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
        <button className={`${gbtn} w-full`}>Sign in</button>
        <p className="text-xs text-slate-500">Access is limited to explicitly authorized administrators.</p>
      </form>
    );

  if (!me)
    return (
      <div className="mx-auto mt-10 max-w-sm space-y-3 rounded-2xl border border-forest-100 bg-white p-6 text-sm shadow-sm">
        <p role={error ? "alert" : "status"}>{error ?? "Checking authorization…"}</p>
        <button className="rounded-lg border px-3 py-2 font-semibold" onClick={logout}>Sign out</button>
      </div>
    );

  const can = (p: string) => me.permissions.includes(p);
  const links = ADMIN_SECTIONS.filter(([, , perm]) => can(perm));
  const nav = (
    <nav aria-label="Admin" className="flex h-full flex-col">
      <div className="mb-4 px-2">
        <p className="text-lg font-bold text-white">RentFlow</p>
        <p className="truncate text-xs text-forest-200">{me.email}</p>
        <p className="text-xs uppercase tracking-wide text-forest-200">{me.role.replace("_", " ")}</p>
      </div>
      <ul className="flex-1 space-y-1">
        {links.map(([slug, label]) => {
          const href = `/admin${slug ? `/${slug}` : ""}`;
          const active = slug === "" ? pathname === "/admin" : pathname.startsWith(href);
          return (
            <li key={slug}>
              <Link href={href} aria-current={active ? "page" : undefined} className={`block rounded-lg px-3 py-2 text-sm ${active ? "bg-white text-forest-900 font-semibold" : "text-forest-100 hover:bg-forest-800"}`}>
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
      <button onClick={logout} className="mt-4 rounded-lg border border-forest-600 px-3 py-2 text-sm text-white hover:bg-forest-800">Sign out</button>
    </nav>
  );

  return (
    <AdminCtx.Provider value={{ me, api, rawFetch, can }}>
      {/* Admin breaks out of the public layout's max width */}
      <div className="-mx-4 -my-8 min-h-screen bg-forest-50 md:flex">
        <header className="flex items-center justify-between bg-forest-900 px-4 py-3 text-white md:hidden">
          <span className="font-bold">RentFlow Admin</span>
          <button onClick={() => setNavOpen(true)} aria-label="Open menu" aria-expanded={navOpen} className="rounded border border-forest-600 px-3 py-1 text-sm">Menu</button>
        </header>
        <aside className="hidden w-60 shrink-0 bg-forest-900 p-4 md:block">{nav}</aside>
        {navOpen && (
          <div className="fixed inset-0 z-40 md:hidden" role="dialog" aria-modal="true" aria-label="Menu">
            <div className="absolute inset-0 bg-black/50" onClick={() => setNavOpen(false)} />
            <aside className="absolute inset-y-0 left-0 w-64 bg-forest-900 p-4">{nav}</aside>
          </div>
        )}
        <section className="min-w-0 flex-1 p-4 sm:p-6">{children}</section>
      </div>
    </AdminCtx.Provider>
  );
}
