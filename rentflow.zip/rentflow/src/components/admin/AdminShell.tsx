"use client";
import Link from "next/link";
import { createContext, useContext, useEffect, useState } from "react";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";

export const ADMIN_SECTIONS = [
  ["", "Dashboard"],
  ["applications", "Applications"],
  ["payments", "Payments"],
  ["screening", "Screening jobs"],
  ["reports", "Report status"],
  ["protected", "Protected information"],
  ["bot-logs", "Bot & error logs"],
  ["manual-review", "Manual review"],
  ["pricing", "Pricing settings"],
  ["providers", "Providers"],
  ["notifications", "Notifications"],
  ["admins", "Admin users"],
  ["audit-logs", "Audit logs"],
  ["security", "Security"],
] as const;

interface Me { uid: string; email: string; role: string }
const Ctx = createContext<{ me: Me; api: (path: string, init?: RequestInit) => Promise<Response> } | null>(null);
export const useAdmin = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAdmin outside AdminShell");
  return v;
};

export function AdminShell({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => onAuthStateChanged(firebaseAuth(), setUser), []);

  useEffect(() => {
    if (!user) return setMe(null);
    (async () => {
      const token = await user.getIdToken();
      const res = await fetch("/api/admin/me", { headers: { authorization: `Bearer ${token}` } });
      if (res.ok) setMe(await res.json());
      else setError((await res.json().catch(() => ({}))).error ?? "Not authorized");
    })();
  }, [user]);

  async function login(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const f = new FormData(e.currentTarget);
    try {
      await signInWithEmailAndPassword(firebaseAuth(), String(f.get("email")), String(f.get("password")));
    } catch {
      setError("Sign-in failed");
    }
  }

  if (user === undefined) return <p className="p-6 text-sm">Loading…</p>;

  if (!user)
    return (
      <form onSubmit={login} className="card mx-auto mt-10 max-w-sm space-y-4">
        <h1 className="text-xl font-bold">Admin sign-in</h1>
        <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" required className="input" /></div>
        <div><label className="label" htmlFor="password">Password</label><input id="password" name="password" type="password" required className="input" /></div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button className="btn-primary w-full">Sign in</button>
      </form>
    );

  if (!me)
    return (
      <div className="card mx-auto mt-10 max-w-sm space-y-3">
        <p className="text-sm">{error ?? "Checking authorization…"}</p>
        <button className="btn-secondary" onClick={() => signOut(firebaseAuth())}>Sign out</button>
      </div>
    );

  const api = async (path: string, init: RequestInit = {}) =>
    fetch(path, { ...init, headers: { ...init.headers, authorization: `Bearer ${await user.getIdToken()}` } });

  return (
    <Ctx.Provider value={{ me, api }}>
      <div className="flex flex-col gap-6 md:flex-row">
        <nav className="md:w-56 md:shrink-0">
          <p className="mb-2 text-xs text-slate-500">{me.email} · {me.role}</p>
          <ul className="flex gap-2 overflow-x-auto md:flex-col md:gap-1">
            {ADMIN_SECTIONS.map(([slug, label]) => (
              <li key={slug}>
                <Link href={`/admin/${slug}`} className="block whitespace-nowrap rounded px-3 py-1.5 text-sm hover:bg-brand-50">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
          <button className="btn-secondary mt-4 w-full" onClick={() => signOut(firebaseAuth())}>Sign out</button>
        </nav>
        <section className="min-w-0 flex-1">{children}</section>
      </div>
    </Ctx.Provider>
  );
}
