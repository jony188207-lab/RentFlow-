"use client";
import { useCallback, useEffect, useState } from "react";
import { useAdmin } from "./AdminShell";

/** Loads JSON from an admin API path; refetches when the path changes or reload() is called. */
export function useLoad<T = any>(path: string | null) {
  const { api } = useAdmin();
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(Boolean(path));
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!path) return;
    let live = true;
    setLoading(true);
    api<T>(path).then((r) => {
      if (!live) return;
      if (r.ok) { setData(r.data); setError(null); }
      else setError((r.data as any)?.error ?? "Request failed");
      setLoading(false);
    });
    return () => { live = false; };
  }, [path, tick, api]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { data, error, loading, reload };
}
