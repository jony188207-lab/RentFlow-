"use client";
import { useEffect, useRef, useState } from "react";

export const usd = (cents: number | null | undefined) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format((cents ?? 0) / 100);

export const fmtDate = (iso?: string | null) =>
  iso ? new Date(iso).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";

const TONE: Record<string, string> = {
  new: "bg-blue-100 text-blue-800",
  pending: "bg-amber-100 text-amber-800",
  approved: "bg-forest-100 text-forest-800",
  rejected: "bg-red-100 text-red-800",
  withdrawn: "bg-slate-200 text-slate-700",
  succeeded: "bg-forest-100 text-forest-800",
  failed: "bg-red-100 text-red-800",
  refunded: "bg-purple-100 text-purple-800",
  partially_refunded: "bg-purple-100 text-purple-800",
  queued: "bg-slate-200 text-slate-700",
  running: "bg-blue-100 text-blue-800",
  action_required: "bg-orange-100 text-orange-800",
  provider_processing: "bg-blue-100 text-blue-800",
  completed: "bg-forest-100 text-forest-800",
  manual_review: "bg-amber-100 text-amber-800",
  resolved: "bg-forest-100 text-forest-800",
  pending_verification: "bg-amber-100 text-amber-800",
  verified: "bg-forest-100 text-forest-800",
  refund_pending: "bg-purple-100 text-purple-800",
};

export function Badge({ value }: { value: string }) {
  return (
    <span className={`inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ${TONE[value] ?? "bg-slate-100 text-slate-700"}`}>
      {value.replace(/_/g, " ")}
    </span>
  );
}

export function SampleTag() {
  return <span className="ml-1 rounded bg-fuchsia-100 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-fuchsia-800">sample</span>;
}

export function PageHeader({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
      <h1 className="text-xl font-bold text-forest-900 sm:text-2xl">{title}</h1>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

export const Panel = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <div className={`rounded-xl border border-forest-100 bg-white p-4 shadow-sm ${className}`}>{children}</div>
);

export const Spinner = () => (
  <div role="status" aria-label="Loading" className="flex justify-center p-8">
    <div className="h-6 w-6 animate-spin rounded-full border-2 border-forest-200 border-t-forest-600" />
  </div>
);

export const Empty = ({ text }: { text: string }) => (
  <div className="rounded-xl border border-dashed border-forest-200 bg-white p-8 text-center text-sm text-slate-500">{text}</div>
);

export const ErrorBox = ({ text }: { text: string | null }) =>
  text ? <div role="alert" className="mb-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">{text}</div> : null;

export const gbtn = "inline-flex items-center justify-center rounded-lg bg-forest-700 px-3 py-2 text-sm font-semibold text-white hover:bg-forest-800 focus:outline-none focus:ring-2 focus:ring-forest-500 focus:ring-offset-2 disabled:opacity-50";
export const gbtn2 = "inline-flex items-center justify-center rounded-lg border border-forest-200 bg-white px-3 py-2 text-sm font-semibold text-forest-900 hover:bg-forest-50 focus:outline-none focus:ring-2 focus:ring-forest-500 disabled:opacity-50";
export const dbtn = "inline-flex items-center justify-center rounded-lg bg-red-700 px-3 py-2 text-sm font-semibold text-white hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-50";
export const ginput = "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-forest-500 focus:outline-none focus:ring-2 focus:ring-forest-200";

/** Accessible modal used for confirmations and detail views. Closes on Escape. */
export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    ref.current?.focus();
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4" onClick={onClose}>
      <div
        ref={ref}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className={`max-h-[90vh] w-full overflow-y-auto rounded-t-2xl bg-white p-5 shadow-xl sm:rounded-2xl ${wide ? "sm:max-w-3xl" : "sm:max-w-md"}`}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <h2 className="text-lg font-bold text-forest-900">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded p-1 text-slate-500 hover:bg-slate-100">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog(props: {
  title: string;
  message: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void | Promise<void>;
  onCancel: () => void;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <Modal title={props.title} onClose={props.onCancel}>
      <p className="text-sm text-slate-700">{props.message}</p>
      <div className="mt-4 flex justify-end gap-2">
        <button className={gbtn2} onClick={props.onCancel}>Cancel</button>
        <button
          className={props.danger ? dbtn : gbtn}
          disabled={busy}
          onClick={async () => { setBusy(true); try { await props.onConfirm(); } finally { setBusy(false); } }}
        >
          {busy ? "Working…" : props.confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

/** Horizontally scrollable table wrapper so wide tables stay usable on phones. */
export const TableWrap = ({ children }: { children: React.ReactNode }) => (
  <div className="overflow-x-auto rounded-xl border border-forest-100 bg-white shadow-sm">
    <table className="min-w-full divide-y divide-forest-100 text-sm">{children}</table>
  </div>
);
export const Th = ({ children }: { children?: React.ReactNode }) => (
  <th className="whitespace-nowrap bg-forest-50 px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-forest-800">{children}</th>
);
export const Td = ({ children, className = "" }: { children?: React.ReactNode; className?: string }) => (
  <td className={`px-3 py-2 align-top ${className}`}>{children}</td>
);

export const DataToggle = ({ value, onChange }: { value: "real" | "sample"; onChange: (v: "real" | "sample") => void }) => (
  <div className="inline-flex overflow-hidden rounded-lg border border-forest-200 text-sm" role="group" aria-label="Data source">
    {(["real", "sample"] as const).map((v) => (
      <button key={v} onClick={() => onChange(v)} aria-pressed={value === v} className={`px-3 py-1.5 ${value === v ? "bg-forest-700 text-white" : "bg-white text-forest-900 hover:bg-forest-50"}`}>
        {v === "real" ? "Real data" : "Sample data"}
      </button>
    ))}
  </div>
);
