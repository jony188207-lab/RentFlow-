export function LegalNotice() {
  return (
    <div className="mb-6 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
      <strong>Template notice:</strong> this text is a starting template and has not been reviewed by an attorney. It
      must be reviewed and adapted (including FCRA and state/local rental-screening requirements) before you accept real
      applications. Operators can replace it from the admin panel once document management is enabled.
    </div>
  );
}
