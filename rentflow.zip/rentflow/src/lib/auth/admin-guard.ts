// Server-only: verifies the Firebase ID token and enforces admin authorization.
import { NextResponse } from "next/server";
import { adminAuth, adminDb } from "@/lib/firebase/admin";
import { serverEnv } from "@/lib/env";
import { authorizeAdmin, hasRole, type AdminRecord, type AdminRole } from "./authorize";

export interface AdminContext {
  uid: string;
  email: string;
  role: AdminRole;
}

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

function bearer(req: Request): string | null {
  const h = req.headers.get("authorization");
  return h?.startsWith("Bearer ") ? h.slice(7) : null;
}

export async function requireAdmin(req: Request, minimum: AdminRole = "viewer"): Promise<AdminContext> {
  const token = bearer(req);
  if (!token) throw new HttpError(401, "Not authenticated");

  let decoded;
  try {
    // checkRevoked=true so disabled/revoked sessions stop working immediately.
    decoded = await adminAuth().verifyIdToken(token, true);
  } catch {
    throw new HttpError(401, "Invalid or expired token");
  }

  const db = adminDb();
  const snap = await db.collection("admins").doc(decoded.uid).get();
  const record = snap.exists ? (snap.data() as AdminRecord) : null;
  const result = authorizeAdmin(decoded, record, serverEnv.initialAdminEmail);
  if (!result.ok) throw new HttpError(result.status, result.reason);

  if (result.bootstrap) {
    await db.collection("admins").doc(decoded.uid).set({
      email: decoded.email,
      role: "super_admin",
      active: true,
      createdAt: new Date().toISOString(),
      createdBy: "bootstrap:INITIAL_ADMIN_EMAIL",
    });
    await db.collection("auditLogs").add({
      at: new Date().toISOString(),
      actorUid: decoded.uid,
      action: "admin.bootstrap",
    });
  }

  if (!hasRole(result.role, minimum)) throw new HttpError(403, "Insufficient role");
  return { uid: decoded.uid, email: decoded.email!, role: result.role };
}

export function errorResponse(e: unknown) {
  if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
  console.error("Unhandled API error"); // never log request bodies or secrets
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
