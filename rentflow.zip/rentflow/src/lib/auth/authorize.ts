// Pure authorization decisions (no I/O) so they can be unit-tested.

export type AdminRole = "super_admin" | "admin" | "reviewer" | "viewer";

export interface DecodedIdentity {
  uid: string;
  email?: string;
  email_verified?: boolean;
}

export interface AdminRecord {
  role: AdminRole;
  active: boolean;
  canViewProtected?: boolean;
}

export type AuthzResult =
  | { ok: true; role: AdminRole; bootstrap: boolean }
  | { ok: false; status: 401 | 403; reason: string };

/**
 * Decide whether an identity may use admin APIs.
 * - Email must be verified.
 * - Access requires an active admins/{uid} record, OR the identity is the
 *   explicitly configured INITIAL_ADMIN_EMAIL (bootstraps a super_admin).
 */
export function authorizeAdmin(
  identity: DecodedIdentity | null,
  record: AdminRecord | null,
  initialAdminEmail: string,
): AuthzResult {
  if (!identity) return { ok: false, status: 401, reason: "Not authenticated" };
  if (!identity.email || identity.email_verified !== true) {
    return { ok: false, status: 403, reason: "Verified email required" };
  }
  if (record) {
    if (!record.active) return { ok: false, status: 403, reason: "Administrator disabled" };
    return { ok: true, role: record.role, bootstrap: false };
  }
  const configured = initialAdminEmail.trim().toLowerCase();
  if (configured && identity.email.toLowerCase() === configured) {
    return { ok: true, role: "super_admin", bootstrap: true };
  }
  return { ok: false, status: 403, reason: "Not an administrator" };
}

const RANK: Record<AdminRole, number> = { viewer: 1, reviewer: 2, admin: 3, super_admin: 4 };

export function hasRole(actual: AdminRole, minimum: AdminRole): boolean {
  return RANK[actual] >= RANK[minimum];
}
