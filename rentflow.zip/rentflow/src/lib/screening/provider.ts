// Screening provider adapter interface. Real adapters require a contract with an authorized
// consumer reporting agency (CRA) and must use its official API (or browser automation ONLY if the
// provider explicitly authorizes it). Adapters must never bypass CAPTCHAs or access controls.
import { HttpError } from "@/lib/http";

export type ProviderPollResult =
  | { state: "processing" }
  | { state: "action_required"; reason: string }
  | { state: "failed"; code: string; message: string }
  | {
      state: "completed";
      /** True ONLY when the provider itself returned a verified result. */
      verified: boolean;
      /** Provider's report payload; stored encrypted, never logged. */
      payload: Record<string, unknown>;
    };

export interface ScreeningProvider {
  readonly name: string;
  submit(input: { applicationId: string }): Promise<{ providerRef: string }>;
  poll(providerRef: string): Promise<ProviderPollResult>;
}

/**
 * DEVELOPMENT ONLY. Produces clearly-labeled fictional data and NEVER reports `verified: true`,
 * so a demo job can only ever land in manual review, never "completed".
 */
class MockScreeningProvider implements ScreeningProvider {
  readonly name = "mock-demo";
  async submit({ applicationId }: { applicationId: string }) {
    return { providerRef: `demo_${applicationId}` };
  }
  async poll(): Promise<ProviderPollResult> {
    return { state: "completed", verified: false, payload: { demo: true, notice: "FICTIONAL DEMO DATA. Not a real screening result." } };
  }
}

class UnconnectedProvider implements ScreeningProvider {
  constructor(readonly name: string) {}
  async submit(): Promise<never> {
    throw new HttpError(501, `Screening provider "${this.name}" is not connected. Implement src/lib/screening/ adapter.`);
  }
  async poll(): Promise<never> {
    throw new HttpError(501, `Screening provider "${this.name}" is not connected.`);
  }
}

export function getScreeningProvider(): ScreeningProvider {
  const name = process.env.SCREENING_PROVIDER ?? "mock";
  if (name === "mock") {
    if (process.env.NODE_ENV === "production") throw new HttpError(503, "The demo screening provider is disabled in production.");
    return new MockScreeningProvider();
  }
  return new UnconnectedProvider(name);
}
