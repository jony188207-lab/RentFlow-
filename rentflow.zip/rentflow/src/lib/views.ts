// Response shaping for admin APIs. Whitelists fields so sensitive data cannot leak by accident.
import { serialize } from "@/lib/serialize";

// Never returns card data beyond brand + last four digits (and only if the provider supplied them).
export const paymentView = (d: FirebaseFirestore.DocumentSnapshot) => {
  const x = d.data()!;
  return serialize({
    id: d.id,
    applicationId: x.applicationId,
    amountCents: x.amountCents,
    currency: x.currency ?? "usd",
    status: x.status,
    provider: x.provider,
    providerRef: x.providerRef ?? null,
    source: x.source ?? "provider",
    methodName: x.methodName ?? null,
    transactionRef: x.transactionRef ?? null,
    hasProof: Boolean(x.proofPath),
    promoCode: x.promoCode ?? null,
    baseCents: x.baseCents ?? null,
    discountCents: x.discountCents ?? 0,
    cardBrand: x.cardBrand ?? null,
    cardLast4: x.cardLast4 ?? null,
    refundStatus: x.refundStatus ?? "none",
    needsReview: x.needsReview === true,
    createdAt: x.createdAt,
    updatedAt: x.updatedAt ?? null,
    isSample: x.isSample === true,
  });
};

export const jobView = (d: FirebaseFirestore.DocumentSnapshot) => {
  const x = d.data()!;
  return serialize({
    id: d.id,
    applicationId: x.applicationId,
    provider: x.provider ?? null,
    status: x.status,
    attempts: x.attempts ?? 0,
    createdAt: x.createdAt,
    updatedAt: x.updatedAt ?? null,
    error: x.error ?? null,
    manualReview: x.manualReview ?? { status: "none" },
    isSample: x.isSample === true,
  });
};
