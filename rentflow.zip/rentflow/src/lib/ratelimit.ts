// Fixed-window rate limiting backed by Firestore (works across serverless instances).
// Add a Firestore TTL policy on `rateLimits.expiresAt` so old counters are cleaned up automatically.
import { createHash } from "node:crypto";
import { adminDb } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/http";

export async function rateLimit(scope: string, id: string | undefined, limit: number, windowSec: number): Promise<void> {
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const key = `${createHash("sha256").update(`${scope}:${id ?? "unknown"}`).digest("hex").slice(0, 40)}_${bucket}`;
  const db = adminDb();
  const ref = db.collection("rateLimits").doc(key);
  const count = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const next = ((snap.data()?.count as number | undefined) ?? 0) + 1;
    tx.set(ref, { count: next, scope, expiresAt: new Date((bucket + 2) * windowSec * 1000) });
    return next;
  });
  if (count > limit) throw new HttpError(429, "Too many requests. Please try again later.");
}
