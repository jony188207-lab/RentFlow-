// AES-256-GCM field encryption for sensitive data (e.g. SSN, report payloads).
// Output format: v1:<iv b64>:<tag b64>:<ciphertext b64>
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

function keyFrom(base64Key: string): Buffer {
  const key = Buffer.from(base64Key, "base64");
  if (key.length !== 32) throw new Error("DATA_ENCRYPTION_KEY must be 32 bytes, base64-encoded.");
  return key;
}

export function encryptField(plain: string, base64Key = process.env.DATA_ENCRYPTION_KEY ?? ""): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", keyFrom(base64Key), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return ["v1", iv.toString("base64"), tag.toString("base64"), enc.toString("base64")].join(":");
}

export function decryptField(payload: string, base64Key = process.env.DATA_ENCRYPTION_KEY ?? ""): string {
  const [version, iv, tag, data] = payload.split(":");
  if (version !== "v1" || !iv || !tag || !data) throw new Error("Unsupported ciphertext format.");
  const decipher = createDecipheriv("aes-256-gcm", keyFrom(base64Key), Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(data, "base64")), decipher.final()]).toString("utf8");
}

/** Show only the last 4 characters of a sensitive value. */
export function maskLast4(value: string): string {
  return value.length <= 4 ? "••••" : `•••-••-${value.slice(-4)}`;
}
