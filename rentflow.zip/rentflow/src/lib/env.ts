// Server-only environment access. Never import this file from client components.
function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required environment variable: ${name}`);
  return v;
}

export const serverEnv = {
  get initialAdminEmail(): string {
    return (process.env.INITIAL_ADMIN_EMAIL ?? "").trim().toLowerCase();
  },
  get dataEncryptionKey(): string {
    return required("DATA_ENCRYPTION_KEY");
  },
  get protectedAreaSecret(): string {
    return required("PROTECTED_AREA_SECRET");
  },
  get firebaseWebApiKey(): string {
    return required("NEXT_PUBLIC_FIREBASE_API_KEY");
  },
  get paymentsMode(): "test" | "live" {
    return process.env.PAYMENTS_MODE === "live" ? "live" : "test";
  },
  /** Live payments require BOTH mode=live and an explicit enable flag. */
  get livePaymentsAllowed(): boolean {
    return process.env.PAYMENTS_MODE === "live" && process.env.PAYMENTS_LIVE_ENABLED === "true";
  },
};
