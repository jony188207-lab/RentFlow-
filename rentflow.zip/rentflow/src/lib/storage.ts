// PRIVATE Cloud Storage access (Firebase Admin SDK only). The bucket must never be public and
// storage.rules deny all client access; files leave only through authorized API routes.
import { adminBucket } from "@/lib/firebase/admin";

export async function putPrivate(path: string, data: Buffer, contentType: string): Promise<void> {
  await adminBucket().file(path).save(data, {
    contentType,
    resumable: false,
    metadata: { cacheControl: "private, no-store" },
  });
}

export async function readPrivate(path: string): Promise<Buffer> {
  const [buf] = await adminBucket().file(path).download();
  return buf;
}

export async function deletePrivate(path: string): Promise<void> {
  await adminBucket().file(path).delete({ ignoreNotFound: true });
}
