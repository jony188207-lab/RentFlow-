// Pure pricing + promo logic. The amount a payment is expected to have is ALWAYS computed here,
// on the server, from admin settings. Amounts sent by a browser are never read.
export type PromoType = "percent" | "fixed";

export interface Promo {
  code: string;
  type: PromoType;
  /** percent: 1–99; fixed: cents in the BASE currency */
  value: number;
  active: boolean;
  startsAt?: string | null;
  endsAt?: string | null;
  maxUses?: number | null;
  usedCount: number;
}

export const normalizePromoCode = (s: string) => s.trim().toUpperCase();

export type PromoCheck = { ok: true } | { ok: false; reason: string };

export function evaluatePromo(promo: Promo | null | undefined, nowMs: number, currency: string, baseCurrency: string): PromoCheck {
  // One generic message for unknown/inactive/expired so codes cannot be probed.
  const invalid: PromoCheck = { ok: false, reason: "This promo code is not valid" };
  if (!promo || !promo.active) return invalid;
  if (promo.startsAt && Date.parse(promo.startsAt) > nowMs) return invalid;
  if (promo.endsAt && Date.parse(promo.endsAt) < nowMs) return invalid;
  if (promo.maxUses != null && promo.usedCount >= promo.maxUses) return invalid;
  if (promo.type === "fixed" && currency !== baseCurrency)
    return { ok: false, reason: "This promo code cannot be used with the selected payment method's currency" };
  return { ok: true };
}

export interface Quote { baseCents: number; discountCents: number; totalCents: number }

export function computeQuote(baseCents: number, promo: Promo | null): Quote {
  let discount = 0;
  if (promo) discount = promo.type === "percent" ? Math.round((baseCents * promo.value) / 100) : promo.value;
  discount = Math.max(0, Math.min(discount, baseCents));
  return { baseCents, discountCents: discount, totalCents: baseCents - discount };
}
