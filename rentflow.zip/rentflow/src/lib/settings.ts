// Reads public, non-sensitive settings. Falls back to safe defaults if Firebase isn't configured yet
// (so the public site still renders during first-time local setup).
import { adminDb } from "@/lib/firebase/admin";

export interface PublicPricing {
  totalFeeCents: number;
  currency: "usd";
  isDefault: boolean;
}

export const DEFAULT_FEE_CENTS = 3500; // development default only; set the real fee in Admin > Pricing

export async function getPublicPricing(): Promise<PublicPricing> {
  try {
    const snap = await adminDb().collection("publicSettings").doc("pricing").get();
    const cents = snap.data()?.totalFeeCents;
    if (typeof cents === "number" && cents >= 0) return { totalFeeCents: cents, currency: "usd", isDefault: false };
  } catch {
    /* Firebase not configured or unreachable: use default */
  }
  return { totalFeeCents: DEFAULT_FEE_CENTS, currency: "usd", isDefault: true };
}

export const formatUsd = (cents: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);
