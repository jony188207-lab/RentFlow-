import Link from "next/link";

const features = [
  { t: "Clear disclosures", d: "You see exactly what is collected, why, and who receives it before you consent." },
  { t: "Secure by design", d: "Sensitive details are encrypted and only visible to authorized reviewers." },
  { t: "Human review", d: "Screening results are reviewed by a person. No one is rejected automatically." },
  { t: "Track your application", d: "Use your application ID and email to check progress any time." },
];

export default function Home() {
  return (
    <div className="space-y-12">
      <section className="rounded-2xl bg-brand-900 px-6 py-14 text-white">
        <h1 className="max-w-2xl text-3xl font-bold sm:text-4xl">Rental applications that are simple, secure, and fair.</h1>
        <p className="mt-4 max-w-2xl text-brand-100">
          Submit one application, pay a single transparent fee, and follow your status online.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/apply" className="btn bg-white text-brand-900 hover:bg-brand-50">
            Start application
          </Link>
          <Link href="/how-it-works" className="btn border border-white/40 text-white hover:bg-white/10">
            How it works
          </Link>
        </div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2">
        {features.map((f) => (
          <div key={f.t} className="card">
            <h2 className="font-semibold">{f.t}</h2>
            <p className="mt-1 text-sm text-slate-600">{f.d}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
