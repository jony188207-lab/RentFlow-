import { NextResponse } from "next/server";
import { AggregateField } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

async function metrics(isSample: boolean) {
  const db = adminDb();
  const cnt = async (col: string, field?: string, value?: string) => {
    let q = db.collection(col).where("isSample", "==", isSample);
    if (field) q = q.where(field, "==", value);
    return (await q.count().get()).data().count;
  };
  const paid = db.collection("payments").where("isSample", "==", isSample).where("status", "in", ["succeeded", "verified"]);
  const [total, nw, pending, approved, rejected, pSucc, pPend, jobs, jDone, jFail, jManual, sum] = await Promise.all([
    cnt("applications"),
    cnt("applications", "status", "new"),
    cnt("applications", "status", "pending"),
    cnt("applications", "status", "approved"),
    cnt("applications", "status", "rejected"),
    db.collection("payments").where("isSample", "==", isSample).where("status", "in", ["succeeded", "verified"]).count().get().then((x) => x.data().count),
    db.collection("payments").where("isSample", "==", isSample).where("status", "in", ["pending", "pending_verification"]).count().get().then((x) => x.data().count),
    cnt("screeningJobs"),
    cnt("screeningJobs", "status", "completed"),
    cnt("screeningJobs", "status", "failed"),
    cnt("screeningJobs", "status", "manual_review"),
    paid.aggregate({ total: AggregateField.sum("amountCents") }).get(),
  ]);
  return {
    applications: { total, new: nw, pending, approved, rejected },
    payments: { totalAmountCents: sum.data().total ?? 0, successful: pSucc, pending: pPend },
    screening: { total: jobs, completed: jDone, failed: jFail, manualReview: jManual },
  };
}

// 14-day series (real data only) bucketed by UTC day.
async function series() {
  const db = adminDb();
  const since = new Date(Date.now() - 13 * 86_400_000);
  since.setUTCHours(0, 0, 0, 0);
  const [apps, pays] = await Promise.all([
    db.collection("applications").where("isSample", "==", false).where("createdAt", ">=", since).select("createdAt").limit(2000).get(),
    db.collection("payments").where("isSample", "==", false).where("createdAt", ">=", since).select("createdAt", "amountCents", "status").limit(2000).get(),
  ]);
  const days = Array.from({ length: 14 }, (_, i) => new Date(since.getTime() + i * 86_400_000).toISOString().slice(0, 10));
  const out = days.map((day) => ({ day, applications: 0, paymentsCents: 0 }));
  const idx = (d: Date) => days.indexOf(d.toISOString().slice(0, 10));
  apps.forEach((d) => { const i = idx(d.get("createdAt").toDate()); if (i >= 0) out[i]!.applications++; });
  pays.forEach((d) => {
    if (!["succeeded", "verified"].includes(d.get("status"))) return;
    const i = idx(d.get("createdAt").toDate());
    if (i >= 0) out[i]!.paymentsCents += d.get("amountCents") ?? 0;
  });
  return out;
}

// Aggregate numbers only: no applicant data leaves this endpoint.
export async function GET(req: Request) {
  try {
    await requirePermission(req, "applications.read");
    const [real, sample, daily, recent] = await Promise.all([
      metrics(false),
      metrics(true),
      series(),
      adminDb().collection("auditLogs").orderBy("at", "desc").limit(10).get(),
    ]);
    return NextResponse.json({
      real,
      sample, // clearly separate: development-only fictional records (isSample: true)
      daily,
      recentActivity: recent.docs.map((d) => {
        const x = d.data();
        return serialize({ id: d.id, at: x.at, action: x.action, actorEmail: x.actorEmail, targetType: x.targetType, targetId: x.targetId });
      }),
    });
  } catch (e) {
    return errorResponse(e);
  }
}
