import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requireAdmin } from "@/lib/auth/admin-guard";

export const dynamic = "force-dynamic";

// Aggregate counts only: no applicant data leaves this endpoint.
export async function GET(req: Request) {
  try {
    await requireAdmin(req, "viewer");
    const db = adminDb();
    const count = async (name: string) => (await db.collection(name).count().get()).data().count;
    const [applications, payments, screeningJobs, manualReview] = await Promise.all([
      count("applications"),
      count("payments"),
      count("screeningJobs"),
      db.collection("screeningJobs").where("status", "==", "manual_review").count().get().then((s) => s.data().count),
    ]);
    return NextResponse.json({ applications, payments, screeningJobs, manualReview });
  } catch (e) {
    return errorResponse(e);
  }
}
