import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminAuth, adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

const Patch = z
  .object({
    role: z.enum(["admin", "reviewer", "viewer"]),
    active: z.boolean(),
    canViewProtected: z.boolean(),
  })
  .partial()
  .refine((v) => Object.keys(v).length > 0, "No changes provided");

export async function PATCH(req: Request, { params }: { params: { uid: string } }) {
  try {
    // Only super_admin (admins.manage) can change anyone's access.
    const a = await requirePermission(req, "admins.manage");
    const body = parseInput(Patch, await readJson(req));
    // Nobody can modify their own role, status, or protected-access grant.
    if (params.uid === a.uid) throw new HttpError(403, "You cannot change your own access");

    const ref = adminDb().collection("admins").doc(params.uid);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Administrator not found");
    const target = snap.data()!;
    if (target.role === "super_admin") throw new HttpError(403, "Super administrators cannot be modified here");

    const patch: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp(), updatedBy: a.uid };
    if (body.role !== undefined) patch.role = body.role;
    if (body.active !== undefined) patch.active = body.active;
    if (body.canViewProtected !== undefined) patch.canViewProtected = body.canViewProtected;
    await ref.update(patch);

    // Disabling takes effect immediately: revoke their sessions server-side.
    if (body.active === false) await adminAuth().revokeRefreshTokens(params.uid);

    await writeAudit({
      actorUid: a.uid, actorEmail: a.email, action: "admin.permissions_changed", targetType: "admin", targetId: params.uid,
      meta: {
        ...(body.role !== undefined ? { newRole: body.role, oldRole: target.role } : {}),
        ...(body.active !== undefined ? { active: body.active } : {}),
        ...(body.canViewProtected !== undefined ? { canViewProtected: body.canViewProtected } : {}),
      },
      ip: a.ip,
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
