import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, queryParams, readJson } from "@/lib/http";
import { serialize } from "@/lib/serialize";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await requirePermission(req, "admins.manage");
    const db = adminDb();
    const [admins, invites] = await Promise.all([db.collection("admins").limit(200).get(), db.collection("adminInvites").limit(200).get()]);
    return NextResponse.json({
      admins: admins.docs.map((d) => serialize({ uid: d.id, ...d.data() })),
      invites: invites.docs.map((d) => serialize({ email: d.id, ...d.data() })),
    });
  } catch (e) {
    return errorResponse(e);
  }
}

// super_admin is NOT assignable here (only via the one-time INITIAL_ADMIN_EMAIL bootstrap).
const Invite = z.object({
  email: z.string().trim().toLowerCase().email().max(200),
  role: z.enum(["admin", "reviewer", "viewer"]),
  canViewProtected: z.boolean().default(false),
});

// Authorize an admin email. Access activates only when that email signs in with a VERIFIED address.
export async function POST(req: Request) {
  try {
    const a = await requirePermission(req, "admins.manage");
    const body = parseInput(Invite, await readJson(req));
    const db = adminDb();
    const existing = await db.collection("admins").where("email", "==", body.email).limit(1).get();
    if (!existing.empty) throw new HttpError(409, "That email is already an administrator");
    await db.collection("adminInvites").doc(body.email).set({
      role: body.role,
      canViewProtected: body.role === "viewer" ? false : body.canViewProtected,
      active: true,
      createdBy: a.uid,
      createdAt: FieldValue.serverTimestamp(),
    });
    await writeAudit({
      actorUid: a.uid, actorEmail: a.email, action: "admin.invited", targetType: "adminInvite", targetId: body.email,
      meta: { role: body.role, canViewProtected: body.canViewProtected }, ip: a.ip,
    });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}

// DELETE ?email= : revoke an unused invite.
export async function DELETE(req: Request) {
  try {
    const a = await requirePermission(req, "admins.manage");
    const { email } = parseInput(z.object({ email: z.string().email() }), queryParams(req));
    await adminDb().collection("adminInvites").doc(email.toLowerCase()).delete();
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "admin.invite_revoked", targetType: "adminInvite", targetId: email.toLowerCase(), ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
