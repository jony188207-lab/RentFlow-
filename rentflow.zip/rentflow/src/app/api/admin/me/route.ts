import { NextResponse } from "next/server";
import { errorResponse, requireAdmin } from "@/lib/auth/admin-guard";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const admin = await requireAdmin(req);
    return NextResponse.json({ uid: admin.uid, email: admin.email, role: admin.role });
  } catch (e) {
    return errorResponse(e);
  }
}
