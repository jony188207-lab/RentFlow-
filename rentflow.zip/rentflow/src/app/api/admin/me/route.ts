import { NextResponse } from "next/server";
import { errorResponse, requireAdmin } from "@/lib/auth/admin-guard";
import { can, type Permission } from "@/lib/auth/permissions";

export const dynamic = "force-dynamic";

const ALL: Permission[] = [
  "applications.read", "applications.update", "applications.reject", "applications.export",
  "payments.read", "payments.manage", "paymentMethods.manage", "screening.read", "screening.manage", "notifications.read",
  "settings.read", "settings.write", "audit.read", "admins.manage", "protected.view",
];

export async function GET(req: Request) {
  try {
    const a = await requireAdmin(req);
    // Permissions are returned only to drive UI visibility; every API re-checks them server-side.
    return NextResponse.json({
      uid: a.uid,
      email: a.email,
      role: a.role,
      permissions: ALL.filter((p) => can(a, p)),
    });
  } catch (e) {
    return errorResponse(e);
  }
}
