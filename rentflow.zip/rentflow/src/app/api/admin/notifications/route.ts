import { NextResponse } from "next/server";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { parseInput, queryParams, readJson } from "@/lib/http";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

const Params = z.object({ unread: z.enum(["1"]).optional(), limit: z.coerce.number().int().min(1).max(100).default(50) });

export async function GET(req: Request) {
  try {
    await requirePermission(req, "notifications.read");
    const p = parseInput(Params, queryParams(req));
    let q: FirebaseFirestore.Query = adminDb().collection("notifications");
    if (p.unread) q = q.where("read", "==", false);
    const snap = await q.orderBy("createdAt", "desc").limit(p.limit).get();
    return NextResponse.json({ items: snap.docs.map((d) => serialize({ id: d.id, ...d.data() })) });
  } catch (e) {
    return errorResponse(e);
  }
}

const Mark = z.union([z.object({ ids: z.array(z.string().min(1)).min(1).max(100) }), z.object({ all: z.literal(true) })]);

export async function PATCH(req: Request) {
  try {
    await requirePermission(req, "notifications.read");
    const body = parseInput(Mark, await readJson(req));
    const db = adminDb();
    const batch = db.batch();
    if ("all" in body) {
      const unread = await db.collection("notifications").where("read", "==", false).limit(400).get();
      unread.docs.forEach((d) => batch.update(d.ref, { read: true }));
    } else {
      body.ids.forEach((id) => batch.update(db.collection("notifications").doc(id), { read: true }));
    }
    await batch.commit();
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
