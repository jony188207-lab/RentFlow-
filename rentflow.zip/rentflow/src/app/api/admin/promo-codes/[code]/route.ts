import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

const Patch = z
  .object({
    active: z.boolean(),
    endsAt: z.string().datetime().nullable(),
    maxUses: z.number().int().min(1).max(1_000_000).nullable(),
  })
  .partial()
  .refine((v) => Object.keys(v).length > 0, "No changes provided");

export async function PATCH(req: Request, { params }: { params: { code: string } }) {
  try {
    const a = await requirePermission(req, "settings.write");
    const body = parseInput(Patch, await readJson(req));
    const ref = adminDb().collection("promoCodes").doc(params.code.toUpperCase());
    if (!(await ref.get()).exists) throw new HttpError(404, "Promo code not found");
    await ref.update({ ...body, updatedAt: FieldValue.serverTimestamp() });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "settings.promo_updated", targetType: "promoCode", targetId: params.code.toUpperCase(), meta: { ...(body.active !== undefined ? { active: body.active } : {}) }, ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function DELETE(req: Request, { params }: { params: { code: string } }) {
  try {
    const a = await requirePermission(req, "settings.write");
    // Existing payments keep their own promoCode/discount snapshot, so history is unchanged.
    await adminDb().collection("promoCodes").doc(params.code.toUpperCase()).delete();
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "settings.promo_deleted", targetType: "promoCode", targetId: params.code.toUpperCase(), ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
