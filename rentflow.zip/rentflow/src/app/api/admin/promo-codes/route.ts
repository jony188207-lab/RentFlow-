import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { writeAudit } from "@/lib/audit";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

const dateOrNull = z.string().datetime().nullable().optional();

const PromoInput = z
  .object({
    code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_-]{3,32}$/, "3–32 letters, numbers, - or _"),
    type: z.enum(["percent", "fixed"]),
    value: z.number().int().min(1),
    active: z.boolean().default(true),
    startsAt: dateOrNull,
    endsAt: dateOrNull,
    maxUses: z.number().int().min(1).max(1_000_000).nullable().optional(),
  })
  .superRefine((p, ctx) => {
    if (p.type === "percent" && p.value > 99) ctx.addIssue({ code: "custom", path: ["value"], message: "Percent must be 1–99" });
    if (p.type === "fixed" && p.value > 5_000_000) ctx.addIssue({ code: "custom", path: ["value"], message: "Amount too large" });
  });

export async function GET(req: Request) {
  try {
    await requirePermission(req, "settings.read");
    const snap = await adminDb().collection("promoCodes").limit(200).get();
    return NextResponse.json({ items: snap.docs.map((d) => serialize({ code: d.id, usedCount: 0, ...d.data() })) });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await requirePermission(req, "settings.write");
    const p = parseInput(PromoInput, await readJson(req));
    const ref = adminDb().collection("promoCodes").doc(p.code);
    try {
      await ref.create({ type: p.type, value: p.value, active: p.active, startsAt: p.startsAt ?? null, endsAt: p.endsAt ?? null, maxUses: p.maxUses ?? null, usedCount: 0, createdAt: FieldValue.serverTimestamp(), createdBy: a.uid });
    } catch {
      throw new HttpError(409, "A promo code with that name already exists");
    }
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "settings.promo_created", targetType: "promoCode", targetId: p.code, meta: { type: p.type, value: p.value }, ip: a.ip });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
