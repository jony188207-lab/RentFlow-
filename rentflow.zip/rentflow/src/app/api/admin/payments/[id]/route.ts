import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { serialize } from "@/lib/serialize";
import { writeAudit } from "@/lib/audit";
import { getPaymentProvider } from "@/lib/payments/provider";
import { createNotification } from "@/lib/notify";
import { paymentView } from "@/lib/views";

export const dynamic = "force-dynamic";

// Payment + the applicant's application summary + history, so a reviewer sees everything together.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    await requirePermission(req, "payments.read");
    const db = adminDb();
    const ref = db.collection("payments").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Payment not found");
    const events = await ref.collection("events").orderBy("at", "desc").limit(50).get();
    const p = snap.data()!;
    const app = p.applicationId ? await db.collection("applications").doc(p.applicationId).get() : null;
    const x = app?.data();
    return NextResponse.json({
      ...paymentView(snap),
      reviewNotes: p.reviewNotes ?? null,
      reviewedByEmail: p.reviewedByEmail ?? null,
      reviewedAt: p.reviewedAt ? serialize(p.reviewedAt) : null,
      history: events.docs.map((e) => serialize({ id: e.id, ...e.data() })),
      application: x
        ? { reference: app!.id, applicantName: x.applicantName, applicantEmail: x.applicantEmail, status: x.status, propertyAddress: x.property?.address ?? null, monthlyIncomeCents: x.employment?.monthlyIncomeCents ?? null }
        : null,
      applicantEmail: p.applicantEmail ?? null,
    });
  } catch (e) {
    return errorResponse(e);
  }
}

const Notes = z.string().trim().max(1000);
const Action = z.discriminatedUnion("action", [
  // Provider-integrated payments (webhook/ledger): re-check the provider server-to-server.
  z.object({ action: z.literal("verify") }),
  z.object({ action: z.literal("refund"), reason: z.string().trim().min(5).max(500) }),
  // Manual-proof payments: a human decision after checking the money actually arrived.
  z.object({ action: z.literal("approve"), notes: Notes.optional() }),
  z.object({ action: z.literal("reject"), notes: Notes.min(5, "Explain why the payment is rejected") }),
  z.object({ action: z.literal("refund_pending"), notes: Notes.min(5) }),
  z.object({ action: z.literal("mark_refunded"), notes: Notes.min(5) }),
]);

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "payments.manage");
    const body = parseInput(Action, await readJson(req));
    const db = adminDb();
    const ref = db.collection("payments").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Payment not found");
    const pay = snap.data()!;
    const manual = pay.source === "manual";
    const audit = (action: string, meta: Record<string, string | number | boolean | null> = {}) =>
      writeAudit({ actorUid: a.uid, actorEmail: a.email, action, targetType: "payment", targetId: params.id, meta, ip: a.ip });

    // ----- manual review -----
    if (["approve", "reject", "refund_pending", "mark_refunded"].includes(body.action)) {
      if (!manual) throw new HttpError(409, "Provider payments are verified by the provider, not by manual review");
      const allowedFrom: Record<string, string[]> = {
        approve: ["pending_verification", "rejected"],
        reject: ["pending_verification", "verified"],
        refund_pending: ["verified"],
        mark_refunded: ["refund_pending"],
      };
      if (!allowedFrom[body.action]!.includes(pay.status)) throw new HttpError(409, `Cannot ${body.action.replace("_", " ")} a payment that is "${pay.status}"`);
      const next = { approve: "verified", reject: "rejected", refund_pending: "refund_pending", mark_refunded: "refunded" }[body.action]!;
      const notes = "notes" in body ? body.notes ?? null : null;
      await ref.update({
        status: next,
        refundStatus: next === "refund_pending" ? "pending" : next === "refunded" ? "refunded" : pay.refundStatus ?? "none",
        reviewNotes: notes ?? pay.reviewNotes ?? null,
        reviewedBy: a.uid,
        reviewedByEmail: a.email,
        reviewedAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
      await ref.collection("events").add({ at: FieldValue.serverTimestamp(), source: `admin:${a.uid}`, status: next, notes });
      await audit("payment.reviewed", { from: pay.status, to: next, hasNotes: Boolean(notes) });
      if (next === "verified") await createNotification({ type: "payment.completed", title: "Payment verified", message: `Payment ${params.id} verified.`, link: "/admin/payments" });
      if (next === "rejected") await createNotification({ type: "payment.failed", title: "Payment rejected", message: `Payment ${params.id} rejected.`, link: "/admin/payments" });
      return NextResponse.json({ ok: true, status: next });
    }

    // ----- provider-integrated payments -----
    if (manual) throw new HttpError(409, "Manual payments are reviewed with approve / reject");
    const provider = getPaymentProvider();
    if (!pay.providerRef) throw new HttpError(409, "Payment has no provider reference");

    if (body.action === "verify") {
      // Authoritative status comes from the provider, server-to-server. Never from the client.
      const remote = await provider.fetchPayment(pay.providerRef);
      if (!remote) throw new HttpError(404, "Provider has no record of this payment");
      const mismatch = remote.status === "succeeded" && remote.amountCents !== pay.amountCents;
      const next = mismatch ? "pending" : remote.status;
      await ref.update({
        status: next,
        needsReview: mismatch,
        cardBrand: remote.cardBrand ?? pay.cardBrand ?? null,
        cardLast4: remote.cardLast4 ?? pay.cardLast4 ?? null,
        updatedAt: FieldValue.serverTimestamp(),
      });
      await ref.collection("events").add({ at: FieldValue.serverTimestamp(), source: `admin_verify:${a.uid}`, status: next, mismatch });
      await audit("payment.verified", { from: pay.status, to: next, amountMismatch: mismatch });
      if (mismatch) await createNotification({ type: "system.error", title: "Payment amount mismatch", message: `Payment ${params.id} amount differs from the provider record.`, link: "/admin/payments" });
      else if (next === "succeeded" && pay.status !== "succeeded") await createNotification({ type: "payment.completed", title: "Payment completed", message: `Payment ${params.id} verified.`, link: "/admin/payments" });
      return NextResponse.json({ ok: true, status: next, amountMismatch: mismatch });
    }

    if (body.action === "refund") {
      if (pay.status !== "succeeded") throw new HttpError(409, "Only succeeded payments can be refunded");
      if (!provider.refund) throw new HttpError(501, "This provider does not support refunds here");
      const r = await provider.refund(pay.providerRef, pay.amountCents);
      const refundStatus = r.status === "succeeded" ? "refunded" : r.status;
      await ref.update({ refundStatus, status: r.status === "succeeded" ? "refunded" : pay.status, updatedAt: FieldValue.serverTimestamp() });
      await ref.collection("events").add({ at: FieldValue.serverTimestamp(), source: `admin_refund:${a.uid}`, status: refundStatus });
      await audit("payment.refund_requested", { result: r.status, amountCents: pay.amountCents });
      return NextResponse.json({ ok: true, refundStatus });
    }
    throw new HttpError(400, "Unknown action");
  } catch (e) {
    return errorResponse(e);
  }
}
