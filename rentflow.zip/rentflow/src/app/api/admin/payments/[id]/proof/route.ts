import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError } from "@/lib/http";
import { writeAudit } from "@/lib/audit";
import { readPrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

// Streams a payment screenshot from PRIVATE storage to an authorized admin only. Every view is
// audit-logged. There is no public or long-lived URL to a screenshot.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "payments.read");
    const snap = await adminDb().collection("payments").doc(params.id).get();
    const p = snap.data();
    if (!snap.exists || !p?.proofPath) throw new HttpError(404, "No screenshot on file");
    const buf = await readPrivate(p.proofPath);
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "payment.proof_viewed", targetType: "payment", targetId: params.id, ip: a.ip });
    return new Response(new Uint8Array(buf), {
      headers: {
        "content-type": p.proofContentType ?? "image/png",
        "cache-control": "private, no-store",
        "x-content-type-options": "nosniff",
        "content-security-policy": "default-src 'none'",
        "content-disposition": "inline",
      },
    });
  } catch (e) {
    return errorResponse(e);
  }
}
