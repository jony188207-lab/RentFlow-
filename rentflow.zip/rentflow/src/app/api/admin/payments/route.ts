import { NextResponse } from "next/server";
import { Timestamp, type Query } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { parseInput, queryParams } from "@/lib/http";
import { PAYMENT_STATUSES } from "@/lib/domain";
import { paymentView } from "@/lib/views";

export const dynamic = "force-dynamic";

const Params = z.object({
  status: z.enum(PAYMENT_STATUSES).optional(),
  q: z.string().trim().max(100).optional(), // transaction ID, application ID or provider reference (exact)
  data: z.enum(["real", "sample"]).default("real"),
  limit: z.coerce.number().int().min(1).max(50).default(20),
  after: z.string().datetime().optional(),
});

export async function GET(req: Request) {
  try {
    await requirePermission(req, "payments.read");
    const p = parseInput(Params, queryParams(req));
    const col = adminDb().collection("payments");
    const isSample = p.data === "sample";

    if (p.q) {
      const [byId, byApp, byRef] = await Promise.all([
        col.doc(p.q).get(),
        col.where("applicationId", "==", p.q).limit(20).get(),
        col.where("providerRef", "==", p.q).limit(20).get(),
      ]);
      const map = new Map<string, FirebaseFirestore.DocumentSnapshot>();
      [...(byId.exists ? [byId] : []), ...byApp.docs, ...byRef.docs].forEach((d) => map.set(d.id, d));
      const items = [...map.values()].filter((d) => (!p.status || d.data()!.status === p.status) && (d.data()!.isSample === true) === isSample);
      return NextResponse.json({ items: items.map(paymentView), nextAfter: null });
    }

    let q: Query = col.where("isSample", "==", isSample);
    if (p.status) q = q.where("status", "==", p.status);
    q = q.orderBy("createdAt", "desc");
    if (p.after) q = q.startAfter(Timestamp.fromDate(new Date(p.after)));
    const snap = await q.limit(p.limit).get();
    const last = snap.docs.at(-1);
    return NextResponse.json({
      items: snap.docs.map(paymentView),
      nextAfter: snap.size === p.limit && last ? last.data().createdAt.toDate().toISOString() : null,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
