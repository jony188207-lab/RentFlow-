import { NextResponse } from "next/server";
import { adminAuth } from "@/lib/firebase/admin";
import { errorResponse, requireAdmin } from "@/lib/auth/admin-guard";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

// POST: called once after a successful admin sign-in (audit record).
export async function POST(req: Request) {
  try {
    const a = await requireAdmin(req);
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "admin.login", ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}

// DELETE: logout. Revokes refresh tokens so existing ID tokens fail server-side verification.
export async function DELETE(req: Request) {
  try {
    const a = await requireAdmin(req);
    await adminAuth().revokeRefreshTokens(a.uid);
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "admin.logout", ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
