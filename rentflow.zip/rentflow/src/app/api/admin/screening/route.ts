import { NextResponse } from "next/server";
import { FieldValue, Timestamp, type Query } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, queryParams, readJson } from "@/lib/http";
import { SCREENING_STATUSES } from "@/lib/domain";
import { jobView } from "@/lib/views";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

const Params = z.object({
  status: z.enum(SCREENING_STATUSES).optional(),
  data: z.enum(["real", "sample"]).default("real"),
  limit: z.coerce.number().int().min(1).max(50).default(20),
  after: z.string().datetime().optional(),
});

export async function GET(req: Request) {
  try {
    await requirePermission(req, "screening.read");
    const p = parseInput(Params, queryParams(req));
    let q: Query = adminDb().collection("screeningJobs").where("isSample", "==", p.data === "sample");
    if (p.status) q = q.where("status", "==", p.status);
    q = q.orderBy("createdAt", "desc");
    if (p.after) q = q.startAfter(Timestamp.fromDate(new Date(p.after)));
    const snap = await q.limit(p.limit).get();
    const last = snap.docs.at(-1);
    return NextResponse.json({
      items: snap.docs.map(jobView),
      nextAfter: snap.size === p.limit && last ? last.data().createdAt.toDate().toISOString() : null,
    });
  } catch (e) {
    return errorResponse(e);
  }
}

const Create = z.object({ applicationId: z.string().min(1).max(100) });

// Queue a screening job. Real applications require a provider-verified successful payment first.
export async function POST(req: Request) {
  try {
    const a = await requirePermission(req, "screening.manage");
    const { applicationId } = parseInput(Create, await readJson(req));
    const db = adminDb();
    const app = await db.collection("applications").doc(applicationId).get();
    if (!app.exists) throw new HttpError(404, "Application not found");
    const isSample = app.data()!.isSample === true;
    if (!isSample) {
      const paid = await db.collection("payments").where("applicationId", "==", applicationId).where("status", "in", ["succeeded", "verified"]).limit(1).get();
      if (paid.empty) throw new HttpError(409, "A verified successful payment is required before screening");
    }
    const ref = await db.collection("screeningJobs").add({
      applicationId,
      status: "queued",
      provider: null,
      attempts: 0,
      error: null,
      manualReview: { status: "none" },
      isSample,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "screening.job_queued", targetType: "screeningJob", targetId: ref.id, meta: { applicationId }, ip: a.ip });
    return NextResponse.json({ id: ref.id }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
