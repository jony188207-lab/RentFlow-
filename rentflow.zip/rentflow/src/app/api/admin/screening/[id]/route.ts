import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { canRetryScreening, type ScreeningStatus } from "@/lib/domain";
import { writeAudit } from "@/lib/audit";
import { createNotification } from "@/lib/notify";
import { advanceJob } from "@/lib/screening/runner";

export const dynamic = "force-dynamic";

const Action = z.discriminatedUnion("action", [
  z.object({ action: z.literal("retry") }),
  z.object({ action: z.literal("run") }),
  z.object({ action: z.literal("send_to_manual_review"), note: z.string().trim().min(5).max(1000) }),
  z.object({ action: z.literal("resolve_manual_review"), note: z.string().trim().min(10).max(1000) }),
]);

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "screening.manage");
    const body = parseInput(Action, await readJson(req));
    const ref = adminDb().collection("screeningJobs").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Job not found");
    const job = snap.data()!;
    const audit = (action: string, meta: Record<string, string | number | boolean | null> = {}) =>
      writeAudit({ actorUid: a.uid, actorEmail: a.email, action, targetType: "screeningJob", targetId: params.id, meta, ip: a.ip });

    switch (body.action) {
      case "retry": {
        if (!canRetryScreening(job.status as ScreeningStatus, job.attempts ?? 0)) throw new HttpError(409, "Job cannot be retried");
        await ref.update({ status: "queued", error: null, updatedAt: FieldValue.serverTimestamp() });
        await audit("screening.job_retried", { attempts: job.attempts ?? 0 });
        return NextResponse.json({ ok: true, status: "queued" });
      }
      case "run": {
        if (job.status !== "queued") throw new HttpError(409, "Only queued jobs can be run");
        const status = await advanceJob(params.id);
        await audit("screening.job_run", { result: status });
        return NextResponse.json({ ok: true, status });
      }
      case "send_to_manual_review": {
        if (job.status === "completed") throw new HttpError(409, "Completed jobs cannot be moved");
        await ref.update({
          status: "manual_review",
          manualReview: { status: "pending", note: body.note, requestedBy: a.uid },
          updatedAt: FieldValue.serverTimestamp(),
        });
        await createNotification({ type: "screening.manual_review", title: "Manual review required", message: `Job ${params.id} needs manual review.`, link: "/admin/screening" });
        await audit("screening.sent_to_manual_review");
        return NextResponse.json({ ok: true });
      }
      case "resolve_manual_review": {
        if (job.manualReview?.status !== "pending") throw new HttpError(409, "No pending manual review");
        // Resolving a review records a human decision. It does NOT mark the job `completed`:
        // completion requires a provider-verified result.
        await ref.update({
          manualReview: { ...job.manualReview, status: "resolved", resolutionNote: body.note, resolvedBy: a.uid, resolvedAt: new Date().toISOString() },
          updatedAt: FieldValue.serverTimestamp(),
        });
        await audit("screening.manual_review_resolved");
        return NextResponse.json({ ok: true });
      }
    }
  } catch (e) {
    return errorResponse(e);
  }
}
