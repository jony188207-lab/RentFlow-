import { NextResponse } from "next/server";
import { Timestamp, type Query } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { parseInput, queryParams } from "@/lib/http";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

const Params = z.object({
  actorUid: z.string().max(128).optional(),
  actionPrefix: z.string().max(60).optional(), // e.g. "protected." or "security."
  limit: z.coerce.number().int().min(1).max(100).default(50),
  after: z.string().datetime().optional(),
});

// Read-only. There is no endpoint (and Firestore rules deny clients) to modify or delete audit records.
export async function GET(req: Request) {
  try {
    await requirePermission(req, "audit.read");
    const p = parseInput(Params, queryParams(req));
    let q: Query = adminDb().collection("auditLogs");
    if (p.actorUid) q = q.where("actorUid", "==", p.actorUid);
    q = q.orderBy("at", "desc");
    if (p.after) q = q.startAfter(Timestamp.fromDate(new Date(p.after)));
    const snap = await q.limit(p.actionPrefix ? 300 : p.limit).get();
    const docs = p.actionPrefix ? snap.docs.filter((d) => String(d.data().action).startsWith(p.actionPrefix!)).slice(0, p.limit) : snap.docs;
    const last = docs.at(-1);
    return NextResponse.json({
      items: docs.map((d) => serialize({ id: d.id, ...d.data() })),
      nextAfter: docs.length === p.limit && last ? last.data().at.toDate().toISOString() : null,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
