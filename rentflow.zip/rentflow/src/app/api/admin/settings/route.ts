import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { configurationStatus, getAppSettings, getSecuritySettings } from "@/lib/config";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await requirePermission(req, "settings.read");
    const [app, security] = await Promise.all([getAppSettings(), getSecuritySettings()]);
    // Configuration status is booleans/labels only; no secret values are ever returned.
    return NextResponse.json({ app, security, configuration: configurationStatus() });
  } catch (e) {
    return errorResponse(e);
  }
}

const Body = z
  .object({
    totalFeeCents: z.number().int().min(0).max(50_000), // $0 – $500
    applicationsEnabled: z.boolean(),
    requireScreenshot: z.boolean(),
    baseCurrency: z.string().regex(/^[A-Z]{3}$/),
    maxFailedAttempts: z.number().int().min(1).max(10),
    lockoutMinutes: z.number().int().min(1).max(1440),
  })
  .partial()
  .refine((v) => Object.keys(v).length > 0, "No changes provided");

export async function PUT(req: Request) {
  try {
    const a = await requirePermission(req, "settings.write");
    const body = parseInput(Body, await readJson(req));
    const securityChange = body.maxFailedAttempts !== undefined || body.lockoutMinutes !== undefined;
    // Security thresholds can only be changed by those who manage admins (super_admin).
    if (securityChange) await requirePermission(req, "admins.manage");

    const db = adminDb();
    const [oldApp, oldSec] = await Promise.all([getAppSettings(), getSecuritySettings()]);
    const audit = (action: string, meta: Record<string, string | number | boolean | null>) =>
      writeAudit({ actorUid: a.uid, actorEmail: a.email, action, targetType: "settings", meta, ip: a.ip });

    const appPatch: Record<string, unknown> = {};
    if (body.totalFeeCents !== undefined && body.totalFeeCents !== oldApp.totalFeeCents) {
      appPatch.totalFeeCents = body.totalFeeCents;
      await audit("settings.pricing_changed", { oldFeeCents: oldApp.totalFeeCents, newFeeCents: body.totalFeeCents });
    }
    if (body.applicationsEnabled !== undefined && body.applicationsEnabled !== oldApp.applicationsEnabled) {
      appPatch.applicationsEnabled = body.applicationsEnabled;
      await audit("settings.applications_toggled", { enabled: body.applicationsEnabled });
    }
    if (body.requireScreenshot !== undefined && body.requireScreenshot !== oldApp.requireScreenshot) {
      appPatch.requireScreenshot = body.requireScreenshot;
      await audit("settings.screenshot_requirement_changed", { required: body.requireScreenshot });
    }
    if (body.baseCurrency !== undefined && body.baseCurrency !== oldApp.baseCurrency) {
      appPatch.baseCurrency = body.baseCurrency;
      await audit("settings.currency_changed", { oldCurrency: oldApp.baseCurrency, newCurrency: body.baseCurrency });
    }
    if (Object.keys(appPatch).length) {
      await db.collection("settings").doc("app").set({ ...appPatch, updatedAt: FieldValue.serverTimestamp(), updatedBy: a.uid }, { merge: true });
      // Public mirror contains only non-sensitive values shown on the website.
      await db.collection("publicSettings").doc("pricing").set(
        {
          totalFeeCents: appPatch.totalFeeCents ?? oldApp.totalFeeCents,
          applicationsEnabled: appPatch.applicationsEnabled ?? oldApp.applicationsEnabled,
          baseCurrency: appPatch.baseCurrency ?? oldApp.baseCurrency,
        },
        { merge: true },
      );
    }

    const secPatch: Record<string, number> = {};
    if (body.maxFailedAttempts !== undefined && body.maxFailedAttempts !== oldSec.maxFailedAttempts) secPatch.maxFailedAttempts = body.maxFailedAttempts;
    if (body.lockoutMinutes !== undefined && body.lockoutMinutes !== oldSec.lockoutMinutes) secPatch.lockoutMinutes = body.lockoutMinutes;
    if (Object.keys(secPatch).length) {
      await db.collection("settings").doc("security").set({ ...secPatch, updatedAt: FieldValue.serverTimestamp(), updatedBy: a.uid }, { merge: true });
      await audit("settings.security_changed", { ...secPatch });
    }

    if (!Object.keys(appPatch).length && !Object.keys(secPatch).length) throw new HttpError(400, "No changes to apply");
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
