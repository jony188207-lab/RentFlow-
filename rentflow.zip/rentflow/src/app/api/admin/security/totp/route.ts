import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { authenticator } from "otplib";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requireAdmin } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { decryptField, encryptField } from "@/lib/crypto";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

// GET: is an authenticator enrolled?
export async function GET(req: Request) {
  try {
    const a = await requireAdmin(req);
    const d = (await adminDb().collection("adminSecrets").doc(a.uid).get()).data();
    return NextResponse.json({ enrolled: Boolean(d?.totpSecretEnc) });
  } catch (e) {
    return errorResponse(e);
  }
}

// POST: begin enrollment. Returns the otpauth URI ONCE over TLS; the secret is stored encrypted.
export async function POST(req: Request) {
  try {
    const a = await requireAdmin(req);
    const ref = adminDb().collection("adminSecrets").doc(a.uid);
    if ((await ref.get()).data()?.totpSecretEnc) throw new HttpError(409, "Authenticator already enrolled");
    const secret = authenticator.generateSecret();
    await ref.set({ pendingTotpEnc: encryptField(secret), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "security.totp_enrollment_started", ip: a.ip });
    return NextResponse.json({ secret, otpauthUrl: authenticator.keyuri(a.email, "RentFlow", secret) });
  } catch (e) {
    return errorResponse(e);
  }
}

// PUT: confirm enrollment with a valid code.
export async function PUT(req: Request) {
  try {
    const a = await requireAdmin(req);
    const { code } = parseInput(z.object({ code: z.string().regex(/^\d{6}$/) }), await readJson(req));
    const ref = adminDb().collection("adminSecrets").doc(a.uid);
    const pending = (await ref.get()).data()?.pendingTotpEnc as string | undefined;
    if (!pending) throw new HttpError(409, "No enrollment in progress");
    if (!authenticator.check(code, decryptField(pending))) throw new HttpError(400, "Invalid code");
    await ref.set({ totpSecretEnc: pending, pendingTotpEnc: FieldValue.delete(), enrolledAt: FieldValue.serverTimestamp() }, { merge: true });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "security.totp_enrolled", ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
