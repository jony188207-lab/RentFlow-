import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { APPLICATION_STATUSES, publicStatusFor } from "@/lib/domain";
import { serialize } from "@/lib/serialize";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

// Full applicant-submitted information. Sensitive identifiers (e.g. SSN) are NEVER returned here;
// they live only in the Protected Information area.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "applications.read");
    const db = adminDb();
    const ref = db.collection("applications").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Application not found");
    const { ssnEnc, ...data } = snap.data()!;
    const notes = await ref.collection("notes").orderBy("createdAt", "desc").limit(50).get();
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "application.viewed", targetType: "application", targetId: params.id, ip: a.ip });
    return NextResponse.json(
      serialize({ id: snap.id, ...data, ssnOnFile: Boolean(ssnEnc), notes: notes.docs.map((n) => ({ id: n.id, ...n.data() })) }),
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return errorResponse(e);
  }
}

const Patch = z.object({
  status: z.enum(APPLICATION_STATUSES),
  reason: z.string().trim().max(1000).optional(),
  acknowledgeReportReviewed: z.boolean().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "applications.update");
    const body = parseInput(Patch, await readJson(req));
    const db = adminDb();
    const ref = db.collection("applications").doc(params.id);

    if (body.status === "rejected") {
      // Rejection is always a deliberate human decision with a recorded reason, and the admin must
      // confirm they reviewed any screening report. No automatic rejection exists anywhere.
      await requirePermission(req, "applications.reject");
      if (!body.reason || body.reason.length < 10) throw new HttpError(400, "A reason (10+ characters) is required to reject");
      const rep = await db.collection("screeningReports").where("applicationId", "==", params.id).limit(1).get();
      if (!rep.empty && body.acknowledgeReportReviewed !== true) {
        throw new HttpError(409, "Confirm you have reviewed the screening report before rejecting");
      }
    }

    const from = await db.runTransaction(async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists) throw new HttpError(404, "Application not found");
      const prev = snap.data()!.status as string;
      if (prev === body.status) throw new HttpError(400, "Status is unchanged");
      tx.update(ref, {
        status: body.status,
        publicStatus: publicStatusFor(body.status),
        updatedAt: FieldValue.serverTimestamp(),
        statusHistory: FieldValue.arrayUnion({
          from: prev,
          to: body.status,
          byUid: a.uid,
          byEmail: a.email,
          at: new Date().toISOString(),
          reason: body.reason ?? null,
        }),
      });
      return prev;
    });

    await writeAudit({
      actorUid: a.uid,
      actorEmail: a.email,
      action: "application.status_changed",
      targetType: "application",
      targetId: params.id,
      meta: { from, to: body.status, hasReason: Boolean(body.reason) },
      ip: a.ip,
    });
    return NextResponse.json({ ok: true, status: body.status });
  } catch (e) {
    return errorResponse(e);
  }
}
