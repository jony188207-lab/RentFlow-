import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

const Body = z.object({ note: z.string().trim().min(1).max(2000) });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "applications.update");
    const { note } = parseInput(Body, await readJson(req));
    const ref = adminDb().collection("applications").doc(params.id);
    if (!(await ref.get()).exists) throw new HttpError(404, "Application not found");
    await ref.collection("notes").add({ note, authorUid: a.uid, authorEmail: a.email, createdAt: FieldValue.serverTimestamp() });
    // Audit records that a note was added, never its text.
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "application.note_added", targetType: "application", targetId: params.id, ip: a.ip });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
