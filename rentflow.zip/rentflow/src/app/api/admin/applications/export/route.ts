import { Timestamp, type Query } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { parseInput, queryParams } from "@/lib/http";
import { APPLICATION_STATUSES, toCsv } from "@/lib/domain";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

const Params = z.object({
  status: z.enum(APPLICATION_STATUSES).optional(),
  from: z.string().date().optional(),
  to: z.string().date().optional(),
  data: z.enum(["real", "sample"]).default("real"),
});

const COLUMNS = ["applicationId", "name", "email", "phone", "status", "createdAt", "propertyAddress", "monthlyIncomeUsd"];

// Export excludes SSN and all protected data. Requires the explicit applications.export permission.
export async function GET(req: Request) {
  try {
    const a = await requirePermission(req, "applications.export");
    const p = parseInput(Params, queryParams(req));
    let q: Query = adminDb().collection("applications").where("isSample", "==", p.data === "sample");
    if (p.status) q = q.where("status", "==", p.status);
    if (p.from) q = q.where("createdAt", ">=", Timestamp.fromDate(new Date(`${p.from}T00:00:00Z`)));
    if (p.to) q = q.where("createdAt", "<=", Timestamp.fromDate(new Date(`${p.to}T23:59:59.999Z`)));
    const snap = await q.orderBy("createdAt", "desc").limit(1000).get();
    const rows = snap.docs.map((d) => {
      const x = d.data();
      return {
        applicationId: d.id,
        name: x.applicantName,
        email: x.applicantEmail,
        phone: x.applicantPhone ?? "",
        status: x.status,
        createdAt: x.createdAt?.toDate().toISOString() ?? "",
        propertyAddress: x.property?.address ?? "",
        monthlyIncomeUsd: x.employment?.monthlyIncomeCents != null ? (x.employment.monthlyIncomeCents / 100).toFixed(2) : "",
      };
    });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "application.exported", meta: { count: rows.length, data: p.data }, ip: a.ip });
    return new Response(toCsv(rows, COLUMNS), {
      headers: {
        "content-type": "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="applications-${new Date().toISOString().slice(0, 10)}.csv"`,
        "cache-control": "no-store",
      },
    });
  } catch (e) {
    return errorResponse(e);
  }
}
