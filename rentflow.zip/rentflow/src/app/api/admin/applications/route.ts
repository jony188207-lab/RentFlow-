import { NextResponse } from "next/server";
import { Timestamp, type Query } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { parseInput, queryParams } from "@/lib/http";
import { APPLICATION_STATUSES } from "@/lib/domain";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

const Params = z.object({
  q: z.string().trim().max(100).optional(),
  status: z.enum(APPLICATION_STATUSES).optional(),
  from: z.string().date().optional(),
  to: z.string().date().optional(),
  data: z.enum(["real", "sample"]).default("real"),
  limit: z.coerce.number().int().min(1).max(50).default(20),
  after: z.string().datetime().optional(),
});

const summary = (d: FirebaseFirestore.QueryDocumentSnapshot | FirebaseFirestore.DocumentSnapshot) => {
  const x = d.data()!;
  return serialize({
    id: d.id,
    applicantName: x.applicantName,
    applicantEmail: x.applicantEmail,
    status: x.status,
    createdAt: x.createdAt,
    propertyAddress: x.property?.address ?? null,
    isSample: x.isSample === true,
  });
};

export async function GET(req: Request) {
  try {
    await requirePermission(req, "applications.read");
    const p = parseInput(Params, queryParams(req));
    const col = adminDb().collection("applications");
    const isSample = p.data === "sample";
    const fromTs = p.from ? Timestamp.fromDate(new Date(`${p.from}T00:00:00Z`)) : undefined;
    const toTs = p.to ? Timestamp.fromDate(new Date(`${p.to}T23:59:59.999Z`)) : undefined;

    let docs: (FirebaseFirestore.QueryDocumentSnapshot | FirebaseFirestore.DocumentSnapshot)[];

    if (p.q) {
      const q = p.q.toLowerCase();
      if (q.includes("@")) {
        docs = (await col.where("isSample", "==", isSample).where("applicantEmailLower", "==", q).limit(50).get()).docs;
      } else {
        const byId = await col.doc(p.q).get(); // application ID exact match
        const byName = await col
          .where("isSample", "==", isSample)
          .where("applicantNameLower", ">=", q)
          .where("applicantNameLower", "<=", q + "")
          .limit(100)
          .get();
        docs = [...(byId.exists ? [byId] : []), ...byName.docs.filter((d) => d.id !== byId.id)];
      }
      // Remaining filters applied in memory for search results.
      docs = docs.filter((d) => {
        const x = d.data()!;
        const t: Timestamp | undefined = x.createdAt;
        return (!p.status || x.status === p.status) && (!fromTs || (t && t >= fromTs)) && (!toTs || (t && t <= toTs));
      });
      docs.sort((a, b) => (b.data()!.createdAt?.toMillis() ?? 0) - (a.data()!.createdAt?.toMillis() ?? 0));
      return NextResponse.json({ items: docs.slice(0, p.limit).map(summary), nextAfter: null });
    }

    let query: Query = col.where("isSample", "==", isSample);
    if (p.status) query = query.where("status", "==", p.status);
    if (fromTs) query = query.where("createdAt", ">=", fromTs);
    if (toTs) query = query.where("createdAt", "<=", toTs);
    query = query.orderBy("createdAt", "desc");
    if (p.after) query = query.startAfter(Timestamp.fromDate(new Date(p.after)));
    const snap = await query.limit(p.limit).get();
    const last = snap.docs.at(-1);
    return NextResponse.json({
      items: snap.docs.map(summary),
      nextAfter: snap.size === p.limit && last ? last.data().createdAt.toDate().toISOString() : null,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
