import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { writeAudit } from "@/lib/audit";
import { serialize } from "@/lib/serialize";
import { PROVIDER_CAPABILITIES, PaymentMethodInput, hasPayableDetails } from "@/lib/paymentMethods";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await requirePermission(req, "payments.read");
    const snap = await adminDb().collection("paymentMethods").get();
    const items = snap.docs
      .map((d) => {
        const { qrPath, ...rest } = d.data(); // storage paths never leave the server
        return serialize({ id: d.id, ...rest });
      })
      .sort((a: any, b: any) => a.displayOrder - b.displayOrder);
    const capabilities = Object.fromEntries(
      Object.entries(PROVIDER_CAPABILITIES).map(([k, c]) => [
        k,
        { label: c.label, supportsUrl: c.supportsUrl, supportsQr: c.supportsQr, identifierLabel: c.identifierLabel, identifierHint: c.identifierHint ?? null, note: c.note, urlHosts: c.urlHosts },
      ]),
    );
    return NextResponse.json({ items, capabilities });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await requirePermission(req, "paymentMethods.manage");
    const input = parseInput(PaymentMethodInput, await readJson(req));
    // A new method has no QR yet, so it can only be enabled if it has a link or identifier.
    if (input.enabled && !hasPayableDetails({ paymentUrl: input.paymentUrl, identifier: input.identifier })) {
      throw new HttpError(400, "Add a payment link or identifier before enabling (or save disabled, upload a QR, then enable)");
    }
    const ref = adminDb().collection("paymentMethods").doc();
    await ref.set({ ...input, hasQr: false, qrPath: null, qrContentType: null, createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(), updatedBy: a.uid });
    await writeAudit({
      actorUid: a.uid, actorEmail: a.email, action: "payment_method.created", targetType: "paymentMethod", targetId: ref.id,
      meta: { provider: input.provider, enabled: input.enabled, identifier: input.identifier ?? null, paymentUrl: input.paymentUrl ?? null }, ip: a.ip,
    });
    return NextResponse.json({ id: ref.id }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
