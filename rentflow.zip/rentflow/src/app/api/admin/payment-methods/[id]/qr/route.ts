import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError } from "@/lib/http";
import { readImageUpload } from "@/lib/files";
import { writeAudit } from "@/lib/audit";
import { PROVIDER_CAPABILITIES, qrAllowed, type ProviderId } from "@/lib/paymentMethods";
import { deletePrivate, putPrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "paymentMethods.manage");
    const ref = adminDb().collection("paymentMethods").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Payment method not found");
    const m = snap.data()!;
    if (!qrAllowed(m.provider as ProviderId)) throw new HttpError(400, `${PROVIDER_CAPABILITIES[m.provider as ProviderId].label} does not support QR codes`);
    const form = await req.formData().catch(() => null);
    const image = await readImageUpload(form?.get("qr") ?? null);
    if (!image) throw new HttpError(400, "Choose a QR image (PNG, JPEG or WebP, up to 4 MB)");
    const path = `payment-qr/${params.id}-${Date.now()}.${image.ext}`;
    await putPrivate(path, image.buf, image.mime);
    if (m.qrPath) await deletePrivate(m.qrPath).catch(() => undefined);
    await ref.update({ hasQr: true, qrPath: path, qrContentType: image.mime, updatedAt: FieldValue.serverTimestamp(), updatedBy: a.uid });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "payment_method.qr_uploaded", targetType: "paymentMethod", targetId: params.id, ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "paymentMethods.manage");
    const ref = adminDb().collection("paymentMethods").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Payment method not found");
    const m = snap.data()!;
    if (m.qrPath) await deletePrivate(m.qrPath).catch(() => undefined);
    const stillPayable = Boolean(m.paymentUrl || m.identifier);
    await ref.update({ hasQr: false, qrPath: null, qrContentType: null, ...(stillPayable ? {} : { enabled: false }), updatedAt: FieldValue.serverTimestamp(), updatedBy: a.uid });
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "payment_method.qr_removed", targetType: "paymentMethod", targetId: params.id, ip: a.ip });
    return NextResponse.json({ ok: true, disabled: !stillPayable });
  } catch (e) {
    return errorResponse(e);
  }
}
