import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { writeAudit } from "@/lib/audit";
import { PaymentMethodInput, hasPayableDetails, qrAllowed } from "@/lib/paymentMethods";
import { deletePrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "paymentMethods.manage");
    const input = parseInput(PaymentMethodInput, await readJson(req));
    const ref = adminDb().collection("paymentMethods").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Payment method not found");
    const old = snap.data()!;

    let hasQr = old.hasQr === true;
    // Switching to a provider that cannot show QR codes removes the stored QR.
    if (hasQr && !qrAllowed(input.provider)) {
      if (old.qrPath) await deletePrivate(old.qrPath).catch(() => undefined);
      hasQr = false;
    }
    if (input.enabled && !hasPayableDetails({ paymentUrl: input.paymentUrl, identifier: input.identifier, hasQr })) {
      throw new HttpError(400, "An enabled method needs a payment link, identifier or QR code");
    }
    await ref.set(
      {
        ...input,
        paymentUrl: input.paymentUrl ?? FieldValue.delete(),
        identifier: input.identifier ?? FieldValue.delete(),
        fixedAmountCents: input.fixedAmountCents ?? FieldValue.delete(),
        hasQr,
        ...(hasQr ? {} : { qrPath: null, qrContentType: null }),
        updatedAt: FieldValue.serverTimestamp(),
        updatedBy: a.uid,
      },
      { merge: true },
    );
    // Redirecting where applicants send money is the key fraud risk, so old/new values are recorded.
    await writeAudit({
      actorUid: a.uid, actorEmail: a.email, action: "payment_method.updated", targetType: "paymentMethod", targetId: params.id,
      meta: {
        provider: input.provider, enabled: input.enabled,
        oldIdentifier: old.identifier ?? null, newIdentifier: input.identifier ?? null,
        oldPaymentUrl: old.paymentUrl ?? null, newPaymentUrl: input.paymentUrl ?? null,
      },
      ip: a.ip,
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requirePermission(req, "paymentMethods.manage");
    const ref = adminDb().collection("paymentMethods").doc(params.id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Payment method not found");
    const m = snap.data()!;
    if (m.qrPath) await deletePrivate(m.qrPath).catch(() => undefined);
    // Existing payments keep their own snapshot (methodName/provider/amount), so history is unchanged.
    await ref.delete();
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "payment_method.deleted", targetType: "paymentMethod", targetId: params.id, meta: { provider: m.provider, identifier: m.identifier ?? null }, ip: a.ip });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
