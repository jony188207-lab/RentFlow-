import { NextResponse } from "next/server";
import { z } from "zod";
import { authenticator } from "otplib";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requireAdmin } from "@/lib/auth/admin-guard";
import { decryptField } from "@/lib/crypto";
import { serverEnv } from "@/lib/env";
import {
  checkAttemptState,
  issueUnlockToken,
  recordFailure,
  resetAttempts,
  type AttemptState,
} from "@/lib/auth/protected-area";

export const dynamic = "force-dynamic";

const Body = z.object({ password: z.string().min(1).max(200), totp: z.string().regex(/^\d{6}$/).optional() });

async function passwordIsCorrect(email: string, password: string): Promise<boolean> {
  // Re-verifies the admin's own password against Firebase Auth without creating a new session.
  const res = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${serverEnv.firebaseWebApiKey}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: false }),
    },
  );
  return res.ok;
}

export async function POST(req: Request) {
  try {
    const admin = await requireAdmin(req, "reviewer");
    const parsed = Body.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return NextResponse.json({ error: "Invalid request" }, { status: 400 });

    const db = adminDb();
    const attemptsRef = db.collection("protectedAttempts").doc(admin.uid);
    const now = Date.now();
    const state = ((await attemptsRef.get()).data() as AttemptState | undefined) ?? null;

    const decision = checkAttemptState(state, now);
    if (!decision.allowed) {
      return NextResponse.json(
        { error: "Too many attempts. Try again later.", retryAfterSeconds: Math.ceil(decision.retryAfterMs / 1000) },
        { status: 429 },
      );
    }

    const audit = (action: string) =>
      db.collection("auditLogs").add({ at: new Date().toISOString(), actorUid: admin.uid, action });

    let totpOk = true;
    if (decision.requireTotp) {
      const secretDoc = await db.collection("adminSecrets").doc(admin.uid).get();
      const enc = secretDoc.data()?.totpSecretEnc as string | undefined;
      totpOk = Boolean(enc && parsed.data.totp && authenticator.check(parsed.data.totp, decryptField(enc)));
      if (!parsed.data.totp) {
        return NextResponse.json({ error: "Authenticator code required", requireTotp: true }, { status: 401 });
      }
    }

    const pwOk = await passwordIsCorrect(admin.email, parsed.data.password);
    if (!pwOk || !totpOk) {
      await attemptsRef.set(recordFailure(state, now));
      await audit("protected.unlock.failed");
      return NextResponse.json({ error: "Verification failed" }, { status: 401 });
    }

    await attemptsRef.set(resetAttempts());
    await audit("protected.unlock.success");
    return NextResponse.json({ unlockToken: issueUnlockToken(admin.uid, serverEnv.protectedAreaSecret) });
  } catch (e) {
    return errorResponse(e);
  }
}
