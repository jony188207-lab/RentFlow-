import { NextResponse } from "next/server";
import { z } from "zod";
import { authenticator } from "otplib";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse, requirePermission } from "@/lib/auth/admin-guard";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { decryptField } from "@/lib/crypto";
import { serverEnv } from "@/lib/env";
import { writeAudit } from "@/lib/audit";
import { getSecuritySettings, toLockoutConfig } from "@/lib/config";
import {
  checkAttemptState,
  issueUnlockToken,
  recordFailure,
  resetAttempts,
  type AttemptState,
} from "@/lib/auth/protected-area";

export const dynamic = "force-dynamic";

const Body = z.object({ password: z.string().min(1).max(200), totp: z.string().regex(/^\d{6}$/).optional() });

async function passwordIsCorrect(email: string, password: string): Promise<boolean> {
  // Re-verifies the admin's own password against Firebase Auth without creating a session.
  const res = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${serverEnv.firebaseWebApiKey}`,
    { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email, password, returnSecureToken: false }) },
  );
  return res.ok;
}

export async function POST(req: Request) {
  try {
    // Only admins with the explicit protected-information grant can even attempt to unlock.
    const a = await requirePermission(req, "protected.view");
    const body = parseInput(Body, await readJson(req));

    const db = adminDb();
    const attemptsRef = db.collection("protectedAttempts").doc(a.uid);
    const now = Date.now();
    const state = ((await attemptsRef.get()).data() as AttemptState | undefined) ?? null;
    const cfg = toLockoutConfig(await getSecuritySettings());
    const audit = (action: string, meta: Record<string, string | number | boolean | null> = {}) =>
      writeAudit({ actorUid: a.uid, actorEmail: a.email, action, meta, ip: a.ip });

    const decision = checkAttemptState(state, now, cfg);
    if (!decision.allowed) {
      await audit("protected.unlock_blocked_locked");
      return NextResponse.json(
        { error: "Too many attempts. Try again later.", retryAfterSeconds: Math.ceil(decision.retryAfterMs / 1000) },
        { status: 429 },
      );
    }

    // After the failure threshold, identity must ALSO be verified with an authenticator code.
    let totpOk = true;
    if (decision.requireTotp) {
      if (!body.totp) return NextResponse.json({ error: "Authenticator code required", requireTotp: true }, { status: 401 });
      const enc = (await db.collection("adminSecrets").doc(a.uid).get()).data()?.totpSecretEnc as string | undefined;
      if (!enc) throw new HttpError(403, "Set up an authenticator in Settings → Security to continue");
      totpOk = authenticator.check(body.totp, decryptField(enc));
    }

    const pwOk = await passwordIsCorrect(a.email, body.password);
    if (!pwOk || !totpOk) {
      const next = recordFailure(state, now, cfg);
      await attemptsRef.set(next);
      await audit("protected.unlock_failed", { failures: next.failures, lockedOut: Boolean(next.lockedUntil) });
      return NextResponse.json(
        { error: "Verification failed", ...(next.lockedUntil ? { locked: true } : {}) },
        { status: 401 },
      );
    }

    await attemptsRef.set(resetAttempts());
    await audit("protected.unlock_success");
    return NextResponse.json({ unlockToken: issueUnlockToken(a.uid, serverEnv.protectedAreaSecret) });
  } catch (e) {
    return errorResponse(e);
  }
}
