import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireProtectedAccess } from "@/lib/auth/protected-guard";
import { HttpError } from "@/lib/http";
import { decryptField } from "@/lib/crypto";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

async function load(id: string) {
  const snap = await adminDb().collection("screeningReports").doc(id).get();
  if (!snap.exists) throw new HttpError(404, "Report not found");
  const x = snap.data()!;
  return { x, payload: JSON.parse(decryptField(x.payloadEnc)) as Record<string, unknown> };
}

// View (?download=1 returns an attachment). Reports are decrypted in memory only for this response
// and are never served from a public URL. Each view and download is audit-logged (IDs only).
export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const download = new URL(req.url).searchParams.get("download") === "1";
    const a = await requireProtectedAccess(req, download ? "report.download" : "report.view");
    const { x, payload } = await load(params.id);
    await writeAudit({
      actorUid: a.uid,
      actorEmail: a.email,
      action: download ? "protected.report_downloaded" : "protected.report_viewed",
      targetType: "screeningReport",
      targetId: params.id,
      meta: { applicationId: x.applicationId ?? null },
      ip: a.ip,
    });
    const body = { id: params.id, applicationId: x.applicationId, verified: x.verified === true, isSample: x.isSample === true, payload };
    const headers: Record<string, string> = { "Cache-Control": "no-store" };
    if (download) {
      headers["Content-Disposition"] = `attachment; filename="report-${params.id}.json"`;
      return new Response(JSON.stringify(body, null, 2), { headers: { ...headers, "Content-Type": "application/json" } });
    }
    return NextResponse.json(body, { headers });
  } catch (e) {
    return errorResponse(e);
  }
}
