import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireProtectedAccess } from "@/lib/auth/protected-guard";
import { writeAudit } from "@/lib/audit";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

// Metadata only. Report contents require opening an individual report (separately audited).
export async function GET(req: Request) {
  try {
    const a = await requireProtectedAccess(req, "reports.list");
    const snap = await adminDb().collection("screeningReports").orderBy("createdAt", "desc").limit(50).get();
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "protected.reports_listed", meta: { count: snap.size }, ip: a.ip });
    return NextResponse.json(
      {
        items: snap.docs.map((d) => {
          const x = d.data();
          return serialize({ id: d.id, jobId: x.jobId, applicationId: x.applicationId, verified: x.verified === true, createdAt: x.createdAt, isSample: x.isSample === true });
        }),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return errorResponse(e);
  }
}
