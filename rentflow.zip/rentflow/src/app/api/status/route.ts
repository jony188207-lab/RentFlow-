import { NextResponse } from "next/server";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";

export const dynamic = "force-dynamic";

const Body = z.object({ applicationId: z.string().min(6).max(64), email: z.string().email().max(200) });

// Public lookup. Requires BOTH the application ID and the email on file, and returns
// only a coarse status. The same message is returned for "not found" and "email mismatch".
export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => null));
  const notFound = NextResponse.json({ error: "No matching application found." }, { status: 404 });
  if (!parsed.success) return notFound;
  try {
    const snap = await adminDb().collection("applications").doc(parsed.data.applicationId).get();
    const data = snap.data();
    if (!snap.exists || data?.applicantEmail?.toLowerCase() !== parsed.data.email.toLowerCase()) return notFound;
    return NextResponse.json({ status: data.publicStatus ?? "received" });
  } catch {
    return NextResponse.json({ error: "Service unavailable." }, { status: 503 });
  }
}
