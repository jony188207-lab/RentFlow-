"use client";
import Link from "next/link";
import { useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, DataToggle, Empty, ErrorBox, PageHeader, SampleTag, Spinner, TableWrap, Td, Th, fmtDate, gbtn, gbtn2, ginput } from "@/components/admin/ui";

const STATUSES = ["new", "pending", "approved", "rejected", "withdrawn"];

export default function ApplicationsPage() {
  const { rawFetch, can } = useAdmin();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [data, setData] = useState<"real" | "sample">("real");
  const [applied, setApplied] = useState({ q: "", status: "", from: "", to: "", data: "real" });
  const [exportErr, setExportErr] = useState<string | null>(null);

  const qs = new URLSearchParams({ data: applied.data });
  (["q", "status", "from", "to"] as const).forEach((k) => applied[k] && qs.set(k, applied[k]));
  const { data: res, error, loading } = useLoad<any>(`/api/admin/applications?${qs}`);

  async function doExport() {
    setExportErr(null);
    const r = await rawFetch(`/api/admin/applications/export?${qs}`);
    if (!r.ok) return setExportErr((await r.json().catch(() => ({}))).error ?? "Export failed");
    const url = URL.createObjectURL(await r.blob());
    const a = Object.assign(document.createElement("a"), { href: url, download: "applications.csv" });
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHeader title="Applications">
        <DataToggle value={data} onChange={(v) => { setData(v); setApplied({ ...applied, data: v }); }} />
        {can("applications.export") && <button className={gbtn2} onClick={doExport}>Export CSV</button>}
      </PageHeader>
      <ErrorBox text={exportErr} />
      <form
        className="mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5"
        onSubmit={(e) => { e.preventDefault(); setApplied({ q, status, from, to, data }); }}
      >
        <input aria-label="Search" className={`${ginput} lg:col-span-2`} placeholder="Name, email or application ID" value={q} onChange={(e) => setQ(e.target.value)} />
        <select aria-label="Status" className={ginput} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <input aria-label="From date" type="date" className={ginput} value={from} onChange={(e) => setFrom(e.target.value)} />
        <input aria-label="To date" type="date" className={ginput} value={to} onChange={(e) => setTo(e.target.value)} />
        <button className={`${gbtn} sm:col-span-2 lg:col-span-5 lg:w-40`}>Apply filters</button>
      </form>

      {loading ? <Spinner /> : error ? <ErrorBox text={error} /> : !res?.items.length ? (
        <Empty text={data === "sample" ? "No sample applications. Run the seed script in development." : "No applications match."} />
      ) : (
        <TableWrap>
          <thead><tr><Th>Applicant</Th><Th>Email</Th><Th>Status</Th><Th>Property</Th><Th>Submitted</Th><Th /></tr></thead>
          <tbody className="divide-y divide-forest-100">
            {res.items.map((a: any) => (
              <tr key={a.id} className="hover:bg-forest-50">
                <Td>{a.applicantName}{a.isSample && <SampleTag />}<div className="text-xs text-slate-500">{a.id}</div></Td>
                <Td>{a.applicantEmail}</Td>
                <Td><Badge value={a.status} /></Td>
                <Td>{a.propertyAddress ?? "—"}</Td>
                <Td>{fmtDate(a.createdAt)}</Td>
                <Td><Link className="font-semibold text-forest-700 underline" href={`/admin/applications/${a.id}`}>Open</Link></Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
      {res?.nextAfter && <p className="mt-2 text-xs text-slate-500">More results available; narrow the date range to see them.</p>}
    </div>
  );
}
