"use client";
import Link from "next/link";
import { useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, ConfirmDialog, ErrorBox, PageHeader, Panel, SampleTag, Spinner, fmtDate, gbtn, gbtn2, ginput, usd } from "@/components/admin/ui";

const NEXT = ["new", "pending", "approved", "rejected", "withdrawn"];

const KV = ({ k, v }: { k: string; v: React.ReactNode }) => (
  <div className="py-1 text-sm"><dt className="text-xs text-slate-500">{k}</dt><dd>{v ?? "—"}</dd></div>
);

export default function ApplicationDetail({ params }: { params: { id: string } }) {
  const { api, can } = useAdmin();
  const { data: a, error, loading, reload } = useLoad<any>(`/api/admin/applications/${params.id}`);
  const [target, setTarget] = useState("");
  const [reason, setReason] = useState("");
  const [ack, setAck] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [note, setNote] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  if (loading) return <Spinner />;
  if (error || !a) return <ErrorBox text={error ?? "Not found"} />;

  async function changeStatus() {
    setMsg(null);
    const r = await api(`/api/admin/applications/${params.id}`, { method: "PATCH", body: { status: target, reason: reason || undefined, acknowledgeReportReviewed: ack || undefined } });
    setConfirm(false);
    if (!r.ok) return setMsg(r.data.error ?? "Update failed");
    setTarget(""); setReason(""); setAck(false);
    reload();
  }
  async function addNote(e: React.FormEvent) {
    e.preventDefault();
    const r = await api(`/api/admin/applications/${params.id}/notes`, { method: "POST", body: { note } });
    if (!r.ok) return setMsg(r.data.error ?? "Could not add note");
    setNote(""); reload();
  }

  const canUpdate = can("applications.update");
  return (
    <div>
      <p className="mb-2 text-sm"><Link href="/admin/applications" className="text-forest-700 underline">← Applications</Link></p>
      <PageHeader title={a.applicantName}>
        <Badge value={a.status} />{a.isSample && <SampleTag />}
      </PageHeader>
      <ErrorBox text={msg} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <h2 className="mb-2 font-semibold text-forest-900">Applicant</h2>
          <dl className="grid grid-cols-2 gap-x-4">
            <KV k="Application ID" v={a.id} /><KV k="Submitted" v={fmtDate(a.createdAt)} />
            <KV k="Email" v={a.applicantEmail} /><KV k="Phone" v={a.applicantPhone} />
            <KV k="SSN" v={a.ssnOnFile ? "On file (view only in Protected information)" : "Not collected"} />
          </dl>
        </Panel>
        <Panel>
          <h2 className="mb-2 font-semibold text-forest-900">Property & household</h2>
          <dl className="grid grid-cols-2 gap-x-4">
            <KV k="Address" v={a.property?.address} /><KV k="Monthly rent" v={a.property?.rentCents != null ? usd(a.property.rentCents) : null} />
            <KV k="Desired move-in" v={a.property?.moveIn} /><KV k="Adults / children" v={`${a.household?.adults ?? "—"} / ${a.household?.children ?? "—"}`} />
            <KV k="Pets" v={a.household?.pets?.length ? a.household.pets.map((p: any) => `${p.type}${p.breed ? ` (${p.breed})` : ""}`).join(", ") : "None"} />
          </dl>
        </Panel>
        <Panel>
          <h2 className="mb-2 font-semibold text-forest-900">Employment & income</h2>
          <dl className="grid grid-cols-2 gap-x-4">
            <KV k="Employer" v={a.employment?.employer} /><KV k="Title" v={a.employment?.title} />
            <KV k="Monthly income" v={a.employment?.monthlyIncomeCents != null ? usd(a.employment.monthlyIncomeCents) : null} /><KV k="Start date" v={a.employment?.startDate} />
          </dl>
        </Panel>
        <Panel>
          <h2 className="mb-2 font-semibold text-forest-900">Consent records</h2>
          {a.consent ? (
            <dl className="grid grid-cols-2 gap-x-4">
              <KV k="FCRA disclosure accepted" v={fmtDate(a.consent.fcraDisclosureAcceptedAt)} />
              <KV k="Screening authorization" v={fmtDate(a.consent.authorizationAcceptedAt)} />
              <KV k="Document version" v={a.consent.version} />
            </dl>
          ) : <p className="text-sm text-slate-500">No consent record on file.</p>}
        </Panel>
      </div>

      <Panel className="mt-4">
        <h2 className="mb-2 font-semibold text-forest-900">Rental history</h2>
        {a.rentalHistory?.length ? (
          <ul className="divide-y divide-forest-100 text-sm">
            {a.rentalHistory.map((r: any, i: number) => (
              <li key={i} className="py-2">
                <strong>{r.address}</strong> · {r.from} – {r.to ?? "present"} · {r.rentCents != null ? usd(r.rentCents) : "—"}
                <div className="text-xs text-slate-500">Landlord: {r.landlord ?? "—"} · Reason for leaving: {r.reason ?? "—"}</div>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-slate-500">No rental history provided.</p>}
      </Panel>

      {canUpdate && (
        <Panel className="mt-4">
          <h2 className="mb-2 font-semibold text-forest-900">Update status</h2>
          <div className="grid gap-2 sm:grid-cols-3">
            <select aria-label="New status" className={ginput} value={target} onChange={(e) => setTarget(e.target.value)}>
              <option value="">Choose status…</option>
              {NEXT.filter((s) => s !== a.status).map((s) => <option key={s}>{s}</option>)}
            </select>
            <input aria-label="Reason" className={`${ginput} sm:col-span-2`} placeholder={target === "rejected" ? "Reason (required, 10+ characters)" : "Reason (optional)"} value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
          {target === "rejected" && (
            <label className="mt-2 flex items-start gap-2 text-sm">
              <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-1" />
              I have personally reviewed any screening report. Rejection is a human decision; adverse-action notices may be required.
            </label>
          )}
          <button className={`${gbtn} mt-3`} disabled={!target} onClick={() => setConfirm(true)}>Update status</button>
        </Panel>
      )}

      <Panel className="mt-4">
        <h2 className="mb-2 font-semibold text-forest-900">Status history</h2>
        {a.statusHistory?.length ? (
          <ul className="space-y-1 text-sm">{[...a.statusHistory].reverse().map((h: any, i: number) => (
            <li key={i}>{fmtDate(h.at)} · {h.from} → <strong>{h.to}</strong> by {h.byEmail}{h.reason ? ` — ${h.reason}` : ""}</li>
          ))}</ul>
        ) : <p className="text-sm text-slate-500">No status changes yet.</p>}
      </Panel>

      <Panel className="mt-4">
        <h2 className="mb-2 font-semibold text-forest-900">Internal notes</h2>
        {canUpdate && (
          <form onSubmit={addNote} className="mb-3 flex flex-col gap-2 sm:flex-row">
            <textarea aria-label="New note" className={ginput} rows={2} maxLength={2000} required value={note} onChange={(e) => setNote(e.target.value)} placeholder="Internal only — never shown to the applicant" />
            <button className={gbtn2}>Add note</button>
          </form>
        )}
        {a.notes?.length ? (
          <ul className="space-y-2 text-sm">{a.notes.map((n: any) => (
            <li key={n.id} className="rounded-lg bg-forest-50 p-2">{n.note}<div className="mt-1 text-xs text-slate-500">{n.authorEmail} · {fmtDate(n.createdAt)}</div></li>
          ))}</ul>
        ) : <p className="text-sm text-slate-500">No notes.</p>}
      </Panel>

      {confirm && (
        <ConfirmDialog
          title="Confirm status change"
          message={`Change status from "${a.status}" to "${target}"? This is recorded in the audit log.`}
          confirmLabel="Confirm"
          danger={target === "rejected"}
          onConfirm={changeStatus}
          onCancel={() => setConfirm(false)}
        />
      )}
    </div>
  );
}
