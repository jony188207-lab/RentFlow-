"use client";
import { useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { Badge, Empty, ErrorBox, Modal, PageHeader, Panel, SampleTag, Spinner, TableWrap, Td, Th, fmtDate, gbtn, gbtn2, ginput } from "@/components/admin/ui";

// The unlock token is held in memory only (never localStorage) and expires server-side after 10 minutes.
export default function ProtectedPage() {
  const { api, rawFetch, can } = useAdmin();
  const [token, setToken] = useState<string | null>(null);
  const [needTotp, setNeedTotp] = useState(false);
  const [pw, setPw] = useState("");
  const [totp, setTotp] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [reports, setReports] = useState<any[] | null>(null);
  const [view, setView] = useState<any | null>(null);

  if (!can("protected.view"))
    return (
      <div>
        <PageHeader title="Protected information" />
        <Panel>Your account is not authorized for protected information. A super administrator must grant this access explicitly.</Panel>
      </div>
    );

  const auth = (t = token) => ({ "x-unlock-token": t ?? "" });
  const expired = () => { setToken(null); setReports(null); setView(null); setPw(""); setTotp(""); setErr("Session expired. Re-enter your password."); };

  async function unlock(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(null);
    const r = await api("/api/admin/protected/unlock", { method: "POST", body: { password: pw, totp: totp || undefined } });
    setBusy(false); setPw("");
    if (r.ok) { setToken(r.data.unlockToken); setNeedTotp(false); setTotp(""); await load(r.data.unlockToken); return; }
    if (r.data.requireTotp) setNeedTotp(true);
    if (r.status === 429) setErr(`Locked after too many attempts. Try again in about ${Math.ceil((r.data.retryAfterSeconds ?? 0) / 60)} minute(s).`);
    else if (r.data.locked) { setNeedTotp(true); setErr("Too many incorrect attempts. Access is temporarily locked; an authenticator code will be required afterwards."); }
    else setErr(r.data.error ?? "Verification failed");
  }

  async function load(t: string) {
    const r = await api("/api/admin/protected/reports", { headers: auth(t) });
    if (r.status === 403) return expired();
    if (!r.ok) return setErr(r.data.error ?? "Could not load reports");
    setReports(r.data.items);
  }

  async function open(id: string) {
    const r = await api(`/api/admin/protected/reports/${id}`, { headers: auth() });
    if (r.status === 403) return expired();
    if (!r.ok) return setErr(r.data.error ?? "Could not open report");
    setView(r.data);
  }

  async function download(id: string) {
    const res = await rawFetch(`/api/admin/protected/reports/${id}?download=1`, { headers: auth() });
    if (res.status === 403) return expired();
    if (!res.ok) return setErr("Download failed");
    const url = URL.createObjectURL(await res.blob());
    Object.assign(document.createElement("a"), { href: url, download: `report-${id}.json` }).click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHeader title="Protected information">
        {token && <button className={gbtn2} onClick={expired}>Lock now</button>}
      </PageHeader>
      <ErrorBox text={err} />
      {!token ? (
        <form onSubmit={unlock} className="max-w-sm space-y-3 rounded-xl border border-forest-100 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-600">Re-enter your password to open screening reports. Every access attempt is logged.</p>
          <input aria-label="Password" type="password" autoComplete="current-password" required className={ginput} value={pw} onChange={(e) => setPw(e.target.value)} />
          {needTotp && <input aria-label="Authenticator code" inputMode="numeric" pattern="\d{6}" maxLength={6} required className={ginput} placeholder="6-digit authenticator code" value={totp} onChange={(e) => setTotp(e.target.value)} />}
          <button className={gbtn} disabled={busy}>{busy ? "Verifying…" : "Unlock"}</button>
        </form>
      ) : reports === null ? <Spinner /> : reports.length === 0 ? <Empty text="No screening reports stored." /> : (
        <TableWrap>
          <thead><tr><Th>Report</Th><Th>Application</Th><Th>Provider-verified</Th><Th>Created</Th><Th /></tr></thead>
          <tbody className="divide-y divide-forest-100">
            {reports.map((r) => (
              <tr key={r.id}>
                <Td>{r.id}{r.isSample && <SampleTag />}</Td><Td>{r.applicationId}</Td>
                <Td><Badge value={r.verified ? "completed" : "manual_review"} /> {r.verified ? "Verified" : "Not verified"}</Td>
                <Td>{fmtDate(r.createdAt)}</Td>
                <Td><div className="flex gap-1"><button className={gbtn2} onClick={() => open(r.id)}>View</button><button className={gbtn2} onClick={() => download(r.id)}>Download</button></div></Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
      {view && (
        <Modal title={`Report ${view.id}`} onClose={() => setView(null)} wide>
          {!view.verified && <p className="mb-2 rounded bg-amber-50 p-2 text-sm text-amber-900">This result is not provider-verified and must not be treated as a real screening result.</p>}
          <pre className="max-h-96 overflow-auto rounded-lg bg-slate-900 p-3 text-xs text-slate-100">{JSON.stringify(view.payload, null, 2)}</pre>
        </Modal>
      )}
    </div>
  );
}
