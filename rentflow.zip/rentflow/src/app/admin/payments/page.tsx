"use client";
import { useEffect, useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, DataToggle, Empty, ErrorBox, Modal, PageHeader, SampleTag, Spinner, TableWrap, Td, Th, fmtDate, gbtn, gbtn2, ginput, usd } from "@/components/admin/ui";

const STATUSES = ["pending_verification", "verified", "rejected", "refund_pending", "refunded", "pending", "succeeded", "failed"];

export default function PaymentsPage() {
  const { api, rawFetch, can } = useAdmin();
  const [data, setData] = useState<"real" | "sample">("real");
  const [status, setStatus] = useState("pending_verification"); // review queue first
  const [q, setQ] = useState("");
  const [applied, setApplied] = useState("");
  const [open, setOpen] = useState<string | null>(null);

  const qs = new URLSearchParams({ data });
  if (status) qs.set("status", status);
  if (applied) qs.set("q", applied);
  const { data: res, error, loading, reload } = useLoad<any>(`/api/admin/payments?${qs}`);

  return (
    <div>
      <PageHeader title="Payment review"><DataToggle value={data} onChange={setData} /></PageHeader>
      <p className="mb-3 text-xs text-slate-500">A submitted screenshot is only a claim. Confirm in the receiving account that the money arrived before verifying. Card numbers and security codes are never stored.</p>
      <form className="mb-4 grid gap-2 sm:grid-cols-4" onSubmit={(e) => { e.preventDefault(); setApplied(q.trim()); }}>
        <input aria-label="Search" className={`${ginput} sm:col-span-2`} placeholder="Payment ID, application reference or provider reference" value={q} onChange={(e) => setQ(e.target.value)} />
        <select aria-label="Status" className={ginput} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
        </select>
        <button className={gbtn}>Search</button>
      </form>
      {loading ? <Spinner /> : error ? <ErrorBox text={error} /> : !res?.items.length ? <Empty text={status === "pending_verification" ? "No payments are waiting for verification." : "No payments found."} /> : (
        <TableWrap>
          <thead><tr><Th>Payment</Th><Th>Application</Th><Th>Method</Th><Th>Amount</Th><Th>Status</Th><Th>Submitted</Th><Th /></tr></thead>
          <tbody className="divide-y divide-forest-100">
            {res.items.map((p: any) => (
              <tr key={p.id} className="hover:bg-forest-50">
                <Td><span className="break-all">{p.id}</span>{p.isSample && <SampleTag />}{p.needsReview && <div className="text-xs font-semibold text-red-700">Amount mismatch</div>}</Td>
                <Td>{p.applicationId ?? <span className="text-xs text-slate-400">not yet applied</span>}</Td>
                <Td>{p.methodName ?? p.provider}</Td>
                <Td>{usd(p.amountCents)} <span className="text-xs text-slate-500">{String(p.currency).toUpperCase()}</span>{p.promoCode && <div className="text-xs text-slate-500">promo {p.promoCode}</div>}</Td>
                <Td><Badge value={p.status} />{p.refundStatus !== "none" && <div className="mt-1"><Badge value={p.refundStatus === "pending" ? "refund_pending" : p.refundStatus} /></div>}</Td>
                <Td>{fmtDate(p.createdAt)}</Td>
                <Td><button className="font-semibold text-forest-700 underline" onClick={() => setOpen(p.id)}>Review</button></Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
      {open && <ReviewModal id={open} onClose={() => setOpen(null)} onChanged={reload} canManage={can("payments.manage")} api={api} rawFetch={rawFetch} />}
    </div>
  );
}

function ReviewModal({ id, onClose, onChanged, canManage, api, rawFetch }: { id: string; onClose: () => void; onChanged: () => void; canManage: boolean; api: ReturnType<typeof useAdmin>["api"]; rawFetch: ReturnType<typeof useAdmin>["rawFetch"] }) {
  const { data: p, loading, error, reload } = useLoad<any>(`/api/admin/payments/${id}`);
  const [msg, setMsg] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [proof, setProof] = useState<string | null>(null);
  const [proofErr, setProofErr] = useState<string | null>(null);

  // Screenshot comes from private storage through an authorized, audited API call (never a public URL).
  useEffect(() => {
    if (!p?.hasProof) return;
    let url: string | null = null;
    rawFetch(`/api/admin/payments/${id}/proof`).then(async (r) => {
      if (!r.ok) return setProofErr("Could not load screenshot");
      url = URL.createObjectURL(await r.blob());
      setProof(url);
    });
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [p?.hasProof, id, rawFetch]);

  async function act(action: string, needNotes = false) {
    setMsg(null);
    if (needNotes && notes.trim().length < 5) return setMsg("Add a note (at least 5 characters)");
    const r = await api(`/api/admin/payments/${id}`, { method: "POST", body: { action, ...(notes.trim() ? { notes: notes.trim() } : {}) } });
    if (!r.ok) return setMsg(r.data.error ?? "Action failed");
    setNotes(""); reload(); onChanged();
  }

  return (
    <Modal title={`Payment ${id}`} onClose={onClose} wide>
      {loading ? <Spinner /> : error || !p ? <ErrorBox text={error} /> : (
        <div className="space-y-4 text-sm">
          <ErrorBox text={msg} />
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="mb-1 font-semibold text-forest-900">Payment</h3>
              <dl className="grid grid-cols-2 gap-2">
                <div><dt className="text-xs text-slate-500">Amount</dt><dd>{usd(p.amountCents)} {String(p.currency).toUpperCase()}</dd></div>
                <div><dt className="text-xs text-slate-500">Status</dt><dd><Badge value={p.status} /></dd></div>
                <div><dt className="text-xs text-slate-500">Method</dt><dd>{p.methodName ?? p.provider}</dd></div>
                <div><dt className="text-xs text-slate-500">Submitted</dt><dd>{fmtDate(p.createdAt)}</dd></div>
                <div className="col-span-2"><dt className="text-xs text-slate-500">Transaction reference (applicant-entered)</dt><dd className="break-all">{p.transactionRef ?? p.providerRef ?? "—"}</dd></div>
                {p.promoCode && <div className="col-span-2"><dt className="text-xs text-slate-500">Promo</dt><dd>{p.promoCode} (−{usd(p.discountCents)} from {usd(p.baseCents)})</dd></div>}
                <div><dt className="text-xs text-slate-500">Refund</dt><dd>{p.refundStatus}</dd></div>
                {p.reviewedByEmail && <div><dt className="text-xs text-slate-500">Last reviewed by</dt><dd>{p.reviewedByEmail}</dd></div>}
              </dl>
              {p.reviewNotes && <p className="mt-2 rounded bg-forest-50 p-2">Review notes: {p.reviewNotes}</p>}
            </div>
            <div>
              <h3 className="mb-1 font-semibold text-forest-900">Applicant</h3>
              {p.application ? (
                <dl className="space-y-1">
                  <div><dt className="inline text-slate-500">Name: </dt><dd className="inline">{p.application.applicantName}</dd></div>
                  <div><dt className="inline text-slate-500">Reference: </dt><dd className="inline"><a className="font-semibold text-forest-700 underline" href={`/admin/applications/${p.application.reference}`}>{p.application.reference}</a></dd></div>
                  <div><dt className="inline text-slate-500">Property: </dt><dd className="inline">{p.application.propertyAddress ?? "—"}</dd></div>
                  <div><dt className="inline text-slate-500">Application status: </dt><dd className="inline"><Badge value={p.application.status} /></dd></div>
                </dl>
              ) : <p className="text-slate-500">No application attached yet. Applicant: {p.applicantEmail ?? "unknown"}</p>}
            </div>
          </div>

          <div>
            <h3 className="mb-1 font-semibold text-forest-900">Screenshot</h3>
            {!p.hasProof ? <p className="text-slate-500">No screenshot submitted.</p> : proofErr ? <ErrorBox text={proofErr} /> : !proof ? <Spinner /> : <img src={proof} alt="Payment screenshot submitted by applicant" className="max-h-96 w-auto rounded-lg border border-forest-100" />}
          </div>

          {canManage && p.source === "manual" && (
            <div className="space-y-2 rounded-lg border border-forest-100 p-3">
              <textarea aria-label="Review notes" className={ginput} rows={2} maxLength={1000} placeholder="Review notes (required to reject or for refunds)" value={notes} onChange={(e) => setNotes(e.target.value)} />
              <div className="flex flex-wrap gap-2">
                {["pending_verification", "rejected"].includes(p.status) && <button className={gbtn} onClick={() => act("approve")}>Verify payment</button>}
                {["pending_verification", "verified"].includes(p.status) && <button className="inline-flex rounded-lg bg-red-700 px-3 py-2 text-sm font-semibold text-white hover:bg-red-800" onClick={() => act("reject", true)}>Reject</button>}
                {p.status === "verified" && <button className={gbtn2} onClick={() => act("refund_pending", true)}>Mark refund pending</button>}
                {p.status === "refund_pending" && <button className={gbtn2} onClick={() => act("mark_refunded", true)}>Mark refunded</button>}
              </div>
              <p className="text-xs text-slate-500">Refunds are sent from your payment account outside RentFlow; this only records their status.</p>
            </div>
          )}
          {canManage && p.source !== "manual" && (
            <div className="flex flex-wrap gap-2">
              <button className={gbtn} onClick={() => act("verify")}>Verify with provider</button>
            </div>
          )}

          <div>
            <h3 className="mb-1 font-semibold text-forest-900">History</h3>
            {p.history.length ? <ul className="space-y-1">{p.history.map((h: any) => <li key={h.id}>{fmtDate(h.at)} · <Badge value={h.status} /> · <span className="text-slate-500">{h.source}</span>{h.notes ? ` — ${h.notes}` : ""}</li>)}</ul> : <p className="text-slate-500">No events recorded.</p>}
          </div>
        </div>
      )}
    </Modal>
  );
}
