"use client";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Empty, ErrorBox, PageHeader, Panel, SampleTag, Spinner, fmtDate, gbtn2 } from "@/components/admin/ui";

const ICON: Record<string, string> = {
  "application.new": "📄", "payment.proof_submitted": "🧾", "payment.completed": "✅", "payment.failed": "⚠️",
  "screening.completed": "🔎", "screening.manual_review": "👤", "system.error": "🛑",
};

export default function NotificationsPage() {
  const { api } = useAdmin();
  const { data, error, loading, reload } = useLoad<any>("/api/admin/notifications");
  const markAll = async () => { await api("/api/admin/notifications", { method: "PATCH", body: { all: true } }); reload(); };
  const markOne = async (id: string) => { await api("/api/admin/notifications", { method: "PATCH", body: { ids: [id] } }); reload(); };

  return (
    <div>
      <PageHeader title="Notifications"><button className={gbtn2} onClick={markAll}>Mark all read</button></PageHeader>
      {loading ? <Spinner /> : error ? <ErrorBox text={error} /> : !data?.items.length ? <Empty text="No notifications yet." /> : (
        <ul className="space-y-2">
          {data.items.map((n: any) => (
            <li key={n.id}>
              <Panel className={n.read ? "opacity-70" : "border-forest-500"}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{ICON[n.type] ?? "🔔"} {n.title}{n.isSample && <SampleTag />}</p>
                    <p className="text-sm text-slate-600">{n.message}</p>
                    <p className="mt-1 text-xs text-slate-500">{fmtDate(n.createdAt)}</p>
                  </div>
                  {!n.read && <button className="text-sm font-semibold text-forest-700 underline" onClick={() => markOne(n.id)}>Mark read</button>}
                </div>
              </Panel>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
