"use client";
import { useState } from "react";
import Link from "next/link";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, ConfirmDialog, Empty, ErrorBox, PageHeader, Panel, Spinner, TableWrap, Td, Th, fmtDate, gbtn, gbtn2, ginput, usd } from "@/components/admin/ui";

export default function PricingPage() {
  const { api, can } = useAdmin();
  const settings = useLoad<any>("/api/admin/settings");
  const promos = useLoad<any>("/api/admin/promo-codes");
  const [code, setCode] = useState("");
  const [type, setType] = useState<"percent" | "fixed">("percent");
  const [value, setValue] = useState("");
  const [endsAt, setEndsAt] = useState("");
  const [maxUses, setMaxUses] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [del, setDel] = useState<string | null>(null);
  const write = can("settings.write");

  if (settings.loading || promos.loading) return <Spinner />;
  if (settings.error || !settings.data) return <ErrorBox text={settings.error} />;
  const a = settings.data.app;

  async function create(e: React.FormEvent) {
    e.preventDefault(); setMsg(null);
    const n = Number(value);
    const r = await api("/api/admin/promo-codes", {
      method: "POST",
      body: { code, type, value: type === "percent" ? Math.round(n) : Math.round(n * 100), ...(endsAt ? { endsAt: new Date(endsAt + "T23:59:59Z").toISOString() } : {}), ...(maxUses ? { maxUses: Number(maxUses) } : {}) },
    });
    if (!r.ok) return setMsg(r.data.error ?? "Could not create promo code");
    setCode(""); setValue(""); setEndsAt(""); setMaxUses(""); promos.reload();
  }
  async function toggle(p: any) {
    const r = await api(`/api/admin/promo-codes/${p.code}`, { method: "PATCH", body: { active: !p.active } });
    if (!r.ok) setMsg(r.data.error ?? "Update failed");
    promos.reload();
  }
  async function remove() {
    await api(`/api/admin/promo-codes/${del}`, { method: "DELETE" });
    setDel(null); promos.reload();
  }

  return (
    <div className="space-y-4">
      <PageHeader title="Pricing & promo codes" />
      <Panel>
        <p className="text-sm text-slate-600">Current application fee</p>
        <p className="text-3xl font-bold text-forest-900">{usd(a.totalFeeCents)} <span className="text-base font-medium text-slate-500">{a.baseCurrency}</span></p>
        <p className="mt-2 text-sm text-slate-600">
          Change the fee and currency in <Link className="font-semibold text-forest-700 underline" href="/admin/settings">Settings</Link>. A new fee applies only to <strong>new</strong> payments; every existing payment keeps the amount, discount and promo recorded when it was submitted. The server always computes the price; amounts from the browser are ignored. A method can also use its own fixed amount/currency (Payment methods).
        </p>
      </Panel>

      <Panel>
        <h2 className="mb-2 font-semibold text-forest-900">Promo codes</h2>
        <ErrorBox text={msg} />
        {write && (
          <form onSubmit={create} className="mb-4 grid gap-2 sm:grid-cols-6">
            <input aria-label="Code" className={`${ginput} sm:col-span-2`} placeholder="CODE" required value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} />
            <select aria-label="Type" className={ginput} value={type} onChange={(e) => setType(e.target.value as any)}><option value="percent">Percent off</option><option value="fixed">Fixed off</option></select>
            <input aria-label="Value" className={ginput} inputMode="decimal" required placeholder={type === "percent" ? "10 (%)" : "5.00 ($)"} value={value} onChange={(e) => setValue(e.target.value)} />
            <input aria-label="Expires" className={ginput} type="date" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
            <input aria-label="Max uses" className={ginput} type="number" min={1} placeholder="Max uses" value={maxUses} onChange={(e) => setMaxUses(e.target.value)} />
            <button className={`${gbtn} sm:col-span-6 sm:w-40`}>Add promo code</button>
          </form>
        )}
        {!promos.data?.items.length ? <Empty text="No promo codes." /> : (
          <TableWrap>
            <thead><tr><Th>Code</Th><Th>Discount</Th><Th>Used</Th><Th>Expires</Th><Th>Status</Th><Th /></tr></thead>
            <tbody className="divide-y divide-forest-100">
              {promos.data.items.map((p: any) => (
                <tr key={p.code}>
                  <Td>{p.code}</Td>
                  <Td>{p.type === "percent" ? `${p.value}%` : usd(p.value)}</Td>
                  <Td>{p.usedCount}{p.maxUses ? ` / ${p.maxUses}` : ""}</Td>
                  <Td>{p.endsAt ? fmtDate(p.endsAt) : "—"}</Td>
                  <Td><Badge value={p.active ? "completed" : "queued"} /> {p.active ? "Active" : "Off"}</Td>
                  <Td>{write && <div className="flex gap-1"><button className={gbtn2} onClick={() => toggle(p)}>{p.active ? "Disable" : "Enable"}</button><button className={gbtn2} onClick={() => setDel(p.code)}>Delete</button></div>}</Td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        )}
      </Panel>
      {del && <ConfirmDialog title="Delete promo code" message={`Delete ${del}? Past payments keep their recorded discount.`} confirmLabel="Delete" danger onConfirm={remove} onCancel={() => setDel(null)} />}
    </div>
  );
}
