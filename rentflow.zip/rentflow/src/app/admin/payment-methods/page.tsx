"use client";
import { useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, ConfirmDialog, Empty, ErrorBox, Modal, PageHeader, Panel, Spinner, gbtn, gbtn2, ginput, usd } from "@/components/admin/ui";

type Form = {
  provider: string; enabled: boolean; displayName: string; description: string; instructions: string; applicantGuidance: string;
  paymentUrl: string; identifier: string; amountMode: "global" | "fixed"; fixedAmount: string; currency: string; displayOrder: string; countries: string;
};
const blank = (provider = "stripe", label = "Stripe"): Form => ({
  provider, enabled: false, displayName: label, description: "", instructions: "", applicantGuidance: "",
  paymentUrl: "", identifier: "", amountMode: "global", fixedAmount: "", currency: "USD", displayOrder: "100", countries: "",
});

export default function PaymentMethodsPage() {
  const { api, rawFetch, can } = useAdmin();
  const { data, error, loading, reload } = useLoad<any>("/api/admin/payment-methods");
  const [editing, setEditing] = useState<{ id: string | null; form: Form; hasQr: boolean } | null>(null);
  const [del, setDel] = useState<any | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [qrFile, setQrFile] = useState<File | null>(null);
  const manage = can("paymentMethods.manage");

  if (loading) return <Spinner />;
  if (error || !data) return <ErrorBox text={error} />;
  const caps = data.capabilities as Record<string, any>;

  const toForm = (m: any): Form => ({
    provider: m.provider, enabled: m.enabled, displayName: m.displayName, description: m.description ?? "", instructions: m.instructions ?? "",
    applicantGuidance: m.applicantGuidance ?? "", paymentUrl: m.paymentUrl ?? "", identifier: m.identifier ?? "",
    amountMode: m.amountMode ?? "global", fixedAmount: m.fixedAmountCents ? (m.fixedAmountCents / 100).toFixed(2) : "", currency: m.currency ?? "USD",
    displayOrder: String(m.displayOrder ?? 100), countries: (m.countries ?? []).join(", "),
  });

  const payload = (f: Form) => ({
    provider: f.provider, enabled: f.enabled, displayName: f.displayName, description: f.description, instructions: f.instructions,
    applicantGuidance: f.applicantGuidance, paymentUrl: f.paymentUrl, identifier: f.identifier, amountMode: f.amountMode,
    ...(f.amountMode === "fixed" ? { fixedAmountCents: Math.round(Number(f.fixedAmount) * 100) } : {}),
    currency: f.currency.toUpperCase(), displayOrder: Number(f.displayOrder),
    countries: f.countries.split(",").map((c) => c.trim().toUpperCase()).filter(Boolean),
  });

  async function save() {
    if (!editing) return;
    setMsg(null);
    const r = editing.id
      ? await api(`/api/admin/payment-methods/${editing.id}`, { method: "PUT", body: payload(editing.form) })
      : await api("/api/admin/payment-methods", { method: "POST", body: payload(editing.form) });
    if (!r.ok) return setMsg(r.data.error ?? "Save failed");
    const id = editing.id ?? r.data.id;
    if (qrFile && caps[editing.form.provider].supportsQr) {
      const fd = new FormData(); fd.append("qr", qrFile);
      const q = await rawFetch(`/api/admin/payment-methods/${id}/qr`, { method: "POST", body: fd });
      if (!q.ok) return setMsg((await q.json().catch(() => ({}))).error ?? "QR upload failed");
    }
    setEditing(null); setQrFile(null); reload();
  }
  async function removeQr() {
    if (!editing?.id) return;
    const r = await api(`/api/admin/payment-methods/${editing.id}/qr`, { method: "DELETE" });
    if (!r.ok) return setMsg(r.data.error ?? "Could not remove QR");
    setEditing({ ...editing, hasQr: false }); reload();
  }
  async function doDelete() {
    const r = await api(`/api/admin/payment-methods/${del.id}`, { method: "DELETE" });
    setDel(null);
    if (!r.ok) setMsg(r.data.error ?? "Delete failed");
    reload();
  }
  async function toggle(m: any) {
    const f = { ...toForm(m), enabled: !m.enabled };
    const r = await api(`/api/admin/payment-methods/${m.id}`, { method: "PUT", body: payload(f) });
    if (!r.ok) setMsg(r.data.error ?? "Update failed");
    reload();
  }

  const set = (k: keyof Form, v: any) => editing && setEditing({ ...editing, form: { ...editing.form, [k]: v } });
  const cap = editing ? caps[editing.form.provider] : null;

  return (
    <div>
      <PageHeader title="Payment methods">
        {manage && <button className={gbtn} onClick={() => { setMsg(null); setEditing({ id: null, form: blank(), hasQr: false }); }}>Add method</button>}
      </PageHeader>
      <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
        These methods collect <strong>manual payments</strong>: the applicant pays outside RentFlow and submits a reference and screenshot. A screenshot is never treated as a successful payment; an admin must verify that the money arrived. Only enter accounts and links <strong>you own</strong>. Every change is audit-logged{manage ? "" : " (only a super administrator can change methods)"}.
      </div>
      <ErrorBox text={msg} />
      {data.items.length === 0 ? <Empty text="No payment methods yet. Add one to let applicants pay." /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {data.items.map((m: any) => (
            <Panel key={m.id}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-forest-900">{m.displayName}</p>
                  <p className="text-xs text-slate-500">{caps[m.provider]?.label} · order {m.displayOrder} · {m.countries?.length ? m.countries.join(", ") : "all countries"}</p>
                </div>
                <Badge value={m.enabled ? "completed" : "queued"} />
              </div>
              <dl className="mt-2 space-y-1 text-sm">
                {m.paymentUrl && <div className="break-all"><dt className="inline text-slate-500">Link: </dt><dd className="inline">{m.paymentUrl}</dd></div>}
                {m.identifier && <div><dt className="inline text-slate-500">Identifier: </dt><dd className="inline">{m.identifier}</dd></div>}
                <div><dt className="inline text-slate-500">Amount: </dt><dd className="inline">{m.amountMode === "fixed" ? `${usd(m.fixedAmountCents)} ${m.currency}` : "Global application fee"}</dd></div>
                <div><dt className="inline text-slate-500">QR code: </dt><dd className="inline">{m.hasQr ? "Uploaded" : "None"}</dd></div>
              </dl>
              {manage && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className={gbtn2} onClick={() => { setMsg(null); setEditing({ id: m.id, form: toForm(m), hasQr: m.hasQr }); }}>Edit</button>
                  <button className={gbtn2} onClick={() => toggle(m)}>{m.enabled ? "Disable" : "Enable"}</button>
                  <button className="rounded-lg border border-red-200 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-50" onClick={() => setDel(m)}>Delete</button>
                </div>
              )}
            </Panel>
          ))}
        </div>
      )}

      {editing && cap && (
        <Modal title={editing.id ? "Edit payment method" : "Add payment method"} onClose={() => setEditing(null)} wide>
          <div className="space-y-3 text-sm">
            <ErrorBox text={msg} />
            <div className="grid gap-3 sm:grid-cols-2">
              <label>Provider
                <select className={ginput} value={editing.form.provider} disabled={Boolean(editing.id)} onChange={(e) => { set("provider", e.target.value); if (!editing.form.displayName || Object.values(caps).some((c: any) => c.label === editing.form.displayName)) set("displayName", caps[e.target.value].label); }}>
                  {Object.entries(caps).map(([k, c]: any) => <option key={k} value={k}>{c.label}</option>)}
                </select>
              </label>
              <label>Display name<input className={ginput} maxLength={60} value={editing.form.displayName} onChange={(e) => set("displayName", e.target.value)} /></label>
            </div>
            <p className="rounded bg-forest-50 p-2 text-xs text-forest-900">{cap.note}</p>
            <label className="block">Description (shown to applicants)<textarea className={ginput} rows={2} maxLength={500} value={editing.form.description} onChange={(e) => set("description", e.target.value)} /></label>
            <label className="block">Payment instructions<textarea className={ginput} rows={3} maxLength={2000} value={editing.form.instructions} onChange={(e) => set("instructions", e.target.value)} /></label>
            <label className="block">Guidance for the applicant after paying<textarea className={ginput} rows={2} maxLength={1000} placeholder="e.g. Put your email in the payment note, then upload the confirmation screenshot." value={editing.form.applicantGuidance} onChange={(e) => set("applicantGuidance", e.target.value)} /></label>
            <div className="grid gap-3 sm:grid-cols-2">
              <label>Payment link {cap.supportsUrl ? (cap.urlHosts ? `(${cap.urlHosts.join(", ")})` : "(https only)") : ""}
                <input className={ginput} disabled={!cap.supportsUrl} placeholder={cap.supportsUrl ? "https://…" : "Not supported by this provider"} value={editing.form.paymentUrl} onChange={(e) => set("paymentUrl", e.target.value)} />
              </label>
              <label>{cap.identifierLabel ?? "Identifier"}
                <input className={ginput} disabled={!cap.identifierLabel} placeholder={cap.identifierHint ?? ""} value={editing.form.identifier} onChange={(e) => set("identifier", e.target.value)} />
              </label>
            </div>
            <div className="grid gap-3 sm:grid-cols-4">
              <label>Amount
                <select className={ginput} value={editing.form.amountMode} onChange={(e) => set("amountMode", e.target.value)}>
                  <option value="global">Global fee</option><option value="fixed">Fixed for this method</option>
                </select>
              </label>
              <label>Fixed amount<input className={ginput} inputMode="decimal" disabled={editing.form.amountMode !== "fixed"} value={editing.form.fixedAmount} onChange={(e) => set("fixedAmount", e.target.value)} /></label>
              <label>Currency<input className={ginput} maxLength={3} value={editing.form.currency} disabled={editing.form.amountMode !== "fixed"} onChange={(e) => set("currency", e.target.value.toUpperCase())} /></label>
              <label>Display order<input className={ginput} type="number" min={0} max={1000} value={editing.form.displayOrder} onChange={(e) => set("displayOrder", e.target.value)} /></label>
            </div>
            <label className="block">Available in countries (ISO codes, comma-separated; empty = everywhere)
              <input className={ginput} placeholder="US, CA" value={editing.form.countries} onChange={(e) => set("countries", e.target.value)} />
            </label>
            {cap.supportsQr ? (
              <div>
                <p className="mb-1">QR code image (PNG/JPEG/WebP, max 4 MB) {editing.hasQr && <span className="text-forest-700">· one is uploaded</span>}</p>
                <input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => setQrFile(e.target.files?.[0] ?? null)} />
                {editing.hasQr && editing.id && <button className="ml-3 text-sm font-semibold text-red-700 underline" onClick={removeQr}>Remove QR</button>}
              </div>
            ) : <p className="text-xs text-slate-500">QR codes are not offered for {cap.label}.</p>}
            <label className="flex items-center gap-2"><input type="checkbox" checked={editing.form.enabled} onChange={(e) => set("enabled", e.target.checked)} /> Enabled (visible to applicants)</label>
            <div className="flex justify-end gap-2"><button className={gbtn2} onClick={() => setEditing(null)}>Cancel</button><button className={gbtn} onClick={save}>Save</button></div>
          </div>
        </Modal>
      )}
      {del && <ConfirmDialog title="Delete payment method" message={`Delete "${del.displayName}"? Existing payment records keep their history. This is recorded in the audit log.`} confirmLabel="Delete" danger onConfirm={doDelete} onCancel={() => setDel(null)} />}
    </div>
  );
}
