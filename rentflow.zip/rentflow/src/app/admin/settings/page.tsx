"use client";
import { useEffect, useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { ConfirmDialog, ErrorBox, PageHeader, Panel, Spinner, gbtn, gbtn2, ginput, usd } from "@/components/admin/ui";

const Dot = ({ ok }: { ok: boolean }) => <span className={`mr-2 inline-block h-2.5 w-2.5 rounded-full ${ok ? "bg-forest-500" : "bg-red-500"}`} aria-label={ok ? "configured" : "not configured"} />;

export default function SettingsPage() {
  const { api, can } = useAdmin();
  const { data, error, loading, reload } = useLoad<any>("/api/admin/settings");
  const totp = useLoad<any>("/api/admin/security/totp");
  const [fee, setFee] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [needShot, setNeedShot] = useState(true);
  const [currency, setCurrency] = useState("USD");
  const [maxFail, setMaxFail] = useState("3");
  const [lockMin, setLockMin] = useState("15");
  const [msg, setMsg] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<null | { body: object; text: string }>(null);
  const [enroll, setEnroll] = useState<{ secret: string; otpauthUrl: string } | null>(null);
  const [code, setCode] = useState("");

  useEffect(() => {
    if (!data) return;
    setFee((data.app.totalFeeCents / 100).toFixed(2));
    setEnabled(data.app.applicationsEnabled);
    setNeedShot(data.app.requireScreenshot !== false);
    setCurrency(data.app.baseCurrency ?? "USD");
    setMaxFail(String(data.security.maxFailedAttempts));
    setLockMin(String(data.security.lockoutMinutes));
  }, [data]);

  if (loading) return <Spinner />;
  if (error || !data) return <ErrorBox text={error} />;
  const writable = can("settings.write");
  const superAdmin = can("admins.manage");
  const c = data.configuration;

  async function save() {
    if (!confirm) return;
    setMsg(null); setOk(null);
    const r = await api("/api/admin/settings", { method: "PUT", body: confirm.body });
    setConfirm(null);
    if (!r.ok) return setMsg(r.data.error ?? "Save failed");
    setOk("Saved."); reload();
  }

  const feeCents = Math.round(Number(fee) * 100);
  const feeValid = Number.isFinite(feeCents) && feeCents >= 0 && feeCents <= 50_000;

  async function startEnroll() {
    const r = await api("/api/admin/security/totp", { method: "POST" });
    if (!r.ok) return setMsg(r.data.error ?? "Could not start enrollment");
    setEnroll(r.data);
  }
  async function confirmEnroll() {
    const r = await api("/api/admin/security/totp", { method: "PUT", body: { code } });
    if (!r.ok) return setMsg(r.data.error ?? "Invalid code");
    setEnroll(null); setCode(""); totp.reload(); setOk("Authenticator enabled.");
  }

  return (
    <div className="space-y-4">
      <PageHeader title="Settings" />
      <ErrorBox text={msg} />
      {ok && <div role="status" className="rounded-lg border border-forest-200 bg-forest-50 p-3 text-sm text-forest-900">{ok}</div>}

      <Panel>
        <h2 className="mb-2 font-semibold text-forest-900">Application fee & intake</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm font-medium" htmlFor="fee">Total application fee (USD)</label>
            <input id="fee" inputMode="decimal" className={ginput} value={fee} disabled={!writable} onChange={(e) => setFee(e.target.value)} />
            <p className="mt-1 text-xs text-slate-500">One global fee, $0.00 – $500.00. Current: {usd(data.app.totalFeeCents)}. Check your state's limits on application fees.</p>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium" htmlFor="cur">Base currency (ISO code)</label>
            <input id="cur" maxLength={3} className={ginput} value={currency} disabled={!writable} onChange={(e) => setCurrency(e.target.value.toUpperCase())} />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={enabled} disabled={!writable} onChange={(e) => setEnabled(e.target.checked)} /> Accept new applications
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={needShot} disabled={!writable} onChange={(e) => setNeedShot(e.target.checked)} /> Require a payment screenshot
          </label>
        </div>
        {writable && (
          <button className={`${gbtn} mt-3`} disabled={!feeValid || !/^[A-Z]{3}$/.test(currency)} onClick={() => setConfirm({ body: { totalFeeCents: feeCents, applicationsEnabled: enabled, requireScreenshot: needShot, baseCurrency: currency }, text: `Set the fee to ${usd(feeCents)} ${currency}, ${enabled ? "accept" : "stop accepting"} new applications, and ${needShot ? "require" : "not require"} payment screenshots? New fees apply only to new payments` })}>Save</button>
        )}
      </Panel>

      <Panel>
        <h2 className="mb-2 font-semibold text-forest-900">Configuration status</h2>
        <p className="mb-2 text-xs text-slate-500">Secrets are set as environment variables (Vercel). Values are never shown here.</p>
        <ul className="grid gap-1 text-sm sm:grid-cols-2">
          <li><Dot ok={c.firebaseAdmin} />Firebase Admin credentials</li>
          <li><Dot ok={c.initialAdminEmail} />Initial admin email</li>
          <li><Dot ok={c.dataEncryptionKey} />Data encryption key</li>
          <li><Dot ok={c.protectedAreaSecret} />Protected-area secret</li>
          <li><Dot ok={c.payments.webhookSecret} />Payment webhook secret</li>
          <li><Dot ok={c.payments.provider !== "mock"} />Real payment provider (currently <strong>{c.payments.provider}</strong>, mode <strong>{c.payments.mode}</strong>)</li>
          <li><Dot ok={c.payments.liveEnabled} />Live payments enabled {c.payments.liveEnabled ? "" : "(disabled — correct until verified)"}</li>
          <li><Dot ok={c.screening.provider !== "mock" && c.screening.apiKey} />Screening provider (currently <strong>{c.screening.provider}</strong>)</li>
          <li><Dot ok={c.email.provider !== "console" && c.email.from} />Email provider (currently <strong>{c.email.provider}</strong>)</li>
        </ul>
      </Panel>

      <Panel>
        <h2 className="mb-2 font-semibold text-forest-900">Protected-area security</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label className="mb-1 block text-sm font-medium" htmlFor="mf">Failed attempts before lockout</label>
            <input id="mf" type="number" min={1} max={10} className={ginput} value={maxFail} disabled={!superAdmin} onChange={(e) => setMaxFail(e.target.value)} /></div>
          <div><label className="mb-1 block text-sm font-medium" htmlFor="lm">Lockout minutes</label>
            <input id="lm" type="number" min={1} max={1440} className={ginput} value={lockMin} disabled={!superAdmin} onChange={(e) => setLockMin(e.target.value)} /></div>
        </div>
        {superAdmin ? (
          <button className={`${gbtn} mt-3`} onClick={() => setConfirm({ body: { maxFailedAttempts: Number(maxFail), lockoutMinutes: Number(lockMin) }, text: "Change the protected-area lockout settings?" })}>Save security settings</button>
        ) : <p className="mt-2 text-xs text-slate-500">Only a super administrator can change these.</p>}
      </Panel>

      <Panel>
        <h2 className="mb-2 font-semibold text-forest-900">Your authenticator (two-factor)</h2>
        <p className="mb-2 text-sm text-slate-600">Required as an extra check after repeated incorrect protected-area passwords. {totp.data?.enrolled ? "An authenticator is enrolled." : "Not enrolled."}</p>
        {!totp.data?.enrolled && !enroll && <button className={gbtn2} onClick={startEnroll}>Set up authenticator</button>}
        {enroll && (
          <div className="space-y-2 text-sm">
            <p>Add this account in your authenticator app using the setup key (shown once):</p>
            <code className="block break-all rounded bg-forest-50 p-2">{enroll.secret}</code>
            <input aria-label="Verification code" inputMode="numeric" maxLength={6} className={`${ginput} sm:w-48`} placeholder="6-digit code" value={code} onChange={(e) => setCode(e.target.value)} />
            <div><button className={gbtn} disabled={code.length !== 6} onClick={confirmEnroll}>Confirm</button></div>
          </div>
        )}
      </Panel>

      {confirm && <ConfirmDialog title="Confirm change" message={`${confirm.text} This is recorded in the audit log.`} confirmLabel="Save" onConfirm={save} onCancel={() => setConfirm(null)} />}
    </div>
  );
}
