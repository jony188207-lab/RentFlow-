import { notFound } from "next/navigation";
import { ADMIN_SECTIONS } from "@/components/admin/AdminShell";

// Sections not yet implemented render an honest placeholder. Real modules replace these
// one at a time as dedicated routes (e.g. src/app/admin/applications/page.tsx).
export default function AdminSection({ params }: { params: { section: string } }) {
  const entry = ADMIN_SECTIONS.find(([slug]) => slug === params.section);
  if (!entry) notFound();
  return (
    <div>
      <h1 className="text-2xl font-bold">{entry[1]}</h1>
      <p className="card mt-4 text-sm text-slate-600">
        This module is not implemented yet. It is scheduled in the build order after the foundation.
      </p>
    </div>
  );
}
