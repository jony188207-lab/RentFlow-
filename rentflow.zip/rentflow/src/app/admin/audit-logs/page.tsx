"use client";
import { useState } from "react";
import { useLoad } from "@/components/admin/useLoad";
import { Empty, ErrorBox, PageHeader, Spinner, TableWrap, Td, Th, fmtDate, gbtn, ginput } from "@/components/admin/ui";

const GROUPS = [["", "All events"], ["admin.", "Login / permissions"], ["application.", "Applications"], ["payment.", "Payments"], ["protected.", "Protected access"], ["settings.", "Settings / pricing"], ["security.", "Security"], ["screening.", "Screening"]];

export default function AuditLogsPage() {
  const [prefix, setPrefix] = useState("");
  const [actor, setActor] = useState("");
  const [applied, setApplied] = useState({ prefix: "", actor: "" });
  const qs = new URLSearchParams({ limit: "100" });
  if (applied.prefix) qs.set("actionPrefix", applied.prefix);
  if (applied.actor) qs.set("actorUid", applied.actor);
  const { data, error, loading } = useLoad<any>(`/api/admin/audit-logs?${qs}`);

  return (
    <div>
      <PageHeader title="Audit logs" />
      <p className="mb-3 text-xs text-slate-500">Append-only. Timestamps are set by the server. Audit records cannot be edited or deleted from this application.</p>
      <form className="mb-4 grid gap-2 sm:grid-cols-4" onSubmit={(e) => { e.preventDefault(); setApplied({ prefix, actor: actor.trim() }); }}>
        <select aria-label="Event group" className={ginput} value={prefix} onChange={(e) => setPrefix(e.target.value)}>
          {GROUPS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <input aria-label="Admin UID" className={`${ginput} sm:col-span-2`} placeholder="Filter by admin UID (admin activity)" value={actor} onChange={(e) => setActor(e.target.value)} />
        <button className={gbtn}>Filter</button>
      </form>
      {loading ? <Spinner /> : error ? <ErrorBox text={error} /> : !data?.items.length ? <Empty text="No audit records match." /> : (
        <TableWrap>
          <thead><tr><Th>Time</Th><Th>Action</Th><Th>Admin</Th><Th>Target</Th><Th>Details</Th></tr></thead>
          <tbody className="divide-y divide-forest-100">
            {data.items.map((l: any) => (
              <tr key={l.id}>
                <Td className="whitespace-nowrap">{fmtDate(l.at)}</Td>
                <Td><code className="rounded bg-forest-50 px-1">{l.action}</code></Td>
                <Td>{l.actorEmail ?? l.actorUid}<div className="text-xs text-slate-400">{l.actorUid}</div></Td>
                <Td>{l.targetType ? `${l.targetType}:${l.targetId}` : "—"}</Td>
                <Td className="max-w-xs break-words text-xs text-slate-600">{l.meta && Object.keys(l.meta).length ? JSON.stringify(l.meta) : ""}</Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </div>
  );
}
