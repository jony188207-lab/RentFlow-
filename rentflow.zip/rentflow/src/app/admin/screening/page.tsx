"use client";
import { useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, DataToggle, Empty, ErrorBox, Modal, PageHeader, SampleTag, Spinner, TableWrap, Td, Th, fmtDate, gbtn, gbtn2, ginput } from "@/components/admin/ui";

const STATUSES = ["queued", "running", "action_required", "provider_processing", "completed", "failed", "manual_review"];

export default function ScreeningPage() {
  const { api, can } = useAdmin();
  const [data, setData] = useState<"real" | "sample">("real");
  const [status, setStatus] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [dialog, setDialog] = useState<{ id: string; action: "send_to_manual_review" | "resolve_manual_review" } | null>(null);
  const [note, setNote] = useState("");
  const [appId, setAppId] = useState("");

  const qs = new URLSearchParams({ data });
  if (status) qs.set("status", status);
  const { data: res, error, loading, reload } = useLoad<any>(`/api/admin/screening?${qs}`);
  const manage = can("screening.manage");

  async function act(id: string, body: object) {
    setMsg(null);
    const r = await api(`/api/admin/screening/${id}`, { method: "POST", body });
    if (!r.ok) setMsg(r.data.error ?? "Action failed");
    setDialog(null); setNote(""); reload();
  }
  async function queue(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const r = await api("/api/admin/screening", { method: "POST", body: { applicationId: appId.trim() } });
    if (!r.ok) return setMsg(r.data.error ?? "Could not queue job");
    setAppId(""); reload();
  }

  return (
    <div>
      <PageHeader title="Screening"><DataToggle value={data} onChange={setData} /></PageHeader>
      <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
        No real screening provider is connected. A job is marked <strong>completed</strong> only when an authorized provider returns a verified result. The development demo provider never does, so demo jobs end in manual review.
      </div>
      <ErrorBox text={msg} />
      <div className="mb-4 flex flex-wrap items-end gap-2">
        <select aria-label="Status filter" className={`${ginput} sm:w-56`} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
        </select>
        {manage && (
          <form onSubmit={queue} className="flex flex-1 gap-2 sm:max-w-md">
            <input aria-label="Application ID" className={ginput} placeholder="Application ID to screen" value={appId} onChange={(e) => setAppId(e.target.value)} required />
            <button className={gbtn}>Queue</button>
          </form>
        )}
      </div>

      {loading ? <Spinner /> : error ? <ErrorBox text={error} /> : !res?.items.length ? <Empty text="No screening jobs." /> : (
        <TableWrap>
          <thead><tr><Th>Job ID</Th><Th>Applicant ID</Th><Th>Provider</Th><Th>Status</Th><Th>Manual review</Th><Th>Created</Th><Th>Updated</Th><Th>Error</Th><Th /></tr></thead>
          <tbody className="divide-y divide-forest-100">
            {res.items.map((j: any) => (
              <tr key={j.id}>
                <Td>{j.id}{j.isSample && <SampleTag />}</Td>
                <Td>{j.applicationId}</Td>
                <Td>{j.provider ?? "—"}</Td>
                <Td><Badge value={j.status} /></Td>
                <Td>{j.manualReview?.status && j.manualReview.status !== "none" ? <Badge value={j.manualReview.status === "pending" ? "manual_review" : "resolved"} /> : "—"}</Td>
                <Td>{fmtDate(j.createdAt)}</Td>
                <Td>{fmtDate(j.updatedAt)}</Td>
                <Td className="max-w-[16rem] text-xs text-red-700">{j.error ? `${j.error.code}: ${j.error.message}` : ""}</Td>
                <Td>
                  {manage && (
                    <div className="flex flex-wrap gap-1">
                      {j.status === "queued" && <button className={gbtn2} onClick={() => act(j.id, { action: "run" })}>Run</button>}
                      {(j.status === "failed" || j.status === "action_required") && j.attempts < 3 && <button className={gbtn2} onClick={() => act(j.id, { action: "retry" })}>Retry</button>}
                      {j.status !== "completed" && j.manualReview?.status !== "pending" && <button className={gbtn2} onClick={() => setDialog({ id: j.id, action: "send_to_manual_review" })}>To manual review</button>}
                      {j.manualReview?.status === "pending" && <button className={gbtn} onClick={() => setDialog({ id: j.id, action: "resolve_manual_review" })}>Resolve</button>}
                    </div>
                  )}
                </Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}

      {dialog && (
        <Modal title={dialog.action === "resolve_manual_review" ? "Resolve manual review" : "Send to manual review"} onClose={() => setDialog(null)}>
          <p className="mb-2 text-sm text-slate-600">Record a note. Resolving documents a human decision; it does not mark the screening completed.</p>
          <textarea aria-label="Note" className={ginput} rows={3} value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} />
          <div className="mt-4 flex justify-end gap-2">
            <button className={gbtn2} onClick={() => setDialog(null)}>Cancel</button>
            <button className={gbtn} disabled={note.trim().length < (dialog.action === "resolve_manual_review" ? 10 : 5)} onClick={() => act(dialog.id, { action: dialog.action, note })}>Save</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
