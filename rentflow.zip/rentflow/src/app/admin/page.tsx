"use client";
import { useEffect, useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";

interface Stats { applications: number; payments: number; screeningJobs: number; manualReview: number }

export default function AdminDashboard() {
  const { api } = useAdmin();
  const [stats, setStats] = useState<Stats | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    api("/api/admin/stats")
      .then(async (r) => (r.ok ? setStats(await r.json()) : setErr("Could not load statistics")))
      .catch(() => setErr("Could not load statistics"));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const tiles: [string, number | undefined][] = [
    ["Applications", stats?.applications],
    ["Payments", stats?.payments],
    ["Screening jobs", stats?.screeningJobs],
    ["Awaiting manual review", stats?.manualReview],
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      {err && <p className="mt-2 text-sm text-red-600">{err}</p>}
      <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tiles.map(([label, v]) => (
          <div key={label} className="card">
            <p className="text-xs text-slate-500">{label}</p>
            <p className="mt-1 text-2xl font-bold">{v ?? "—"}</p>
          </div>
        ))}
      </div>
      <p className="mt-6 text-sm text-slate-500">
        Traffic analytics will appear here once an analytics source is connected.
      </p>
    </div>
  );
}
