"use client";
import { useState } from "react";
import { useLoad } from "@/components/admin/useLoad";
import { DataToggle, Empty, ErrorBox, PageHeader, Panel, Spinner, fmtDate, usd } from "@/components/admin/ui";

export default function AdminDashboard() {
  const { data, error, loading } = useLoad<any>("/api/admin/stats");
  const [mode, setMode] = useState<"real" | "sample">("real");

  if (loading) return <Spinner />;
  if (error || !data) return <ErrorBox text={error ?? "Could not load statistics"} />;
  const m = data[mode];
  const tiles: [string, string | number][] = [
    ["Total applications", m.applications.total],
    ["New applications", m.applications.new],
    ["Pending applications", m.applications.pending],
    ["Approved applications", m.applications.approved],
    ["Rejected applications", m.applications.rejected],
    ["Total payment amount", usd(m.payments.totalAmountCents)],
    ["Successful payments", m.payments.successful],
    ["Pending payments", m.payments.pending],
    ["Screening jobs", m.screening.total],
    ["Completed screening", m.screening.completed],
    ["Failed screening", m.screening.failed],
    ["Manual review jobs", m.screening.manualReview],
  ];
  const maxApps = Math.max(1, ...data.daily.map((d: any) => d.applications));
  const maxPay = Math.max(1, ...data.daily.map((d: any) => d.paymentsCents));

  return (
    <div>
      <PageHeader title="Dashboard"><DataToggle value={mode} onChange={setMode} /></PageHeader>
      {mode === "sample" ? (
        <div className="mb-4 rounded-lg border border-fuchsia-200 bg-fuchsia-50 p-3 text-sm text-fuchsia-900">
          Showing <strong>fictional sample data</strong> created by the development seed script. It is not real.
        </div>
      ) : (
        data.sample.applications.total > 0 && (
          <p className="mb-4 text-xs text-slate-500">Sample records exist ({data.sample.applications.total} applications) and are excluded from these real figures.</p>
        )
      )}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tiles.map(([label, v]) => (
          <Panel key={label}>
            <p className="text-xs text-slate-500">{label}</p>
            <p className="mt-1 text-xl font-bold text-forest-900 sm:text-2xl">{v}</p>
          </Panel>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Panel>
          <h2 className="mb-3 font-semibold text-forest-900">Applications (last 14 days, real)</h2>
          <Bars rows={data.daily} value={(d) => d.applications} max={maxApps} label={(v) => String(v)} />
        </Panel>
        <Panel>
          <h2 className="mb-3 font-semibold text-forest-900">Payments received (last 14 days, real)</h2>
          <Bars rows={data.daily} value={(d) => d.paymentsCents} max={maxPay} label={usd} />
        </Panel>
      </div>

      <Panel className="mt-6">
        <h2 className="mb-3 font-semibold text-forest-900">Recent activity</h2>
        {data.recentActivity.length === 0 ? (
          <Empty text="No activity recorded yet." />
        ) : (
          <ul className="divide-y divide-forest-100 text-sm">
            {data.recentActivity.map((a: any) => (
              <li key={a.id} className="flex flex-wrap justify-between gap-2 py-2">
                <span><code className="rounded bg-forest-50 px-1">{a.action}</code> {a.actorEmail ?? ""}</span>
                <span className="text-slate-500">{fmtDate(a.at)}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <p className="mt-4 text-xs text-slate-500">Website traffic analytics are not connected. Add an analytics provider to show visitors here.</p>
    </div>
  );
}

function Bars({ rows, value, max, label }: { rows: any[]; value: (d: any) => number; max: number; label: (v: number) => string }) {
  if (rows.every((d) => value(d) === 0)) return <Empty text="No real records in this period." />;
  return (
    <div className="flex h-32 items-end gap-1" role="img" aria-label="Daily bar chart">
      {rows.map((d) => (
        <div key={d.day} className="flex flex-1 flex-col items-center justify-end" title={`${d.day}: ${label(value(d))}`}>
          <div className="w-full rounded-t bg-forest-500" style={{ height: `${(value(d) / max) * 100}%`, minHeight: value(d) ? 3 : 0 }} />
        </div>
      ))}
    </div>
  );
}
