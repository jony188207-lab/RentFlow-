"use client";
import Link from "next/link";
import { useState } from "react";
import { useAdmin } from "@/components/admin/AdminShell";
import { useLoad } from "@/components/admin/useLoad";
import { Badge, ConfirmDialog, ErrorBox, PageHeader, Panel, Spinner, TableWrap, Td, Th, fmtDate, gbtn, gbtn2, ginput } from "@/components/admin/ui";

export default function AdminsPage() {
  const { api, me } = useAdmin();
  const { data, error, loading, reload } = useLoad<any>("/api/admin/admins");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("reviewer");
  const [protectedAccess, setProtectedAccess] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<{ uid: string; body: object; text: string } | null>(null);

  async function invite(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const r = await api("/api/admin/admins", { method: "POST", body: { email, role, canViewProtected: protectedAccess } });
    if (!r.ok) return setMsg(r.data.error ?? "Could not add admin");
    setEmail(""); setProtectedAccess(false); reload();
  }
  async function patch() {
    if (!confirm) return;
    const r = await api(`/api/admin/admins/${confirm.uid}`, { method: "PATCH", body: confirm.body });
    setConfirm(null);
    if (!r.ok) setMsg(r.data.error ?? "Update failed");
    reload();
  }
  async function revoke(e: string) {
    await api(`/api/admin/admins?email=${encodeURIComponent(e)}`, { method: "DELETE" });
    reload();
  }

  if (loading) return <Spinner />;
  if (error || !data) return <ErrorBox text={error} />;

  return (
    <div>
      <PageHeader title="Admin users" />
      <ErrorBox text={msg} />
      <Panel className="mb-4">
        <h2 className="mb-2 font-semibold text-forest-900">Authorize an admin email</h2>
        <form onSubmit={invite} className="grid gap-2 sm:grid-cols-5">
          <input aria-label="Email" type="email" required className={`${ginput} sm:col-span-2`} placeholder="admin@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          <select aria-label="Role" className={ginput} value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="admin">admin</option><option value="reviewer">reviewer</option><option value="viewer">viewer</option>
          </select>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={protectedAccess} disabled={role === "viewer"} onChange={(e) => setProtectedAccess(e.target.checked)} />Protected info</label>
          <button className={gbtn}>Authorize</button>
        </form>
        <p className="mt-2 text-xs text-slate-500">Access begins when this person signs in with this email and it is verified. Super administrator can only be set by the one-time INITIAL_ADMIN_EMAIL bootstrap.</p>
      </Panel>

      {data.invites.length > 0 && (
        <div className="mb-4">
          <h2 className="mb-2 font-semibold text-forest-900">Pending invitations</h2>
          <ul className="space-y-1 text-sm">{data.invites.map((i: any) => (
            <li key={i.email} className="flex items-center justify-between rounded-lg bg-white p-2 shadow-sm">
              <span>{i.email} · {i.role}{i.canViewProtected ? " · protected" : ""}</span>
              <button className="font-semibold text-red-700 underline" onClick={() => revoke(i.email)}>Revoke</button>
            </li>
          ))}</ul>
        </div>
      )}

      <TableWrap>
        <thead><tr><Th>Admin</Th><Th>Role</Th><Th>Status</Th><Th>Protected info</Th><Th>Added</Th><Th>Actions</Th></tr></thead>
        <tbody className="divide-y divide-forest-100">
          {data.admins.map((a: any) => {
            const locked = a.uid === me.uid || a.role === "super_admin";
            return (
              <tr key={a.uid}>
                <Td>{a.email}<div className="text-xs text-slate-400">{a.uid}</div></Td>
                <Td>{locked ? a.role : (
                  <select aria-label={`Role for ${a.email}`} className={ginput} value={a.role} onChange={(e) => setConfirm({ uid: a.uid, body: { role: e.target.value }, text: `Change ${a.email} to ${e.target.value}?` })}>
                    <option>admin</option><option>reviewer</option><option>viewer</option>
                  </select>
                )}</Td>
                <Td><Badge value={a.active ? "completed" : "failed"} /> {a.active ? "Active" : "Disabled"}</Td>
                <Td>{a.canViewProtected ? "Authorized" : "No"}</Td>
                <Td>{fmtDate(a.createdAt)}</Td>
                <Td>
                  {!locked && (
                    <div className="flex flex-wrap gap-1">
                      <button className={gbtn2} onClick={() => setConfirm({ uid: a.uid, body: { active: !a.active }, text: `${a.active ? "Disable" : "Enable"} ${a.email}?` })}>{a.active ? "Disable" : "Enable"}</button>
                      <button className={gbtn2} onClick={() => setConfirm({ uid: a.uid, body: { canViewProtected: !a.canViewProtected }, text: `${a.canViewProtected ? "Remove" : "Grant"} protected information access for ${a.email}?` })}>{a.canViewProtected ? "Revoke protected" : "Grant protected"}</button>
                      <Link className="self-center text-sm font-semibold text-forest-700 underline" href={`/admin/audit-logs?actor=${a.uid}`}>Activity</Link>
                    </div>
                  )}
                </Td>
              </tr>
            );
          })}
        </tbody>
      </TableWrap>
      {confirm && <ConfirmDialog title="Confirm change" message={`${confirm.text} This is recorded in the audit log.`} confirmLabel="Confirm" onConfirm={patch} onCancel={() => setConfirm(null)} />}
    </div>
  );
}
