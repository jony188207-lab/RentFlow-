import { LegalNotice } from "@/components/LegalNotice";

export const metadata = { title: "Privacy Policy" };

export default function Privacy() {
  return (
    <article className="max-w-3xl space-y-4 text-sm leading-relaxed text-slate-700">
      <LegalNotice />
      <h1 className="text-2xl font-bold text-slate-900">Privacy Policy</h1>
      <h2 className="text-lg font-semibold text-slate-900">Information we collect</h2>
      <p>Contact details, rental property details, household and pet information, employment and income details, rental history, and your screening authorization. Sensitive identifiers (such as a Social Security number) are collected only when required by the screening provider and permitted by law.</p>
      <h2 className="text-lg font-semibold text-slate-900">How we use it</h2>
      <p>To process your rental application, request a consumer report from an authorized screening provider, communicate with you, and meet legal obligations.</p>
      <h2 className="text-lg font-semibold text-slate-900">Protection</h2>
      <p>Sensitive fields are encrypted at rest and access is limited to authorized personnel and logged. Payment card data is handled entirely by our payment provider; we never store full card numbers or security codes.</p>
      <h2 className="text-lg font-semibold text-slate-900">Retention and deletion</h2>
      <p>We keep application data only as long as needed for the purposes above and applicable law, then delete or anonymize it according to our retention schedule. [Operator: insert retention periods.]</p>
      <h2 className="text-lg font-semibold text-slate-900">Your choices</h2>
      <p>See <a className="text-brand-600 underline" href="/applicant-rights">Applicant Rights</a> or <a className="text-brand-600 underline" href="/contact">contact us</a> to request access, correction, or deletion where available.</p>
    </article>
  );
}
