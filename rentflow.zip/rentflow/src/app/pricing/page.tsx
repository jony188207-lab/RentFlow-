import Link from "next/link";
import { formatUsd, getPublicPricing } from "@/lib/settings";

export const metadata = { title: "Pricing" };
export const revalidate = 60;

export default async function Pricing() {
  const p = await getPublicPricing();
  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Pricing</h1>
      <div className="card mt-6">
        <p className="text-sm text-slate-600">Total application fee</p>
        <p className="mt-1 text-4xl font-bold">{formatUsd(p.totalFeeCents)}</p>
        <p className="mt-3 text-sm text-slate-600">
          One fee covers the application and screening report. The amount shown at checkout is final; no hidden charges.
        </p>
        {p.isDefault && (
          <p className="mt-3 rounded bg-amber-50 p-2 text-xs text-amber-900">
            Development default shown. The operator sets the real fee in the admin dashboard.
          </p>
        )}
        <Link href="/apply" className="btn-primary mt-5">
          Start application
        </Link>
      </div>
    </div>
  );
}
