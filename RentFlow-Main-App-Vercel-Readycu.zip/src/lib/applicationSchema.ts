// Shared (client + server) validation for the rental application. The server re-validates everything.
import { z } from "zod";

const text = (max: number) => z.string().trim().min(1, "Required").max(max);
const optText = (max: number) => z.string().trim().max(max).optional().or(z.literal("").transform(() => undefined));
const isoMonthOrDate = z.string().regex(/^\d{4}-\d{2}(-\d{2})?$/, "Use YYYY-MM or YYYY-MM-DD");
const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");
const phone = z.string().trim().regex(/^[0-9+()\-.\s]{7,20}$/, "Enter a valid phone number");

export const PROPERTY_TYPES = ["apartment", "house", "condo", "townhouse", "room", "other"] as const;
export const EMPLOYMENT_STATUSES = ["employed", "self_employed", "student", "retired", "unemployed", "other"] as const;

export function ageOn(dob: string, now = new Date()): number | null {
  const d = new Date(`${dob}T00:00:00Z`);
  if (Number.isNaN(d.getTime())) return null;
  let age = now.getUTCFullYear() - d.getUTCFullYear();
  if (now.getUTCMonth() < d.getUTCMonth() || (now.getUTCMonth() === d.getUTCMonth() && now.getUTCDate() < d.getUTCDate())) age--;
  return age;
}

export const ApplicationInput = z
  .object({
    paymentId: z.string().min(5).max(160),
    personal: z.object({
      firstName: text(60),
      middleName: optText(60),
      lastName: text(60),
      dob: dateStr.refine((v) => { const a = ageOn(v); return a !== null && a >= 18 && a <= 120; }, "You must be at least 18 years old"),
      phone,
      currentAddress: text(250),
    }),
    property: z.object({
      address: text(200),
      unit: optText(30),
      type: z.enum(PROPERTY_TYPES),
      rentCents: z.number().int().min(0).max(10_000_000).optional(),
      moveIn: dateStr,
      leaseMonths: z.number().int().min(1).max(60),
    }),
    household: z.object({
      occupants: z.number().int().min(1).max(20),
      pets: z.array(z.object({ type: text(40), breed: optText(60) })).max(5).default([]),
    }),
    rentalHistory: z
      .array(
        z.object({
          address: text(200),
          landlord: optText(100),
          landlordPhone: optText(30),
          from: isoMonthOrDate,
          to: isoMonthOrDate.optional().or(z.literal("").transform(() => undefined)),
          rentCents: z.number().int().min(0).max(10_000_000).optional(),
          reason: optText(200),
        }),
      )
      .max(5),
    employment: z
      .object({
        status: z.enum(EMPLOYMENT_STATUSES),
        employer: optText(120),
        title: optText(100),
        monthlyIncomeCents: z.number().int().min(0).max(100_000_000),
        additionalIncomeCents: z.number().int().min(0).max(100_000_000).optional(),
        duration: optText(60),
      })
      .superRefine((v, ctx) => {
        if (v.status === "employed" || v.status === "self_employed") {
          if (!v.employer) ctx.addIssue({ code: "custom", path: ["employer"], message: "Required" });
          if (!v.title) ctx.addIssue({ code: "custom", path: ["title"], message: "Required" });
        }
      }),
    documents: z.object({
      govId: z.string().min(5).max(160),
      income: z.array(z.string().min(5).max(160)).min(1, "Upload at least one proof of income").max(5),
    }),
    emergencyContact: z.object({ name: text(100), relationship: text(60), phone }),
    // Optional: collect only if your screening provider requires it. Stored encrypted, shown only in Protected information.
    ssn: z.string().trim().regex(/^\d{3}-?\d{2}-?\d{4}$/, "Enter a valid SSN").optional().or(z.literal("").transform(() => undefined)),
    consent: z.object({
      fcraDisclosure: z.literal(true, { errorMap: () => ({ message: "You must acknowledge the disclosure" }) }),
      backgroundCheck: z.literal(true, { errorMap: () => ({ message: "Background check consent is required to apply" }) }),
      creditCheck: z.literal(true, { errorMap: () => ({ message: "Credit check consent is required to apply" }) }),
      terms: z.literal(true, { errorMap: () => ({ message: "You must accept the Terms & Conditions" }) }),
    }),
    signature: z.string().trim().min(2, "Type your full legal name").max(150),
  })
  .superRefine((v, ctx) => {
    const sig = v.signature.toLowerCase();
    if (!sig.includes(v.personal.firstName.toLowerCase()) || !sig.includes(v.personal.lastName.toLowerCase())) {
      ctx.addIssue({ code: "custom", path: ["signature"], message: "Your electronic signature must include your first and last name" });
    }
  });
export type ApplicationInput = z.infer<typeof ApplicationInput>;
