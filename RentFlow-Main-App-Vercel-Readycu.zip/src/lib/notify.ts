// Admin in-app notifications. Messages must NEVER contain applicant PII or report contents.
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";

export type NotificationType =
  | "application.new"
  | "payment.proof_submitted"
  | "payment.completed"
  | "payment.failed"
  | "screening.completed"
  | "screening.manual_review"
  | "system.error";

export async function createNotification(n: {
  type: NotificationType;
  title: string;
  /** Generic text only, e.g. "Application APP-1042 received". IDs are fine; names/emails are not. */
  message: string;
  link?: string;
  isSample?: boolean;
}): Promise<void> {
  await adminDb()
    .collection("notifications")
    .add({
      type: n.type,
      title: n.title,
      message: n.message,
      link: n.link ?? null,
      read: false,
      isSample: n.isSample === true,
      createdAt: FieldValue.serverTimestamp(),
    });
}

/** In-app notification for ONE applicant (shown in their dashboard). Keep messages free of sensitive details. */
export async function notifyUser(uid: string, n: { title: string; message: string; link?: string }): Promise<void> {
  try {
    await adminDb().collection("userNotifications").add({
      uid,
      title: n.title,
      message: n.message,
      link: n.link ?? null,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    });
  } catch {
    /* A failed courtesy notification must never block the real action. */
  }
}
