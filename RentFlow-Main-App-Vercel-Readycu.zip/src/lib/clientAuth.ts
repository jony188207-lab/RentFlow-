"use client";
// Browser helpers for the signed-in applicant. Email verification is NOT required.
import { useEffect, useState } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { firebaseAuth, missingFirebaseConfig } from "@/lib/firebase/client";

/** undefined = still loading, null = signed out. Never throws: if Firebase is not configured it reports signed out. */
export function useAuthUser(): User | null | undefined {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  useEffect(() => {
    if (missingFirebaseConfig().length) { setUser(null); return; }
    try {
      return onAuthStateChanged(firebaseAuth(), setUser, () => setUser(null));
    } catch (e) {
      console.error("[RentFlow] Could not start Firebase Auth", e);
      setUser(null);
    }
  }, []);
  return user;
}

export type CallInit = { method?: string; body?: unknown; form?: FormData };
export type CallResult = { ok: boolean; status: number; data: any };

/** Authenticated call to our own API. Never throws; returns { ok, status, data }. */
export async function authCall(path: string, init: CallInit = {}): Promise<CallResult> {
  try {
    const token = await firebaseAuth().currentUser?.getIdToken();
    const res = await fetch(path, {
      method: init.method ?? "GET",
      headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(init.body ? { "content-type": "application/json" } : {}) },
      body: init.form ?? (init.body ? JSON.stringify(init.body) : undefined),
    });
    return { ok: res.ok, status: res.status, data: await res.json().catch(() => ({})) };
  } catch {
    return { ok: false, status: 0, data: { error: "Network error. Please try again." } };
  }
}

/** Fetch a private file with the user's token and open it in a new tab. */
export async function openPrivateFile(path: string): Promise<boolean> {
  try {
    const token = await firebaseAuth().currentUser?.getIdToken();
    const res = await fetch(path, { headers: token ? { authorization: `Bearer ${token}` } : {} });
    if (!res.ok) return false;
    const url = URL.createObjectURL(await res.blob());
    window.open(url, "_blank", "noopener");
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return true;
  } catch {
    return false;
  }
}
