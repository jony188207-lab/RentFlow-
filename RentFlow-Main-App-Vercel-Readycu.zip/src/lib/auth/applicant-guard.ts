// Applicant (non-admin) authentication for /api/applicant/*. A verified email is NOT required (accounts work
// with email + password). Every route still verifies the Firebase ID token (with revocation check) and only
// ever reads/writes records whose applicantUid equals the token's uid. Admin access is separate and requires an
// active admins/{uid} record plus a verified email (see admin-guard.ts).
import { adminAuth } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/http";
import { clientIp } from "@/lib/audit";

export interface ApplicantContext { uid: string; email: string; ip?: string }

export async function requireApplicant(req: Request): Promise<ApplicantContext> {
  const h = req.headers.get("authorization");
  if (!h?.startsWith("Bearer ")) throw new HttpError(401, "Please sign in");
  let decoded;
  try {
    decoded = await adminAuth().verifyIdToken(h.slice(7), true);
  } catch {
    throw new HttpError(401, "Your session expired. Please sign in again");
  }
  if (!decoded.email) throw new HttpError(403, "Your account has no email address");
  return { uid: decoded.uid, email: decoded.email, ip: clientIp(req) };
}
