import { AuthPage } from "@/components/AuthGate";

export const metadata = { title: "Sign in" };

export default function Page() {
  return <AuthPage mode="login" />;
}
