import { AuthPage } from "@/components/AuthGate";

export const metadata = { title: "Reset password" };

export default function Page() {
  return <AuthPage mode="reset" />;
}
