
export const metadata = { title: "Privacy Policy" };

export default function Privacy() {
  return (
    <article className="max-w-3xl space-y-4 text-sm leading-relaxed text-slate-700">
      <h1 className="text-2xl font-bold text-slate-900">Privacy Policy</h1>
      <h2 className="text-lg font-semibold text-slate-900">Information we collect</h2>
      <p>Contact details, rental property details, household and pet information, employment and income details, rental history, and your screening authorization. Sensitive identifiers (such as a Social Security number) are collected only when required by the screening provider and permitted by law.</p>
      <h2 className="text-lg font-semibold text-slate-900">How we use it</h2>
      <p>To process your rental application, request a consumer report from an authorized screening provider, communicate with you, and meet legal obligations.</p>
      <h2 className="text-lg font-semibold text-slate-900">Protection</h2>
      <p>Sensitive fields are encrypted at rest and access is limited to authorized personnel and logged. We never ask for or store full card numbers or security codes. For the payment you make, we keep only the payment method, the transaction reference and the screenshot you submit, in private storage visible to authorized staff.</p>
      <h2 className="text-lg font-semibold text-slate-900">Retention and deletion</h2>
      <p>We keep application data only as long as needed for the purposes above and applicable law, then delete or anonymize it. {process.env.NEXT_PUBLIC_RETENTION_POLICY ?? "You may ask us to delete your data through the Contact page, subject to legal retention requirements."}</p>
      <h2 className="text-lg font-semibold text-slate-900">Your choices</h2>
      <p>See <a className="text-brand-600 underline" href="/applicant-rights">Applicant Rights</a> or <a className="text-brand-600 underline" href="/contact">contact us</a> to request access, correction, or deletion where available.</p>
    </article>
  );
}
