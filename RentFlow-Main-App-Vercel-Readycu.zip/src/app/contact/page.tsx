export const metadata = { title: "Contact" };

export default function Contact({ searchParams }: { searchParams?: { sent?: string; error?: string } }) {
  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Contact us</h1>
      <p className="mt-3 text-sm text-slate-600">
        Questions about your application, a data request, or a dispute? Send us a message. Please do not include your
        Social Security number, card numbers, or other sensitive details in this form.
      </p>
      {searchParams?.sent === "1" && <p role="status" className="mt-4 rounded bg-green-50 p-3 text-sm text-green-800">Thank you. Your message was received.</p>}
      {searchParams?.error === "invalid" && <p role="alert" className="mt-4 rounded bg-red-50 p-3 text-sm text-red-800">Please check your name, a valid email and a message under 2000 characters, then try again.</p>}
      {searchParams?.error === "unavailable" && <p role="alert" className="mt-4 rounded bg-red-50 p-3 text-sm text-red-800">Your message could not be saved right now. Please try again later.</p>}
      <form className="card mt-6 space-y-4" action="/api/contact" method="post">
        <div>
          <label className="label" htmlFor="name">Name</label>
          <input id="name" name="name" required maxLength={100} className="input" />
        </div>
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" name="email" type="email" required maxLength={200} className="input" />
        </div>
        <div>
          <label className="label" htmlFor="message">Message</label>
          <textarea id="message" name="message" required maxLength={2000} rows={5} className="input" />
        </div>
        <button className="btn-primary" type="submit">Send message</button>
      </form>
    </div>
  );
}
