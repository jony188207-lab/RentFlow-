import Link from "next/link";
import { formatUsd, getPublicPricing } from "@/lib/settings";

export const revalidate = 60;

const steps = [
  ["Create your account", "Sign up with your email and a password. It takes less than a minute."],
  ["Complete the application", "Four short steps: personal details, property, employment and income, then documents and consent."],
  ["Pay the application fee", "Choose a payment method, pay, and submit your transaction reference and receipt."],
  ["We verify your payment", "A person confirms your payment. Until then it shows as Pending Verification."],
  ["Human review", "A reviewer considers your full application. Nothing is rejected automatically."],
  ["Track every update", "Your dashboard shows your status, payments and notifications as they change."],
];
const features = [
  ["Step-by-step application", "A guided form with a progress bar and clear validation, so nothing is missed."],
  ["Private document upload", "Your ID and income documents are stored privately and seen only by you and authorized reviewers."],
  ["Live status tracking", "See your application and payment status in your dashboard, plus notifications on every change."],
  ["Transparent fee", "One application fee, shown before you pay. Promo codes are checked on our servers."],
  ["Clear disclosures", "You see what is collected, why, and your rights before you give consent."],
  ["Secure by design", "Sensitive fields are encrypted, admin access is checked on the server and actions are logged."],
];
const why = [
  ["Fair, human review", "Decisions are made by people. Screening results are never fabricated and never auto-reject an applicant."],
  ["Your data, protected", "Other applicants can never see your information, and our team's access is limited by role."],
  ["No surprises", "The fee you see at checkout is the fee you pay. Payments are confirmed only after verification."],
];
const faqs = [
  ["Do I need to verify my email to apply?", "No. You can create an account with your email and a password and sign in right away."],
  ["How do I pay the application fee?", "In the application you choose one of the payment methods shown, pay using its instructions, then enter the transaction reference and upload your receipt."],
  ["When is my payment confirmed?", "After a team member checks it. Until then it shows as Pending Verification. Uploading a receipt alone does not mark it as paid."],
  ["Which documents do I need?", "A government-issued ID and at least one proof of income (for example a pay stub or bank statement), as PDF, PNG, JPEG or WebP up to 4 MB each."],
  ["How do I check my status?", "Sign in and open your dashboard, or use the Check status page with your Application ID and email."],
  ["Is a screening report always ordered?", "Only with your consent, and only through an authorized provider. If a decision relies on a report you will receive the required notices and dispute instructions."],
];

export default async function Home() {
  const price = await getPublicPricing();
  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-900 via-brand-700 to-brand-500 px-6 py-16 text-white shadow-lg sm:px-12 sm:py-20">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" aria-hidden="true" />
        <p className="text-sm font-semibold uppercase tracking-widest text-brand-100">Rental applications, simplified</p>
        <h1 className="mt-3 max-w-2xl text-3xl font-bold leading-tight sm:text-5xl">Apply for your next home with confidence.</h1>
        <p className="mt-4 max-w-xl text-brand-100 sm:text-lg">One secure application, one clear fee, and live updates from submission to decision.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/apply" className="btn bg-white text-brand-900 shadow hover:bg-brand-50">Get started / Apply now</Link>
          <Link href="/login" className="btn border border-white/40 text-white hover:bg-white/10">Sign in</Link>
        </div>
      </section>

      <section id="how-it-works" aria-labelledby="h-how">
        <h2 id="h-how" className="text-2xl font-bold">How it works</h2>
        <ol className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {steps.map(([t, d], i) => (
            <li key={t} className="card">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-sm font-bold text-white">{i + 1}</span>
              <h3 className="mt-3 font-semibold">{t}</h3>
              <p className="mt-1 text-sm text-slate-600">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="features" aria-labelledby="h-feat">
        <h2 id="h-feat" className="text-2xl font-bold">Features</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(([t, d]) => (<div key={t} className="card"><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></div>))}
        </div>
      </section>

      <section id="pricing" aria-labelledby="h-price" className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-slate-200 sm:p-12">
        <h2 id="h-price" className="text-2xl font-bold">Pricing</h2>
        <div className="mt-4 flex flex-wrap items-end gap-x-6 gap-y-2">
          <p className="text-5xl font-bold text-brand-700">{price.isDefault ? "Shown at checkout" : formatUsd(price.totalFeeCents)}</p>
          <p className="max-w-md text-sm text-slate-600">One fee per application. The amount shown at checkout is final; no hidden charges. Promo codes are applied at checkout.</p>
        </div>
        <Link href="/apply" className="btn-primary mt-6">Start your application</Link>
      </section>

      <section id="why" aria-labelledby="h-why">
        <h2 id="h-why" className="text-2xl font-bold">Why choose RentFlow</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          {why.map(([t, d]) => (<div key={t} className="card border-l-4 border-l-brand-600"><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></div>))}
        </div>
      </section>

      <section id="faq" aria-labelledby="h-faq">
        <h2 id="h-faq" className="text-2xl font-bold">Frequently asked questions</h2>
        <div className="mt-6 space-y-3">
          {faqs.map(([q, a]) => (
            <details key={q} className="card group">
              <summary className="cursor-pointer list-none font-semibold marker:hidden">{q}</summary>
              <p className="mt-2 text-sm text-slate-600">{a}</p>
            </details>
          ))}
        </div>
      </section>

      <section id="contact" aria-labelledby="h-contact" className="grid gap-8 lg:grid-cols-2">
        <div>
          <h2 id="h-contact" className="text-2xl font-bold">Contact us</h2>
          <p className="mt-3 text-sm text-slate-600">Questions about your application, a data request, or a dispute? Send us a message and we will get back to you. Please do not include your Social Security number or card numbers.</p>
        </div>
        <form className="card space-y-4" action="/api/contact" method="post">
          <div><label className="label" htmlFor="c-name">Name</label><input id="c-name" name="name" required maxLength={100} className="input" /></div>
          <div><label className="label" htmlFor="c-email">Email</label><input id="c-email" name="email" type="email" required maxLength={200} className="input" /></div>
          <div><label className="label" htmlFor="c-msg">Message</label><textarea id="c-msg" name="message" required maxLength={2000} rows={4} className="input" /></div>
          <button className="btn-primary" type="submit">Send message</button>
        </form>
      </section>
    </div>
  );
}
