const steps = [
  ["Complete the application", "Provide contact, property, household, employment, income, and rental-history details."],
  ["Review disclosures and consent", "Read the required screening disclosure and give written authorization."],
  ["Pay the application fee", "Choose one of the payment methods shown, pay, then submit the transaction reference and a screenshot. Your payment shows Pending Verification until our team confirms it."],
  ["Screening is requested", "An authorized consumer reporting agency prepares the report. Results are never fabricated."],
  ["Human review", "A reviewer considers your full application. Nothing is rejected automatically."],
  ["Decision and your rights", "If an adverse action is taken based on a report, you receive the required notices and dispute instructions."],
];

export const metadata = { title: "How It Works" };

export default function HowItWorks() {
  return (
    <div>
      <h1 className="text-2xl font-bold">How it works</h1>
      <ol className="mt-6 space-y-3">
        {steps.map(([t, d], i) => (
          <li key={t} className="card flex gap-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-100 font-bold text-brand-700">
              {i + 1}
            </span>
            <div>
              <h2 className="font-semibold">{t}</h2>
              <p className="text-sm text-slate-600">{d}</p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
