"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { missingFirebaseConfig } from "@/lib/firebase/client";
import { SetupRequired } from "@/components/SetupRequired";
import { AuthPanel } from "@/components/AuthPanel";
import { authCall, useAuthUser } from "@/lib/clientAuth";
import { EMPLOYMENT_STATUSES, PROPERTY_TYPES, ageOn } from "@/lib/applicationSchema";

const money = (cents: number | null | undefined, cur = "USD") =>
  cents == null ? "—" : new Intl.NumberFormat("en-US", { style: "currency", currency: cur.toUpperCase() }).format(cents / 100);
const toCents = (s: string) => Math.round(parseFloat(s) * 100);
const isMoney = (s: string) => s.trim() !== "" && Number.isFinite(parseFloat(s)) && parseFloat(s) >= 0;
const label = (s: string) => s.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());

type Method = {
  id: string; provider: string; displayName: string; description: string; instructions: string; applicantGuidance: string;
  paymentUrl: string | null; identifier: string | null; hasQr: boolean; amountCents: number | null; currency: string; discountCents: number;
};
type Pet = { type: string; breed: string };
type Hist = { address: string; landlord: string; landlordPhone: string; from: string; to: string; rent: string; reason: string };

const emptyHist = (): Hist => ({ address: "", landlord: "", landlordPhone: "", from: "", to: "", rent: "", reason: "" });
const INITIAL = {
  firstName: "", middleName: "", lastName: "", dob: "", phone: "", currentAddress: "",
  propAddress: "", unit: "", propType: "apartment", moveIn: "", leaseMonths: "12", rent: "", occupants: "1",
  pets: [] as Pet[], history: [emptyHist()] as Hist[],
  empStatus: "employed", employer: "", title: "", income: "", additional: "", duration: "",
  ecName: "", ecRel: "", ecPhone: "", ssn: "",
  fcra: false, bg: false, credit: false, terms: false, signature: "",
  country: "US", promo: "", method: "", txRef: "",
};
type Form = typeof INITIAL;
const STEPS = ["Personal", "Property & rental", "Employment & income", "Documents, consent & payment", "Review & submit"];
const DRAFT_KEY = "rentflow-apply-draft-v1";

export default function ApplyPage() {
  if (missingFirebaseConfig().length) return <SetupRequired what="Online applications" />;
  return <ApplyGate />;
}

function ApplyGate() {
  const user = useAuthUser();
  if (user === undefined) return <p role="status">Loading…</p>;
  if (!user) return <AuthPanel initialMode="register" />;
  return <Wizard email={user.email ?? ""} />;
}

function Wizard({ email }: { email: string }) {
  const [step, setStep] = useState(0);
  const [f, setF] = useState<Form>(INITIAL);
  const [govId, setGovId] = useState<File | null>(null);
  const [income, setIncome] = useState<File[]>([]);
  const [receipt, setReceipt] = useState<File | null>(null);
  const [errs, setErrs] = useState<string[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [checkout, setCheckout] = useState<any>(null);
  const [loadErr, setLoadErr] = useState<string | null>(null);
  const [appliedPromo, setAppliedPromo] = useState("");
  const [unlinked, setUnlinked] = useState<any[]>([]);
  const [reuse, setReuse] = useState("");
  // Server ids created so far, so a retry after a failure never uploads or charges twice.
  const progress = useRef<{ govId?: string; income: Record<string, string>; paymentId?: string; idem: string }>({
    income: {},
    idem: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().replace(/-/g, "") : String(Date.now()) + Math.random().toString(36).slice(2, 12),
  });

  // Restore a saved draft (text answers only; files cannot be saved by the browser).
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(DRAFT_KEY);
      if (raw) setF({ ...INITIAL, ...JSON.parse(raw) });
    } catch { /* storage unavailable: start empty */ }
  }, []);
  useEffect(() => {
    try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ ...f, ssn: "" })); } catch { /* ignore */ }
  }, [f]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((s) => ({ ...s, [k]: v }));

  useEffect(() => {
    const qs = new URLSearchParams({ country: f.country || "US" });
    if (appliedPromo) qs.set("promo", appliedPromo);
    fetch(`/api/public/checkout?${qs}`)
      .then(async (r) => {
        const d = await r.json().catch(() => ({}));
        if (!r.ok) return setLoadErr(d.error ?? "Could not load payment options");
        setLoadErr(null); setCheckout(d);
        setF((s) => (d.methods.some((m: Method) => m.id === s.method) ? s : { ...s, method: "" }));
      })
      .catch(() => setLoadErr("Could not load payment options"));
  }, [f.country, appliedPromo]);

  useEffect(() => {
    authCall("/api/applicant/applications").then((r) => { if (r.ok) setUnlinked(r.data.unlinkedPayments ?? []); });
  }, []);

  const method: Method | undefined = checkout?.methods?.find((m: Method) => m.id === f.method);

  function validate(s: number): string[] {
    const e: string[] = [];
    if (s === 0) {
      if (!f.firstName.trim()) e.push("First name is required");
      if (!f.lastName.trim()) e.push("Last name is required");
      const age = /^\d{4}-\d{2}-\d{2}$/.test(f.dob) ? ageOn(f.dob) : null;
      if (age === null) e.push("Enter your date of birth");
      else if (age < 18) e.push("You must be at least 18 years old");
      if (!/^[0-9+()\-.\s]{7,20}$/.test(f.phone.trim())) e.push("Enter a valid phone number");
      if (!f.currentAddress.trim()) e.push("Current address is required");
    }
    if (s === 1) {
      if (!f.propAddress.trim()) e.push("Property address is required");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(f.moveIn)) e.push("Choose your desired move-in date");
      const lease = Number(f.leaseMonths); if (!Number.isInteger(lease) || lease < 1 || lease > 60) e.push("Lease duration must be 1–60 months");
      const occ = Number(f.occupants); if (!Number.isInteger(occ) || occ < 1 || occ > 20) e.push("Number of occupants must be 1–20");
      if (f.rent && !isMoney(f.rent)) e.push("Monthly rent must be a number");
      f.history.forEach((h, i) => {
        const any = Object.values(h).some((v) => v.trim());
        if (any && !h.address.trim()) e.push(`Previous address ${i + 1}: address is required`);
        if (any && !/^\d{4}-\d{2}(-\d{2})?$/.test(h.from)) e.push(`Previous address ${i + 1}: enter the start date (YYYY-MM)`);
      });
    }
    if (s === 2) {
      if ((f.empStatus === "employed" || f.empStatus === "self_employed") && (!f.employer.trim() || !f.title.trim())) e.push("Employer name and job title are required");
      if (!isMoney(f.income)) e.push("Enter your monthly income (0 if none)");
      if (f.additional && !isMoney(f.additional)) e.push("Additional income must be a number");
    }
    if (s === 3) {
      if (!govId) e.push("Upload a government ID");
      if (income.length === 0) e.push("Upload at least one proof of income");
      if (!f.ecName.trim() || !f.ecRel.trim()) e.push("Emergency contact name and relationship are required");
      if (!/^[0-9+()\-.\s]{7,20}$/.test(f.ecPhone.trim())) e.push("Enter a valid emergency contact phone number");
      if (f.ssn.trim() && !/^\d{3}-?\d{2}-?\d{4}$/.test(f.ssn.trim())) e.push("Enter a valid SSN or leave it blank");
      if (!f.fcra) e.push("Acknowledge the screening disclosure");
      if (!f.bg) e.push("Background check consent is required");
      if (!f.credit) e.push("Credit check consent is required");
      if (!f.terms) e.push("Accept the Terms & Conditions");
      const sig = f.signature.toLowerCase();
      if (!f.signature.trim()) e.push("Type your full name as your electronic signature");
      else if (!sig.includes(f.firstName.trim().toLowerCase()) || !sig.includes(f.lastName.trim().toLowerCase())) e.push("Your signature must include your first and last name");
      if (checkout && !checkout.applicationsEnabled) e.push("New applications are currently closed");
      if (!reuse) {
        if (!method) e.push("Choose a payment method");
        if (f.txRef.trim().length < 4) e.push("Enter the transaction reference from your payment");
        if (checkout?.requireScreenshot && !receipt) e.push("Upload your payment receipt or screenshot");
      }
    }
    return e;
  }

  const sizeErr = (file: File | null) => (file && file.size > 4 * 1024 * 1024 ? `${file.name} is larger than 4 MB` : null);

  function next() {
    let e = validate(step);
    if (step === 3) e = [...e, ...[govId, ...income, receipt].map(sizeErr).filter(Boolean) as string[]];
    setErrs(e);
    if (e.length === 0) { setStep(step + 1); window.scrollTo?.({ top: 0 }); }
  }
  const back = () => { setErrs([]); setStep(Math.max(0, step - 1)); window.scrollTo?.({ top: 0 }); };

  async function upload(kind: "gov_id" | "income", file: File): Promise<string> {
    const fd = new FormData(); fd.append("kind", kind); fd.append("file", file);
    const r = await authCall("/api/applicant/documents", { method: "POST", form: fd });
    if (!r.ok) throw new Error(r.data.error ?? `Could not upload ${file.name}`);
    return r.data.id;
  }

  async function submit() {
    const all = [0, 1, 2, 3].flatMap(validate);
    if (all.length) { setErrs(all); return; }
    setErrs([]);
    const p = progress.current;
    try {
      setBusy("Uploading documents…");
      if (!p.govId) p.govId = await upload("gov_id", govId!);
      const incomeIds: string[] = [];
      for (const file of income) {
        const key = `${file.name}:${file.size}:${file.lastModified}`;
        if (!p.income[key]) p.income[key] = await upload("income", file);
        incomeIds.push(p.income[key]!);
      }
      let paymentId = reuse || p.paymentId;
      if (!paymentId) {
        setBusy("Submitting payment details…");
        const fd = new FormData();
        fd.append("methodId", method!.id); fd.append("transactionRef", f.txRef.trim()); fd.append("idempotencyKey", p.idem); fd.append("country", f.country || "US");
        if (appliedPromo) fd.append("promo", appliedPromo);
        if (receipt) fd.append("screenshot", receipt);
        const r = await authCall("/api/applicant/payments", { method: "POST", form: fd });
        if (!r.ok) throw new Error(r.data.error ?? "Could not submit your payment details");
        paymentId = r.data.paymentId as string;
        p.paymentId = paymentId;
      }
      setBusy("Submitting your application…");
      const r = await authCall("/api/applicant/applications", {
        method: "POST",
        body: {
          paymentId,
          personal: { firstName: f.firstName.trim(), middleName: f.middleName.trim() || undefined, lastName: f.lastName.trim(), dob: f.dob, phone: f.phone.trim(), currentAddress: f.currentAddress.trim() },
          property: { address: f.propAddress.trim(), unit: f.unit.trim() || undefined, type: f.propType, rentCents: f.rent ? toCents(f.rent) : undefined, moveIn: f.moveIn, leaseMonths: Number(f.leaseMonths) },
          household: { occupants: Number(f.occupants), pets: f.pets.filter((x) => x.type.trim()).map((x) => ({ type: x.type.trim(), breed: x.breed.trim() || undefined })) },
          rentalHistory: f.history.filter((h) => h.address.trim()).map((h) => ({ address: h.address.trim(), landlord: h.landlord.trim() || undefined, landlordPhone: h.landlordPhone.trim() || undefined, from: h.from, to: h.to || undefined, rentCents: h.rent ? toCents(h.rent) : undefined, reason: h.reason.trim() || undefined })),
          employment: { status: f.empStatus, employer: f.employer.trim() || undefined, title: f.title.trim() || undefined, monthlyIncomeCents: toCents(f.income), additionalIncomeCents: f.additional ? toCents(f.additional) : undefined, duration: f.duration.trim() || undefined },
          documents: { govId: p.govId, income: incomeIds },
          emergencyContact: { name: f.ecName.trim(), relationship: f.ecRel.trim(), phone: f.ecPhone.trim() },
          ssn: f.ssn.trim() || undefined,
          consent: { fcraDisclosure: f.fcra, backgroundCheck: f.bg, creditCheck: f.credit, terms: f.terms },
          signature: f.signature.trim(),
        },
      });
      if (!r.ok) throw new Error(r.data.error ?? "Could not submit your application");
      try { sessionStorage.removeItem(DRAFT_KEY); } catch { /* ignore */ }
      setDone(r.data.reference);
    } catch (e: any) {
      setErrs([e?.message ?? "Something went wrong. Please try again."]);
    }
    setBusy(null);
  }

  if (done) {
    return (
      <section className="card mx-auto max-w-xl border-green-300 bg-green-50" role="status">
        <h1 className="text-xl font-bold text-green-900">Application submitted</h1>
        <p className="mt-2 text-sm">Your Application ID is <strong className="text-xl">{done}</strong>. Keep it to check your status. Your payment is pending verification; a person will confirm it.</p>
        <div className="mt-4 flex flex-wrap gap-2"><Link href="/dashboard" className="btn-primary">Go to my dashboard</Link><Link href="/status" className="btn-secondary">Check status</Link></div>
      </section>
    );
  }

  const inp = (k: keyof Form, p: { type?: string; max?: number; placeholder?: string; auto?: string } = {}) => (
    <input id={String(k)} className="input" type={p.type ?? "text"} maxLength={p.max} placeholder={p.placeholder} autoComplete={p.auto} value={f[k] as string} onChange={(e) => set(k, e.target.value as any)} />
  );
  const fld = (k: keyof Form, text: string, p: Parameters<typeof inp>[1] = {}, cls = "") => (
    <div className={cls}><label className="label" htmlFor={String(k)}>{text}</label>{inp(k, p)}</div>
  );
  const check = (k: "fcra" | "bg" | "credit" | "terms", node: React.ReactNode) => (
    <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={f[k]} onChange={(e) => set(k, e.target.checked)} /><span>{node}</span></label>
  );

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-2xl font-bold">Rental application</h1>
      <p className="mt-1 text-sm text-slate-600">Signed in as {email}</p>
      <div className="mt-4" aria-label={`Step ${step + 1} of ${STEPS.length}`}>
        <div className="h-2 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-valuemin={1} aria-valuemax={STEPS.length} aria-valuenow={step + 1}>
          <div className="h-full bg-brand-600 transition-all" style={{ width: `${((step + 1) / STEPS.length) * 100}%` }} />
        </div>
        <p className="mt-2 text-sm font-medium">Step {step + 1} of {STEPS.length}: {STEPS[step]}</p>
      </div>

      <div className="card mt-4 space-y-4">
        {step === 0 && (
          <>
            <div className="grid gap-3 sm:grid-cols-3">{fld("firstName", "First name", { auto: "given-name", max: 60 })}{fld("middleName", "Middle name (optional)", { auto: "additional-name", max: 60 })}{fld("lastName", "Last name", { auto: "family-name", max: 60 })}</div>
            <div className="grid gap-3 sm:grid-cols-2">{fld("dob", "Date of birth", { type: "date", auto: "bday" })}{fld("phone", "Phone number", { type: "tel", auto: "tel", max: 20 })}</div>
            <div><label className="label" htmlFor="email-ro">Email</label><input id="email-ro" className="input bg-slate-100" value={email} readOnly /></div>
            {fld("currentAddress", "Current address", { auto: "street-address", max: 250 })}
          </>
        )}

        {step === 1 && (
          <>
            <div className="grid gap-3 sm:grid-cols-3">{fld("propAddress", "Property address", { max: 200 }, "sm:col-span-2")}{fld("unit", "Apartment / unit no. (optional)", { max: 30 })}</div>
            <div className="grid gap-3 sm:grid-cols-4">
              <div><label className="label" htmlFor="propType">Property type</label><select id="propType" className="input" value={f.propType} onChange={(e) => set("propType", e.target.value)}>{PROPERTY_TYPES.map((t) => <option key={t} value={t}>{label(t)}</option>)}</select></div>
              {fld("moveIn", "Desired move-in date", { type: "date" })}
              {fld("leaseMonths", "Lease duration (months)", { type: "number" })}
              {fld("occupants", "Number of occupants", { type: "number" })}
            </div>
            {fld("rent", "Monthly rent in USD (optional)", { type: "number" })}
            <fieldset className="space-y-2"><legend className="font-semibold">Pets</legend>
              {f.pets.map((p, i) => (
                <div key={i} className="grid gap-2 sm:grid-cols-3">
                  <input aria-label="Pet type" className="input" placeholder="Type (e.g. dog)" value={p.type} onChange={(e) => set("pets", f.pets.map((x, j) => (j === i ? { ...x, type: e.target.value } : x)))} />
                  <input aria-label="Pet breed" className="input" placeholder="Breed (optional)" value={p.breed} onChange={(e) => set("pets", f.pets.map((x, j) => (j === i ? { ...x, breed: e.target.value } : x)))} />
                  <button type="button" className="btn-secondary" onClick={() => set("pets", f.pets.filter((_, j) => j !== i))}>Remove</button>
                </div>
              ))}
              {f.pets.length < 5 && <button type="button" className="btn-secondary" onClick={() => set("pets", [...f.pets, { type: "", breed: "" }])}>Add a pet</button>}
            </fieldset>
            <fieldset className="space-y-3"><legend className="font-semibold">Previous rental history &amp; landlord (optional)</legend>
              {f.history.map((h, i) => (
                <div key={i} className="grid gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">
                  {([["address", "Previous address"], ["landlord", "Previous landlord name"], ["landlordPhone", "Landlord phone"], ["from", "From (YYYY-MM)"], ["to", "To (YYYY-MM)"], ["rent", "Monthly rent (USD)"], ["reason", "Reason for leaving"]] as const).map(([k, text]) => (
                    <input key={k} aria-label={text} className="input" placeholder={text} value={h[k]} onChange={(e) => set("history", f.history.map((x, j) => (j === i ? { ...x, [k]: e.target.value } : x)))} />
                  ))}
                  {f.history.length > 1 && <button type="button" className="btn-secondary" onClick={() => set("history", f.history.filter((_, j) => j !== i))}>Remove</button>}
                </div>
              ))}
              {f.history.length < 5 && <button type="button" className="btn-secondary" onClick={() => set("history", [...f.history, emptyHist()])}>Add another address</button>}
            </fieldset>
          </>
        )}

        {step === 2 && (
          <>
            <div><label className="label" htmlFor="empStatus">Employment status</label><select id="empStatus" className="input sm:w-60" value={f.empStatus} onChange={(e) => set("empStatus", e.target.value)}>{EMPLOYMENT_STATUSES.map((t) => <option key={t} value={t}>{label(t)}</option>)}</select></div>
            <div className="grid gap-3 sm:grid-cols-2">{fld("employer", "Employer name", { max: 120 })}{fld("title", "Job title", { max: 100 })}</div>
            <div className="grid gap-3 sm:grid-cols-3">{fld("income", "Monthly income (USD)", { type: "number" })}{fld("additional", "Additional monthly income (USD, optional)", { type: "number" })}{fld("duration", "Employment duration (e.g. 2 years)", { max: 60 })}</div>
            <p className="text-sm text-slate-600">You will upload your income documents in the next step.</p>
          </>
        )}

        {step === 3 && (
          <>
            <fieldset className="space-y-3"><legend className="font-semibold">Documents</legend>
              <div><label className="label" htmlFor="govId">Government ID (PDF, PNG, JPEG or WebP, up to 4 MB)</label><input id="govId" type="file" accept="application/pdf,image/png,image/jpeg,image/webp" onChange={(e) => { progress.current.govId = undefined; setGovId(e.target.files?.[0] ?? null); }} /></div>
              <div><label className="label" htmlFor="incomeDocs">Proof of income (pay stubs, tax return, bank statement; up to 5 files)</label><input id="incomeDocs" type="file" multiple accept="application/pdf,image/png,image/jpeg,image/webp" onChange={(e) => setIncome(Array.from(e.target.files ?? []).slice(0, 5))} />
                {income.length > 0 && <p className="mt-1 text-xs text-slate-600">{income.length} file(s) selected</p>}</div>
              <p className="text-xs text-slate-500">Documents are stored privately and are visible only to you and authorized reviewers.</p>
            </fieldset>
            <fieldset className="space-y-2"><legend className="font-semibold">Emergency contact</legend>
              <div className="grid gap-3 sm:grid-cols-3">{fld("ecName", "Full name", { max: 100 })}{fld("ecRel", "Relationship", { max: 60 })}{fld("ecPhone", "Phone", { type: "tel", max: 20 })}</div>
            </fieldset>
            <fieldset className="space-y-2"><legend className="font-semibold">Identity (optional)</legend>
              <p className="text-sm text-slate-600">Provide your Social Security number only if the screening provider requires it. It is stored encrypted and shown only to specifically authorized staff.</p>
              <input aria-label="Social Security number" name="ssn" inputMode="numeric" autoComplete="off" placeholder="Optional" className="input sm:w-60" value={f.ssn} onChange={(e) => set("ssn", e.target.value)} />
            </fieldset>
            <fieldset className="space-y-2"><legend className="font-semibold">Consent &amp; signature</legend>
              <p className="text-sm text-slate-600">A consumer report may be obtained about you from a consumer reporting agency to evaluate this application. If a decision is based in whole or in part on that report, you will be told which agency provided it, and you have the right to a free copy and to dispute inaccurate information.</p>
              {check("fcra", <>I have read the screening disclosure and reviewed the <a className="underline" href="/applicant-rights" target="_blank">Applicant Rights</a> and <a className="underline" href="/privacy" target="_blank">Privacy Policy</a>.</>)}
              {check("bg", "I authorize a background check to be obtained about me for evaluating this rental application.")}
              {check("credit", "I authorize a credit check to be obtained about me for evaluating this rental application.")}
              {check("terms", <>I accept the <a className="underline" href="/terms" target="_blank">Terms &amp; Conditions</a>.</>)}
              <div><label className="label" htmlFor="signature">Electronic signature (type your full legal name)</label><input id="signature" className="input sm:w-96" autoComplete="off" value={f.signature} onChange={(e) => set("signature", e.target.value)} /></div>
            </fieldset>
            <PaymentBlock f={f} set={set} checkout={checkout} loadErr={loadErr} method={method} applyPromo={() => setAppliedPromo(f.promo.trim())} receipt={receipt} setReceipt={setReceipt} unlinked={unlinked} reuse={reuse} setReuse={setReuse} />
          </>
        )}

        {step === 4 && (
          <>
            <h2 className="font-semibold">Please review your application</h2>
            <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
              {([
                ["Name", [f.firstName, f.middleName, f.lastName].filter(Boolean).join(" ")], ["Date of birth", f.dob], ["Phone", f.phone], ["Current address", f.currentAddress],
                ["Property", `${f.propAddress}${f.unit ? `, ${f.unit}` : ""} (${label(f.propType)})`], ["Move-in / lease", `${f.moveIn} · ${f.leaseMonths} months`], ["Occupants", f.occupants],
                ["Employment", `${label(f.empStatus)}${f.employer ? ` · ${f.employer}` : ""}${f.title ? ` · ${f.title}` : ""}`], ["Monthly income", `$${f.income || "0"}${f.additional ? ` + $${f.additional} additional` : ""}`],
                ["Emergency contact", `${f.ecName} (${f.ecRel}) ${f.ecPhone}`], ["Documents", `${govId?.name ?? "—"}; ${income.map((x) => x.name).join(", ") || "—"}`],
                ["Signature", f.signature],
                ["Application fee", reuse ? "Using your earlier submitted payment" : `${money(method?.amountCents, method?.currency)} via ${method?.displayName ?? "—"} (ref ${f.txRef})`],
              ] as [string, string][]).map(([k, v]) => <div key={k}><dt className="text-xs text-slate-500">{k}</dt><dd className="break-words">{v || "—"}</dd></div>)}
            </dl>
            <p className="text-xs text-slate-500">Your payment is confirmed only after our team verifies it. Submitting does not guarantee approval.</p>
          </>
        )}

        {errs.length > 0 && <ul role="alert" className="list-disc rounded bg-red-50 p-3 pl-7 text-sm text-red-800">{errs.map((e) => <li key={e}>{e}</li>)}</ul>}
        <div className="flex flex-wrap justify-between gap-2">
          <button type="button" className="btn-secondary" onClick={back} disabled={step === 0 || !!busy}>Back</button>
          {step < STEPS.length - 1
            ? <button type="button" className="btn-primary" onClick={next}>Next</button>
            : <button type="button" className="btn-primary" onClick={submit} disabled={!!busy}>{busy ?? "Submit application"}</button>}
        </div>
      </div>
    </div>
  );
}

function PaymentBlock(p: {
  f: Form; set: <K extends keyof Form>(k: K, v: Form[K]) => void; checkout: any; loadErr: string | null; method?: Method; applyPromo: () => void;
  receipt: File | null; setReceipt: (f: File | null) => void; unlinked: any[]; reuse: string; setReuse: (s: string) => void;
}) {
  const { f, set, checkout, method } = p;
  if (p.loadErr) return <p role="alert" className="text-red-700">{p.loadErr}</p>;
  if (!checkout) return <p role="status">Loading payment options…</p>;
  if (!checkout.applicationsEnabled) return <div className="rounded border p-3 text-sm">New applications are currently closed. Please check back later.</div>;
  return (
    <fieldset className="space-y-3"><legend className="font-semibold">Application fee &amp; payment</legend>
      <p className="text-3xl font-bold">{money(checkout.baseCents, checkout.baseCurrency)}</p>
      {p.unlinked.length > 0 && (
        <div className="rounded border border-slate-200 p-3 text-sm">
          <label className="label" htmlFor="reuse">You already submitted a payment that is not linked to an application</label>
          <select id="reuse" className="input" value={p.reuse} onChange={(e) => p.setReuse(e.target.value)}>
            <option value="">Make a new payment instead</option>
            {p.unlinked.map((u) => <option key={u.paymentId} value={u.paymentId}>{u.methodName} · {money(u.amountCents, u.currency)} · {u.label}</option>)}
          </select>
        </div>
      )}
      {!p.reuse && (
        <>
          <div className="grid gap-2 sm:grid-cols-3">
            <div><label className="label" htmlFor="country">Your country (ISO code)</label><input id="country" className="input" maxLength={2} value={f.country} onChange={(e) => set("country", e.target.value.toUpperCase())} /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="promo">Promo code (optional)</label>
              <div className="flex gap-2"><input id="promo" className="input" value={f.promo} onChange={(e) => set("promo", e.target.value.toUpperCase())} /><button type="button" className="btn-secondary" onClick={p.applyPromo}>Apply</button></div>
              {checkout.promo && <p className={`mt-1 text-xs ${checkout.promo.valid ? "text-green-700" : "text-red-700"}`}>{checkout.promo.valid ? `Promo ${checkout.promo.code} applied` : checkout.promo.reason}</p>}
            </div>
          </div>
          {checkout.methods.length === 0 ? <p className="text-sm text-slate-600">No payment methods are available for your country right now.</p> : (
            <div className="space-y-2" role="radiogroup" aria-label="Payment method">
              {checkout.methods.map((m: Method) => (
                <label key={m.id} className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 ${f.method === m.id ? "border-brand-500 bg-brand-50" : "border-slate-200"}`}>
                  <input type="radio" name="method" className="mt-1" checked={f.method === m.id} onChange={() => set("method", m.id)} />
                  <span className="flex-1"><strong>{m.displayName}</strong> <span className="text-sm text-slate-600">· {money(m.amountCents, m.currency)}</span>{m.description && <span className="block text-sm text-slate-600">{m.description}</span>}</span>
                </label>
              ))}
            </div>
          )}
          {method && (
            <div className="space-y-2 text-sm">
              <h3 className="font-semibold">Pay {money(method.amountCents, method.currency)} with {method.displayName}</h3>
              {method.instructions && <p className="whitespace-pre-line">{method.instructions}</p>}
              {method.paymentUrl && <p><a className="btn-primary" href={method.paymentUrl} target="_blank" rel="noopener noreferrer">Open payment page</a></p>}
              {method.identifier && <p>Send to: <code className="rounded bg-slate-100 px-2 py-1 font-semibold">{method.identifier}</code></p>}
              {method.hasQr && <img src={`/api/public/payment-methods/${method.id}/qr`} alt={`${method.displayName} payment QR code`} className="h-48 w-48 rounded border" />}
              {method.applicantGuidance && <p className="rounded bg-amber-50 p-2 text-amber-900">{method.applicantGuidance}</p>}
              <p className="text-xs text-slate-500">Only pay to the details shown on this page. After paying, enter your transaction reference and upload your receipt below. Your payment is confirmed only after our team verifies it.</p>
              <div><label className="label" htmlFor="txRef">Transaction reference / ID</label><input id="txRef" className="input" maxLength={100} value={f.txRef} onChange={(e) => set("txRef", e.target.value)} /></div>
              <div><label className="label" htmlFor="receipt">Payment receipt / screenshot {checkout.requireScreenshot ? "(required)" : "(optional)"} — PNG, JPEG or WebP, up to 4 MB</label>
                <input id="receipt" type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => p.setReceipt(e.target.files?.[0] ?? null)} /></div>
            </div>
          )}
        </>
      )}
    </fieldset>
  );
}
