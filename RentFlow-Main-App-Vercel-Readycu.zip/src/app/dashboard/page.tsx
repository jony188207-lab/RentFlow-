"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { signOut } from "firebase/auth";
import { firebaseAuth, missingFirebaseConfig } from "@/lib/firebase/client";
import { SetupRequired } from "@/components/SetupRequired";
import { AuthPanel } from "@/components/AuthPanel";
import { authCall, openPrivateFile, useAuthUser } from "@/lib/clientAuth";

const money = (cents: number | null | undefined, cur = "USD") =>
  cents == null ? "—" : new Intl.NumberFormat("en-US", { style: "currency", currency: String(cur).toUpperCase() }).format(cents / 100);
const when = (iso?: string | null) => (iso ? new Date(iso).toLocaleString() : "—");
const words = (s?: string | null) => (s ? s.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase()) : "—");

const TABS = ["Overview", "My applications", "Payments", "Documents", "Notifications", "Profile"] as const;
type Tab = (typeof TABS)[number];

export default function DashboardPage() {
  if (missingFirebaseConfig().length) return <SetupRequired what="The dashboard" />;
  return <Gate />;
}

function Gate() {
  const user = useAuthUser();
  if (user === undefined) return <p role="status">Loading…</p>;
  if (!user) return <AuthPanel initialMode="login" />;
  return <Dashboard email={user.email ?? ""} />;
}

function Dashboard({ email }: { email: string }) {
  const [tab, setTab] = useState<Tab>("Overview");
  const [apps, setApps] = useState<any[] | null>(null);
  const [pays, setPays] = useState<any[] | null>(null);
  const [docs, setDocs] = useState<any[] | null>(null);
  const [notes, setNotes] = useState<{ notifications: any[]; unread: number } | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [a, p, d, n, pr] = await Promise.all([
      authCall("/api/applicant/applications"), authCall("/api/applicant/payments"), authCall("/api/applicant/documents"),
      authCall("/api/applicant/notifications"), authCall("/api/applicant/profile"),
    ]);
    if (!a.ok && !pr.ok) setError(a.data?.error ?? "Could not load your dashboard");
    else setError(null);
    setApps(a.ok ? a.data.applications : []); setPays(p.ok ? p.data.payments : []); setDocs(d.ok ? d.data.documents : []);
    setNotes(n.ok ? n.data : { notifications: [], unread: 0 }); setProfile(pr.ok ? pr.data : { email });
  }, [email]);
  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-bold">My dashboard</h1>
        <button className="btn-secondary" onClick={() => signOut(firebaseAuth()).then(() => { window.location.href = "/"; })}>Logout</button>
      </div>
      <nav className="mt-4 flex flex-wrap gap-2" aria-label="Dashboard sections">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)} aria-current={tab === t} className={`btn ${tab === t ? "bg-brand-600 text-white" : "border border-slate-300 bg-white"}`}>
            {t}{t === "Notifications" && notes && notes.unread > 0 ? ` (${notes.unread})` : ""}
          </button>
        ))}
      </nav>
      {error && <p role="alert" className="mt-4 rounded bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      <div className="mt-4">
        {apps === null ? <p role="status">Loading…</p> : (
          <>
            {tab === "Overview" && <Overview apps={apps} pays={pays ?? []} notes={notes} go={setTab} />}
            {tab === "My applications" && <Applications apps={apps} />}
            {tab === "Payments" && <Payments pays={pays ?? []} />}
            {tab === "Documents" && <Documents docs={docs ?? []} />}
            {tab === "Notifications" && <Notifications data={notes} reload={load} />}
            {tab === "Profile" && <Profile profile={profile} email={email} reload={load} />}
          </>
        )}
      </div>
    </div>
  );
}

const Empty = ({ text, cta }: { text: string; cta?: boolean }) => (
  <div className="card text-sm text-slate-600"><p>{text}</p>{cta && <Link href="/apply" className="btn-primary mt-3">Start an application</Link>}</div>
);

function Overview({ apps, pays, notes, go }: { apps: any[]; pays: any[]; notes: any; go: (t: Tab) => void }) {
  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <div className="card"><p className="text-xs text-slate-500">Applications</p><p className="text-3xl font-bold">{apps.length}</p><button className="mt-2 text-sm text-brand-600 underline" onClick={() => go("My applications")}>View</button></div>
      <div className="card"><p className="text-xs text-slate-500">Payments</p><p className="text-3xl font-bold">{pays.length}</p><button className="mt-2 text-sm text-brand-600 underline" onClick={() => go("Payments")}>View</button></div>
      <div className="card"><p className="text-xs text-slate-500">Unread notifications</p><p className="text-3xl font-bold">{notes?.unread ?? 0}</p><button className="mt-2 text-sm text-brand-600 underline" onClick={() => go("Notifications")}>View</button></div>
      {apps.length === 0 && <div className="sm:col-span-3"><Empty text="You have not submitted an application yet." cta /></div>}
      {apps.length > 0 && <div className="card sm:col-span-3"><h2 className="font-semibold">Latest application</h2><p className="mt-1 text-sm"><strong>{apps[0].reference}</strong> · Status: <strong>{words(apps[0].applicationStatus)}</strong> · Payment: <strong>{apps[0].payment?.label ?? "—"}</strong></p></div>}
    </div>
  );
}

function Applications({ apps }: { apps: any[] }) {
  const [open, setOpen] = useState<string | null>(null);
  const [detail, setDetail] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  async function view(ref: string) {
    setOpen(ref); setDetail(null); setErr(null);
    const r = await authCall(`/api/applicant/applications/${ref}`);
    if (r.ok) setDetail(r.data); else setErr(r.data.error ?? "Could not load the application");
  }
  if (apps.length === 0) return <Empty text="You have not submitted an application yet." cta />;
  return (
    <div className="space-y-4">
      <ul className="card divide-y text-sm">
        {apps.map((a) => (
          <li key={a.reference} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span><strong>{a.reference}</strong> · {when(a.createdAt)}</span>
            <span>Status: <strong>{words(a.applicationStatus)}</strong> · Payment: <strong>{a.payment?.label ?? "—"}</strong></span>
            <button className="btn-secondary" onClick={() => view(a.reference)}>Details</button>
          </li>
        ))}
      </ul>
      {open && (
        <section className="card text-sm" aria-live="polite">
          <h2 className="font-semibold">Application {open}</h2>
          {err && <p role="alert" className="text-red-700">{err}</p>}
          {!detail && !err && <p role="status">Loading…</p>}
          {detail && (
            <dl className="mt-2 grid gap-x-6 gap-y-2 sm:grid-cols-2">
              {([
                ["Status", words(detail.status)], ["Submitted", when(detail.createdAt)],
                ["Name", [detail.personal?.firstName, detail.personal?.middleName, detail.personal?.lastName].filter(Boolean).join(" ")],
                ["Property", `${detail.property?.address ?? "—"}${detail.property?.unit ? `, ${detail.property.unit}` : ""}`],
                ["Move-in / lease", detail.property ? `${detail.property.moveIn} · ${detail.property.leaseMonths ?? "—"} months` : "—"],
                ["Occupants", detail.household?.occupants ?? "—"],
                ["Employment", `${words(detail.employment?.status)}${detail.employment?.employer ? ` · ${detail.employment.employer}` : ""}`],
                ["Monthly income", money(detail.employment?.monthlyIncomeCents)],
                ["Emergency contact", detail.emergencyContact ? `${detail.emergencyContact.name} (${detail.emergencyContact.relationship})` : "—"],
                ["Payment", detail.payment ? `${detail.payment.label} · ${money(detail.payment.amountCents, detail.payment.currency)} · ${detail.payment.methodName ?? ""}` : "—"],
              ] as [string, string][]).map(([k, v]) => <div key={k}><dt className="text-xs text-slate-500">{k}</dt><dd>{v}</dd></div>)}
            </dl>
          )}
        </section>
      )}
    </div>
  );
}

function Payments({ pays }: { pays: any[] }) {
  if (pays.length === 0) return <Empty text="No payments yet." />;
  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead><tr className="text-xs text-slate-500"><th className="py-1 pr-3">Date</th><th className="pr-3">Method</th><th className="pr-3">Reference</th><th className="pr-3">Amount</th><th>Status</th></tr></thead>
        <tbody>{pays.map((p) => <tr key={p.id} className="border-t"><td className="py-2 pr-3">{when(p.createdAt)}</td><td className="pr-3">{p.methodName ?? "—"}</td><td className="pr-3">{p.transactionRef ?? "—"}</td><td className="pr-3">{money(p.amountCents, p.currency)}</td><td><strong>{p.label}</strong></td></tr>)}</tbody>
      </table>
    </div>
  );
}

function Documents({ docs }: { docs: any[] }) {
  const [err, setErr] = useState<string | null>(null);
  if (docs.length === 0) return <Empty text="You have not uploaded any documents yet. Documents are uploaded as part of an application." />;
  return (
    <div className="card text-sm">
      {err && <p role="alert" className="mb-2 text-red-700">{err}</p>}
      <ul className="divide-y">
        {docs.map((d) => (
          <li key={d.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span>{d.kind === "gov_id" ? "Government ID" : "Proof of income"} · {d.name} · {Math.max(1, Math.round(d.size / 1024))} KB · {when(d.createdAt)}{d.applicationId ? ` · ${d.applicationId}` : " · not yet submitted"}</span>
            <button className="btn-secondary" onClick={async () => setErr((await openPrivateFile(`/api/applicant/documents/${d.id}`)) ? null : "Could not open the document")}>View</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Notifications({ data, reload }: { data: { notifications: any[]; unread: number } | null; reload: () => void }) {
  const list = data?.notifications ?? [];
  if (list.length === 0) return <Empty text="No notifications yet. You will see status and payment updates here." />;
  return (
    <div className="card text-sm">
      {data!.unread > 0 && <button className="btn-secondary mb-2" onClick={async () => { await authCall("/api/applicant/notifications", { method: "PATCH", body: { all: true } }); reload(); }}>Mark all as read</button>}
      <ul className="divide-y">
        {list.map((n) => (
          <li key={n.id} className="py-2"><p className={n.read ? "" : "font-semibold"}>{n.title}</p><p className="text-slate-600">{n.message}</p><p className="text-xs text-slate-400">{when(n.createdAt)}</p></li>
        ))}
      </ul>
    </div>
  );
}

function Profile({ profile, email, reload }: { profile: any; email: string; reload: () => void }) {
  const [first, setFirst] = useState(profile?.firstName ?? "");
  const [last, setLast] = useState(profile?.lastName ?? "");
  const [phone, setPhone] = useState(profile?.phone ?? "");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    const r = await authCall("/api/applicant/profile", { method: "PUT", body: { firstName: first, lastName: last, phone } });
    setMsg(r.ok ? { ok: true, text: "Profile saved." } : { ok: false, text: r.data.error ?? "Could not save your profile" });
    if (r.ok) reload();
  }
  return (
    <form onSubmit={save} className="card max-w-lg space-y-3">
      <div><label className="label" htmlFor="pe">Email</label><input id="pe" className="input bg-slate-100" value={email} readOnly /></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div><label className="label" htmlFor="pf">First name</label><input id="pf" className="input" maxLength={60} value={first} onChange={(e) => setFirst(e.target.value)} /></div>
        <div><label className="label" htmlFor="pl">Last name</label><input id="pl" className="input" maxLength={60} value={last} onChange={(e) => setLast(e.target.value)} /></div>
      </div>
      <div><label className="label" htmlFor="pp">Phone</label><input id="pp" className="input" type="tel" maxLength={20} value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
      {msg && <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-green-700" : "text-red-700"}`}>{msg.text}</p>}
      <button className="btn-primary">Save profile</button>
    </form>
  );
}
