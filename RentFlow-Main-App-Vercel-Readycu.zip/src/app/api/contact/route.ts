import { NextResponse } from "next/server";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";

export const dynamic = "force-dynamic";

const Body = z.object({
  name: z.string().min(1).max(100),
  email: z.string().email().max(200),
  message: z.string().min(1).max(2000),
});

export async function POST(req: Request) {
  const form = await req.formData().catch(() => null);
  const parsed = Body.safeParse(form ? Object.fromEntries(form) : null);
  if (!parsed.success) return NextResponse.redirect(new URL("/contact?error=invalid", req.url), 303);
  try {
    await adminDb().collection("contactMessages").add({ ...parsed.data, at: new Date().toISOString() });
  } catch {
    return NextResponse.redirect(new URL("/contact?error=unavailable", req.url), 303);
  }
  return NextResponse.redirect(new URL("/contact?sent=1", req.url), 303);
}
