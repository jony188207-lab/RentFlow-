import { NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { applicantPaymentLabel } from "@/lib/domain";
import { HttpError } from "@/lib/http";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

// Details of ONE of the applicant's own applications. Another user's application returns 404.
// Never returns the SSN, internal notes, admin names or storage paths.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requireApplicant(req);
    const db = adminDb();
    const snap = await db.collection("applications").doc(params.id).get();
    const x = snap.data();
    if (!snap.exists || x?.applicantUid !== a.uid) throw new HttpError(404, "Application not found");
    const pay = x.paymentId ? (await db.collection("payments").doc(x.paymentId).get()).data() : undefined;
    const ids: string[] = x.documentIds ? [x.documentIds.govId, ...(x.documentIds.income ?? [])].filter(Boolean) : [];
    const documents = (
      await Promise.all(ids.map(async (id) => { const d = await db.collection("applicantDocuments").doc(id).get(); return d.exists && d.data()!.uid === a.uid ? { id, kind: d.data()!.kind, name: d.data()!.name } : null; }))
    ).filter(Boolean);
    return NextResponse.json(
      serialize({
        reference: snap.id,
        status: x.publicStatus ?? "received",
        createdAt: x.createdAt,
        updatedAt: x.updatedAt ?? null,
        personal: x.personal ?? null,
        property: x.property ?? null,
        household: x.household ?? null,
        employment: x.employment ?? null,
        rentalHistory: x.rentalHistory ?? [],
        emergencyContact: x.emergencyContact ?? null,
        documents,
        payment: pay ? { label: applicantPaymentLabel(pay.status, true), methodName: pay.methodName ?? null, transactionRef: pay.transactionRef ?? null, amountCents: pay.amountCents, currency: pay.currency } : null,
      }),
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return errorResponse(e);
  }
}
