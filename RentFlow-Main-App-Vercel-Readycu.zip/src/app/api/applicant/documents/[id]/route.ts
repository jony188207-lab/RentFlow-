import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { HttpError } from "@/lib/http";
import { readPrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

// Streams a document back to the person who uploaded it, and nobody else.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const a = await requireApplicant(req);
    const d = await adminDb().collection("applicantDocuments").doc(params.id).get();
    const x = d.data();
    if (!d.exists || x?.uid !== a.uid) throw new HttpError(404, "Document not found");
    const buf = await readPrivate(x.path);
    return new Response(new Uint8Array(buf), {
      headers: {
        "content-type": x.contentType,
        "content-disposition": `attachment; filename="${String(x.name).replace(/"/g, "")}"`,
        "cache-control": "private, no-store",
        "x-content-type-options": "nosniff",
        "content-security-policy": "default-src 'none'; sandbox",
      },
    });
  } catch (e) {
    return errorResponse(e);
  }
}
