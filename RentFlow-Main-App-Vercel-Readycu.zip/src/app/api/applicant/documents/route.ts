import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { writeAudit } from "@/lib/audit";
import { readDocumentUpload } from "@/lib/files";
import { HttpError, parseInput } from "@/lib/http";
import { rateLimit } from "@/lib/ratelimit";
import { serialize } from "@/lib/serialize";
import { deletePrivate, putPrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

const Kind = z.enum(["gov_id", "income"]);
const MAX_DOCS = 20;

// Upload one document (government ID or proof of income) to PRIVATE storage. The file type is decided by
// its real content, not by the filename or the browser-supplied type.
export async function POST(req: Request) {
  try {
    const a = await requireApplicant(req);
    await rateLimit("document-upload", a.uid, 30, 3600);
    const form = await req.formData().catch(() => null);
    if (!form) throw new HttpError(400, "Invalid form data");
    const kind = parseInput(Kind, form.get("kind"));
    const file = await readDocumentUpload(form.get("file"));
    if (!file) throw new HttpError(400, "Choose a file to upload");

    const db = adminDb();
    const existing = await db.collection("applicantDocuments").where("uid", "==", a.uid).limit(MAX_DOCS + 1).get();
    if (existing.size >= MAX_DOCS) throw new HttpError(429, "Document limit reached");

    const ref = db.collection("applicantDocuments").doc();
    const path = `applicant-documents/${a.uid}/${ref.id}.${file.ext}`;
    const entry = form.get("file") as File;
    await putPrivate(path, file.buf, file.mime);
    try {
      await ref.set({
        uid: a.uid,
        kind,
        path,
        contentType: file.mime,
        size: file.buf.length,
        name: String(entry.name ?? "document").replace(/[^\w.\- ]/g, "_").slice(0, 100),
        applicationId: null,
        createdAt: FieldValue.serverTimestamp(),
      });
    } catch (e) {
      await deletePrivate(path).catch(() => undefined);
      throw e;
    }
    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "document.uploaded", targetType: "document", targetId: ref.id, meta: { kind, size: file.buf.length }, ip: a.ip });
    return NextResponse.json({ id: ref.id, kind }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}

// The applicant's own uploaded documents (metadata only; never storage paths).
export async function GET(req: Request) {
  try {
    const a = await requireApplicant(req);
    const snap = await adminDb().collection("applicantDocuments").where("uid", "==", a.uid).limit(50).get();
    const documents = snap.docs
      .map((d) => serialize({ id: d.id, kind: d.data().kind, name: d.data().name, contentType: d.data().contentType, size: d.data().size, applicationId: d.data().applicationId ?? null, createdAt: d.data().createdAt }))
      .sort((x, y) => String(y.createdAt).localeCompare(String(x.createdAt)));
    return NextResponse.json({ documents }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    return errorResponse(e);
  }
}
