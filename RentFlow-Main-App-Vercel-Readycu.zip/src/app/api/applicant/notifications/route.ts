import { NextResponse } from "next/server";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { parseInput, readJson } from "@/lib/http";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const a = await requireApplicant(req);
    const snap = await adminDb().collection("userNotifications").where("uid", "==", a.uid).limit(50).get();
    const items = snap.docs
      .map((d) => serialize({ id: d.id, title: d.data().title, message: d.data().message, link: d.data().link ?? null, read: d.data().read === true, createdAt: d.data().createdAt }))
      .sort((x, y) => String(y.createdAt).localeCompare(String(x.createdAt)));
    return NextResponse.json({ notifications: items, unread: items.filter((n) => !n.read).length }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    return errorResponse(e);
  }
}

const Patch = z.object({ ids: z.array(z.string().min(1).max(100)).max(50).optional(), all: z.boolean().optional() });

// Mark the applicant's OWN notifications as read (ownership is checked per document).
export async function PATCH(req: Request) {
  try {
    const a = await requireApplicant(req);
    const body = parseInput(Patch, await readJson(req));
    const db = adminDb();
    let refs;
    if (body.all) refs = (await db.collection("userNotifications").where("uid", "==", a.uid).limit(100).get()).docs.map((d) => d.ref);
    else refs = (body.ids ?? []).map((id) => db.collection("userNotifications").doc(id));
    let n = 0;
    for (const r of refs) {
      const d = await r.get();
      if (d.exists && d.data()!.uid === a.uid) { await r.update({ read: true }); n++; }
    }
    return NextResponse.json({ updated: n });
  } catch (e) {
    return errorResponse(e);
  }
}
