import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { parseInput, readJson } from "@/lib/http";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

// The signed-in applicant's profile (users/{uid}). Created on first visit, which is how "Total users" is counted.
export async function GET(req: Request) {
  try {
    const a = await requireApplicant(req);
    const ref = adminDb().collection("users").doc(a.uid);
    const snap = await ref.get();
    if (!snap.exists) await ref.set({ uid: a.uid, email: a.email, role: "applicant", disabled: false, createdAt: FieldValue.serverTimestamp(), lastSeenAt: FieldValue.serverTimestamp() });
    else await ref.update({ lastSeenAt: FieldValue.serverTimestamp(), email: a.email });
    const d = (await ref.get()).data()!;
    return NextResponse.json(serialize({ email: a.email, firstName: d.firstName ?? "", lastName: d.lastName ?? "", phone: d.phone ?? "", createdAt: d.createdAt }), { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    return errorResponse(e);
  }
}

const Put = z.object({
  firstName: z.string().trim().max(60).optional(),
  lastName: z.string().trim().max(60).optional(),
  phone: z.string().trim().regex(/^[0-9+()\-.\s]{7,20}$/, "Enter a valid phone number").or(z.literal("")).optional(),
});

export async function PUT(req: Request) {
  try {
    const a = await requireApplicant(req);
    const body = parseInput(Put, await readJson(req));
    await adminDb().collection("users").doc(a.uid).set({ ...body, uid: a.uid, email: a.email, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
