import { AuthPage } from "@/components/AuthGate";

export const metadata = { title: "Create account" };

export default function Page() {
  return <AuthPage mode="register" />;
}
