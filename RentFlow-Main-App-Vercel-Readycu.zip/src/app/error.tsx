"use client";
import { useEffect } from "react";

// Route-level error boundary: shows a recoverable message instead of a blank crash page.
export default function RouteError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error("[RentFlow] page error:", error); }, [error]);
  return (
    <div role="alert" className="mx-auto max-w-md rounded-lg border border-slate-300 bg-white p-5">
      <h1 className="text-lg font-bold">Something went wrong</h1>
      <p className="mt-2 text-sm text-slate-600">This page could not be displayed. You can try again, or return to the home page.</p>
      <div className="mt-4 flex gap-2">
        <button className="rounded bg-slate-800 px-3 py-1.5 text-sm text-white" onClick={() => reset()}>Try again</button>
        <a className="rounded border border-slate-300 px-3 py-1.5 text-sm" href="/">Home</a>
      </div>
    </div>
  );
}
