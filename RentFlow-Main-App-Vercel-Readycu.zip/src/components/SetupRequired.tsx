"use client";
import { missingFirebaseConfig } from "@/lib/firebase/client";

/** Shown instead of a crash when this deployment has no Firebase web configuration. */
export function SetupRequired({ what }: { what: string }) {
  const missing = missingFirebaseConfig();
  // Variable NAMES only (never values) go to the console for whoever operates the site.
  if (typeof console !== "undefined") console.error(`[RentFlow] ${what} is unavailable. Missing Firebase settings: ${missing.join(", ")}. Set them in Vercel and Redeploy.`);
  return (
    <div role="alert" className="mx-auto max-w-md rounded-lg border border-slate-300 bg-white p-5">
      <h1 className="text-lg font-bold">{what} is not available yet</h1>
      <p className="mt-2 text-sm text-slate-600">This site has not finished its account setup, so sign-in is switched off. Please try again later or contact the site owner.</p>
    </div>
  );
}
