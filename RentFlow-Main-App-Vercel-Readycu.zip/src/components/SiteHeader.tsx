import Link from "next/link";
import { AuthLinks } from "@/components/AuthLinks";

const links = [
  { href: "/how-it-works", label: "How it works" },
  { href: "/pricing", label: "Pricing" },
  { href: "/status", label: "Check status" },
  { href: "/contact", label: "Contact" },
];

export function SiteHeader() {
  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="text-lg font-bold text-brand-700">
          RentFlow
        </Link>
        <nav className="flex flex-wrap items-center gap-4 text-sm text-slate-700">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-brand-600">
              {l.label}
            </Link>
          ))}
          <AuthLinks />
          <Link href="/apply" className="btn-primary !py-1.5">
            Apply now
          </Link>
        </nav>
      </div>
    </header>
  );
}
