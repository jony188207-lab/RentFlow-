"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import type { AuthMode } from "@/components/AuthPanel";
import { AuthPanel } from "@/components/AuthPanel";
import { SetupRequired } from "@/components/SetupRequired";
import { missingFirebaseConfig } from "@/lib/firebase/client";
import { useAuthUser } from "@/lib/clientAuth";

/** Page body for /login, /register and /forgot-password: signed-in visitors go straight to the dashboard. */
export function AuthPage({ mode }: { mode: AuthMode }) {
  const router = useRouter();
  const user = useAuthUser();
  const missing = missingFirebaseConfig().length > 0;
  useEffect(() => { if (user) router.replace("/dashboard"); }, [user, router]);
  if (missing) return <SetupRequired what="Sign-in" />;
  if (user === undefined || user) return <p role="status">Loading…</p>;
  return <AuthPanel initialMode={mode} onSuccess={() => router.replace("/dashboard")} />;
}
