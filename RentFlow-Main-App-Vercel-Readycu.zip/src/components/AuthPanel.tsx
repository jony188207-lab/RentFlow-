"use client";
import { useState } from "react";
import Link from "next/link";
import { createUserWithEmailAndPassword, sendPasswordResetEmail, signInWithEmailAndPassword } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";

export type AuthMode = "login" | "register" | "reset";

const MESSAGES: Record<string, string> = {
  "auth/email-already-in-use": "An account with this email already exists. Sign in instead.",
  "auth/weak-password": "Password must be at least 8 characters.",
  "auth/invalid-email": "Enter a valid email address.",
  "auth/too-many-requests": "Too many attempts. Please wait a few minutes and try again.",
  "auth/network-request-failed": "Network error. Check your connection and try again.",
  "auth/user-disabled": "This account has been disabled. Please contact us.",
  "auth/operation-not-allowed": "Email/password sign-in is not enabled for this site yet.",
};

/** Sign up, sign in and password reset with Firebase Authentication. No email verification is required. */
export function AuthPanel({ initialMode = "login", onSuccess }: { initialMode?: AuthMode; onSuccess?: () => void }) {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(null); setInfo(null); setBusy(true);
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email") ?? "").trim();
    const password = String(f.get("password") ?? "");
    try {
      if (mode === "register") {
        if (password.length < 8) throw Object.assign(new Error(), { code: "auth/weak-password" });
        if (password !== String(f.get("confirm") ?? "")) throw new Error("Passwords do not match.");
        await createUserWithEmailAndPassword(firebaseAuth(), email, password);
        onSuccess?.();
      } else if (mode === "login") {
        await signInWithEmailAndPassword(firebaseAuth(), email, password);
        onSuccess?.();
      } else {
        // Same message whether or not the address has an account (no account enumeration).
        await sendPasswordResetEmail(firebaseAuth(), email).catch((er: any) => { if (er?.code !== "auth/user-not-found") throw er; });
        setInfo("If an account exists for that email, a password reset link has been sent. Check your inbox and spam folder.");
      }
    } catch (er: any) {
      const code: string = er?.code ?? "";
      setErr(
        MESSAGES[code] ??
          (er?.message && !code ? er.message : mode === "login" ? "Sign-in failed. Check your email and password." : mode === "register" ? "Could not create the account. Please try again." : "Could not send the reset email. Please try again."),
      );
    }
    setBusy(false);
  }

  const title = mode === "register" ? "Create your account" : mode === "login" ? "Sign in" : "Reset your password";
  return (
    <div className="mx-auto max-w-sm">
      <h1 className="text-2xl font-bold">{title}</h1>
      <p className="mt-2 text-sm text-slate-600">
        {mode === "reset" ? "Enter your email and we will send you a link to choose a new password." : "Use your email and a password. You can apply, pay the fee and track your application."}
      </p>
      <form onSubmit={submit} className="card mt-4 space-y-4">
        <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required className="input" /></div>
        {mode !== "reset" && (
          <div><label className="label" htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} required minLength={mode === "register" ? 8 : undefined} className="input" /></div>
        )}
        {mode === "register" && (
          <div><label className="label" htmlFor="confirm">Confirm password</label><input id="confirm" name="confirm" type="password" autoComplete="new-password" required minLength={8} className="input" /></div>
        )}
        {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
        {info && <p role="status" className="text-sm text-green-700">{info}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Please wait…" : mode === "register" ? "Create account" : mode === "login" ? "Sign in" : "Send reset link"}</button>
      </form>
      <div className="mt-4 space-y-1 text-center text-sm text-slate-600">
        {mode === "login" && (<>
          <p>New here? <button type="button" className="font-semibold text-brand-600 underline" onClick={() => { setMode("register"); setErr(null); setInfo(null); }}>Create an account</button></p>
          <p><button type="button" className="text-brand-600 underline" onClick={() => { setMode("reset"); setErr(null); setInfo(null); }}>Forgot password?</button></p>
        </>)}
        {mode === "register" && <p>Already have an account? <button type="button" className="font-semibold text-brand-600 underline" onClick={() => { setMode("login"); setErr(null); }}>Sign in</button></p>}
        {mode === "reset" && <p><button type="button" className="text-brand-600 underline" onClick={() => { setMode("login"); setErr(null); setInfo(null); }}>Back to sign in</button></p>}
        <p className="text-xs"><Link href="/" className="underline">Back to home</Link></p>
      </div>
    </div>
  );
}
