"use client";
import Link from "next/link";
import { signOut } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";
import { useAuthUser } from "@/lib/clientAuth";

/** Header links that depend on whether the visitor is signed in. */
export function AuthLinks() {
  const user = useAuthUser();
  if (user === undefined) return null;
  if (!user) return <Link href="/login" className="hover:text-brand-600">Sign in</Link>;
  return (
    <>
      <Link href="/dashboard" className="hover:text-brand-600">Dashboard</Link>
      <button type="button" className="hover:text-brand-600" onClick={() => signOut(firebaseAuth()).then(() => { window.location.href = "/"; })}>Logout</button>
    </>
  );
}
