# RentFlow — Main App (Next.js 14 · TypeScript · Tailwind · Firebase · Vercel)

Public website, applicant accounts, the 4-step rental application, payment-proof submission and the applicant dashboard.
The **RentFlow Admin Panel** is a separate project that uses the **same Firebase project**. Deploy this Main App first.

## What works (implemented in code)
| Area | Details |
|---|---|
| Home | Hero, navigation, How it works, Features, Pricing (live fee from the database), Why RentFlow, FAQ, Contact form, footer; responsive |
| Accounts | `/register`, `/login`, Logout, `/forgot-password` (Firebase password-reset email). **Email verification is not required** |
| Application | `/apply`: 5 screens (Personal → Property & rental → Employment & income → Documents, consent & payment → Review & submit) with Back/Next, progress bar and validation; unique Application ID `RF-XXXXXXXX` |
| Documents | Government ID + proof of income (PDF/PNG/JPEG/WebP, ≤ 4 MB, type checked by file content) in **private** Cloud Storage |
| Payment | Fee and methods set by the admin (Stripe, Cash App, Payoneer, PayPal, Chime, Custom); applicant pays outside the app, then submits transaction reference + receipt → **Pending Verification** until an admin verifies. A receipt is never treated as paid |
| Dashboard | `/dashboard`: overview, applications and details, payment history, uploaded documents, notifications (status/payment changes made by an admin), profile, logout |
| Status | `/status` lookup by Application ID + email |
| Security | Server verifies the Firebase ID token on every API call; applicants can only read their own records; Firestore/Storage rules deny all browser access; rate limits; duplicate-payment protection; SSN encrypted (AES-256-GCM) |

## What needs external accounts / credentials (not faked)
- **Firebase project** (Auth, Firestore, Storage) — required for everything except the static pages.
- **Automatic payment confirmation** (Stripe/PayPal API) — not implemented; payments are verified manually in the Admin Panel. A signed-webhook receiver exists but no provider adapter.
- **Tenant-screening provider**, **transactional email** (other than Firebase's own password-reset email) — not implemented.

## Test status — read this
This source was written in an environment without access to the npm registry, so **`npm install`, `npm run build`, `npm test` and the browser flows have NOT been run**. Only syntax-only TypeScript checks and a partial type check were run. Run these once before relying on it:
```
npm install && npm run typecheck && npm test && npm run build
```
`next.config.mjs` lets the Vercel build continue past TypeScript/ESLint errors so a type problem cannot block a deployment you cannot debug; set `STRICT_TYPES=true` to enforce types.

## 1. Firebase setup (browser only, no terminal)
1. console.firebase.google.com → create a project.
2. **Authentication → Sign-in method → Email/Password → Enable.**
3. **Firestore Database** → create database (production mode). **Storage** → create a bucket (may require the Blaze plan); keep it private.
4. **Project settings → General → Your apps → Web app** → copy the four config values.
5. **Project settings → Service accounts → Generate new private key.** Keep the JSON private; copy only `project_id`, `client_email`, `private_key` into Vercel env vars.
6. **Firestore → Rules:** paste the contents of `firestore.rules` → Publish. **Storage → Rules:** paste `storage.rules` → Publish.
7. Indexes: `firestore.indexes.json` lists them; if a page reports a missing index, tap the link in the error to create it.
8. Firestore → TTL policies: collection `rateLimits`, field `expiresAt`.
9. **Authentication → Settings → Authorized domains:** add your Vercel domain (e.g. `your-app.vercel.app`).

## 2. Deploy on Vercel
- **Without Git/CLI:** open vercel.com/drop, sign in, drop `RentFlow-Main-App-Vercel-Ready.zip` **without unzipping**, name the project, Deploy. (Per Vercel's docs Drop supports framework projects when signed in; each drop creates a new project.)
- **With Git:** push the contents of this folder to a repository and import it in Vercel.
- After the first deploy add the environment variables below, then **Redeploy** (`NEXT_PUBLIC_*` values are baked in at build time).

## 3. Environment variables
| Variable | Required | Secret? | Purpose |
|---|---|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | yes | no | Firebase web config |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | yes | no | Firebase web config |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | yes | no | Firebase web config |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | yes | no | Firebase web config |
| `FIREBASE_ADMIN_PROJECT_ID` | yes | **yes** | Service account |
| `FIREBASE_ADMIN_CLIENT_EMAIL` | yes | **yes** | Service account |
| `FIREBASE_ADMIN_PRIVATE_KEY` | yes | **yes** | Service-account key, in double quotes, keep the `\n` escapes |
| `FIREBASE_STORAGE_BUCKET` | yes | no | Private bucket name |
| `DATA_ENCRYPTION_KEY` | yes | **yes** | `openssl rand -base64 32`; **must equal the Admin Panel's value** |
| `PAYMENT_WEBHOOK_SECRET` | only for provider webhooks | **yes** | Webhook HMAC |
| `NEXT_PUBLIC_REFUND_POLICY`, `NEXT_PUBLIC_RETENTION_POLICY` | optional | no | Text shown on Terms / Privacy |
| `STRICT_TYPES` | optional | no | `true` = fail build on TypeScript errors |

If the four `NEXT_PUBLIC_FIREBASE_*` values are missing from a build, sign-in pages show "not available yet" instead of crashing (names of the missing variables are written to the browser console).

## 4. First steps after deploying
1. Deploy the **Admin Panel**, then create the admin account (see its README).
2. In the Admin Panel set the **application fee** and add/enable at least one **payment method**. Until a fee is saved the Pricing section shows "Shown at checkout".
3. Have the Privacy Policy, Terms and screening disclosure reviewed by an attorney for your states (templates, not legal advice).

## Routes
`/` `/register` `/login` `/forgot-password` `/apply` `/dashboard` `/status` `/pricing` `/how-it-works` `/contact` `/privacy` `/terms` `/applicant-rights` · APIs under `/api/applicant/*`, `/api/public/*`, `/api/status`, `/api/contact`, `/api/webhooks/payments`. (`/admin` lives in the Admin Panel project.)
