/** @type {import('next').NextConfig} */
const securityHeaders = [
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
];

const nextConfig = {
  // Lint and type problems must not block a deployment that has no terminal to fix them in.
  // Run `npm run typecheck` / `npm run lint` locally; set STRICT_TYPES=true in Vercel to enforce types during build.
  eslint: { ignoreDuringBuilds: true },
  typescript: { ignoreBuildErrors: process.env.STRICT_TYPES !== "true" },
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    return [{ source: "/(.*)", headers: securityHeaders }];
  },
};

export default nextConfig;
