# RentFlow Main App — Vercel-এ Deploy (Git ও Terminal ছাড়া)

## পদ্ধতি: Vercel Drop (vercel.com/drop)
Vercel-এর নিজস্ব ডকুমেন্টেশন অনুযায়ী Vercel Drop-এ `.zip` ফাইল দিলে Git বা CLI লাগে না; framework প্রোজেক্ট (Next.js) চিনে নিজে build করে। এর জন্য Vercel অ্যাকাউন্টে সাইন-ইন লাগে। এই ZIP-এর একদম ওপরের স্তরেই `package.json` আছে (ভেতরে আলাদা ফোল্ডার নেই)। **ZIP খুলবেন না, যেমন আছে তেমন দিন।**
সীমা: প্রতিটি Drop একটি **নতুন** প্রজেক্ট বানায়; Drop দিয়ে বিদ্যমান প্রজেক্ট আপডেট করতে হলে ড্যাশবোর্ডে প্রজেক্টের ওপর ফোল্ডার/ফাইল Drop করতে হয় (অ্যাকাউন্ট লাগে)।

## ধাপ
1. Firebase প্রজেক্ট বানান (console.firebase.google.com) এবং README-র "Setup" অংশ অনুসরণ করুন।
2. vercel.com/drop-এ সাইন-ইন করে এই ZIP দিন → Team বাছুন → প্রজেক্টের নাম দিন → **Deploy**।
3. প্রথম deploy-এ Environment Variable না থাকলেও build হওয়ার কথা (সাইটের পাতাগুলো Firebase ছাড়াই render হয়); কিন্তু Register/Login/Apply কাজ করবে না।
4. Project → Settings → Environment Variables-এ `.env.example`-এর সব মান দিন (বিশেষ করে `NEXT_PUBLIC_FIREBASE_*`, `FIREBASE_ADMIN_*`, `FIREBASE_STORAGE_BUCKET`, `DATA_ENCRYPTION_KEY`)।
5. Deployments → সর্বশেষ deployment → **Redeploy**। (`NEXT_PUBLIC_*` মান build-এর সময় বসে, তাই Redeploy ছাড়া কাজ করবে না।)
6. Firebase Console → Authentication → Settings → Authorized domains-এ আপনার `*.vercel.app` ডোমেইন যোগ করুন।
7. Rules (Terminal ছাড়া): Firebase Console → Firestore → Rules ট্যাবে `firestore.rules`-এর লেখা বসিয়ে Publish; Storage → Rules ট্যাবে `storage.rules`-এর লেখা বসিয়ে Publish। Index লাগলে ত্রুটির লিংকে ট্যাপ করলে Console-এ বানানো যায় (তালিকা: `firestore.indexes.json`)।

## Build ও TypeScript
`next.config.mjs`-এ TypeScript/ESLint ত্রুটিতে build থামে না (terminal ছাড়া ঠিক করার উপায় নেই বলে)। কড়া করতে Vercel env-এ `STRICT_TYPES=true` দিন।
